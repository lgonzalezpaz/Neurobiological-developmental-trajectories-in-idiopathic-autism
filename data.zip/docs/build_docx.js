// Builds the manuscript .docx from manuscript.json (Nature-style biomedical article).
// Equations are native Office Math (OMML) objects, fully editable in Word.
const fs = require("fs");
const path = require("path");
const d = require("docx");
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, WidthType,
  AlignmentType, HeadingLevel, Header, PageNumber, LineNumberRestartFormat, TabStopType,
  BorderStyle, ShadingType, Math: OMath, MathRun, MathFraction, MathSubScript, MathSuperScript,
  MathSubSuperScript, MathRoundBrackets, MathSquareBrackets, PageBreak,
} = d;

const ROOT = path.resolve(__dirname, "..");
const M = JSON.parse(fs.readFileSync(path.join(__dirname, "manuscript.json"), "utf8"));
const OUT = process.argv[2] || path.join(ROOT, "manuscript", "Manuscript_PSR_autism.docx");
const FONT = "Times New Roman";
const TEXT_W = 9026; // A4 minus 2 x 1440

// ---------- inline markup: *italic* **bold** ^sup^ ~sub~ ----------
function runs(text, base = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\^[^^]+\^|~[^~]+~)/g;
  let last = 0, m;
  const push = (t, o) => { if (t) out.push(new TextRun({ text: t, font: FONT, ...base, ...o })); };
  while ((m = re.exec(text)) !== null) {
    push(text.slice(last, m.index), {});
    const tok = m[0];
    if (tok.startsWith("**")) {
      // bold may contain italics
      const inner = tok.slice(2, -2);
      runs(inner, { ...base, bold: true }).forEach((r) => out.push(r));
    } else if (tok.startsWith("*")) {
      const inner = tok.slice(1, -1);
      // allow sub/sup inside italics
      runs(inner, { ...base, italics: true }).forEach((r) => out.push(r));
    } else if (tok.startsWith("^")) push(tok.slice(1, -1), { superScript: true });
    else push(tok.slice(1, -1), { subScript: true });
    last = m.index + tok.length;
  }
  push(text.slice(last), {});
  return out;
}

// ---------- tiny OMML parser:  \frac{a}{b}  x_{s}  x^{s}  x_{s}^{t}  \left( ... \right) ----------
function parseMath(s) {
  let i = 0;
  function group() { // expects '{'
    if (s[i] !== "{") throw new Error("expected { at " + i + " in " + s);
    let depth = 0, j = i;
    for (; j < s.length; j++) {
      if (s[j] === "{") depth++;
      else if (s[j] === "}") { depth--; if (depth === 0) break; }
    }
    const inner = s.slice(i + 1, j); i = j + 1;
    return parseMath(inner);
  }
  const out = []; let buf = "";
  const flush = () => { if (buf) { out.push(new MathRun(buf)); buf = ""; } };
  while (i < s.length) {
    if (s.startsWith("\\frac", i)) {
      flush(); i += 5; const num = group(); const den = group();
      out.push(new MathFraction({ numerator: num, denominator: den }));
    } else if (s.startsWith("\\lp", i)) { // \lp{...} round brackets
      flush(); i += 3; out.push(new MathRoundBrackets({ children: group() }));
    } else if (s.startsWith("\\lb", i)) { // \lb{...} square brackets
      flush(); i += 3; out.push(new MathSquareBrackets({ children: group() }));
    } else if (s[i] === "_" || s[i] === "^") {
      // base = last char of buffer or last element
      let base;
      if (buf) { base = [new MathRun(buf.slice(-1))]; buf = buf.slice(0, -1); flush(); }
      else base = [out.pop()];
      const t1 = s[i]; i++;
      const g1 = s[i] === "{" ? group() : [new MathRun(s[i++])];
      if ((s[i] === "_" || s[i] === "^") && s[i] !== t1) {
        i++; const g2 = s[i] === "{" ? group() : [new MathRun(s[i++])];
        const sub = t1 === "_" ? g1 : g2, sup = t1 === "_" ? g2 : g1;
        out.push(new MathSubSuperScript({ children: base, subScript: sub, superScript: sup }));
      } else if (t1 === "_") out.push(new MathSubScript({ children: base, subScript: g1 }));
      else out.push(new MathSuperScript({ children: base, superScript: g1 }));
    } else if (s[i] === "{") { flush(); group().forEach((x) => out.push(x)); }
    else { buf += s[i]; i++; }
  }
  flush();
  return out;
}

const EQS = {
  dS: ["\\frac{dS}{dt}=σ(t)−\\lb{k_{0}+k_{P} ε P Φ(F)} S", 1],
  sigma: ["σ(t)=σ_{b}\\lb{1+a_{σ}\\frac{x^{a} e^{−x}}{a^{a} e^{−a}}}", 2],
  P: ["\\frac{dP}{dt}=\\frac{m(t) S^{λ}−P}{τ_{P}},  m(t)=\\frac{1−d_{m}\\lb{1+e^{−(t−12)/3}}^{−1}}{1+e^{−(t−t_{m})/w_{m}}}", 3],
  R: ["\\frac{dR}{dt}=\\frac{1}{τ_{R}}\\lb{\\frac{R_{0}}{1+(A/A_{h})^{n}}−R},  A=S^{η}", 4],
  psi: ["\\frac{dψ}{dt}=\\frac{1}{τ_{ψ}}\\lb{\\frac{R^{h}}{R^{h}+K_{ψ}^{h}}−ψ}", 5],
  F: ["F=\\frac{1}{1+exp\\lb{\\lp{1−ψ−χ^{∗}}/w_{χ}}},  Φ(F)=φ_{0}+(1−φ_{0})F,  χ^{∗}=0.375, w_{χ}=0.035", "6–7"],
  norm: ["K_{ψ}=R_{ad}\\lp{\\frac{1−ψ_{ad}}{ψ_{ad}}}^{1/h},  σ_{b}=k_{0}+k_{P} P_{ad} Φ_{ad},  k_{0}=\\frac{f_{0}}{1−f_{0}}k_{P} P_{ad} Φ_{ad}", 8],
  abc: ["d(θ)=∑_{j}\\lb{\\frac{log(s_{j}(θ)/s_{j}^{∗})}{δ_{j}}}^{2}+Π(θ)", 9],
  onset: ["t_{X}^{∗}=min\\{t≥0: |D_{X}(t)|≥0.25 max_{0≤u≤30}|D_{X}(u)|\\},  Δ=t_{ψ}^{∗}−t_{S}^{∗}", 10],
  meta: ["\\hat{μ}=\\frac{∑_{i}w_{i}^{∗}g_{i}}{∑_{i}w_{i}^{∗}},  w_{i}^{∗}=\\frac{1}{v_{i}+\\hat{τ}^{2}},  I^{2}=\\frac{Q−(k−1)}{Q}", 11],
  ou: ["dξ=−\\frac{ξ}{τ}dt+σ_{ξ}\\sqrt{2/τ} dW,  ε_{i}(t)=ε_{i}e^{ξ_{G}(t)},  R_{0,i}(t)=R_{0,i}e^{ξ_{S}(t)}", 12],
  meas: ["X_{it}^{obs}=X_{it}+e_{it},  e_{it}∼N\\lp{0, Var_{b}(X_{t})\\frac{1−r}{r}}", 13],
  riclpm: ["x_{it}=μ_{xt}+κ_{xi}+p_{it},  p_{it}=α_{x}p_{i,t−1}+β_{yx}q_{i,t−1}+u_{it}", 14],
  riclpm2: ["y_{it}=μ_{yt}+κ_{yi}+q_{it},  q_{it}=α_{y}q_{i,t−1}+β_{xy}p_{i,t−1}+v_{it}", 15],
  outcome: ["Y_{i}=−B_{i}+e_{i},  B_{i}=\\frac{1}{|T|}∑_{t∈T}\\frac{log S_{i}(t)−\\bar{μ}_{S}(t)}{σ_{S}(t)},  e_{i}∼N\\lp{0, Var(B)\\frac{1−R_{B}^{2}}{R_{B}^{2}}},  T=[8,18] y", 16],
};

function eqParagraph(key) {
  let [src, num] = EQS[key];
  src = src.replace(/\\bar\{([^}]+)\}/g, "$1̄");
  src = src.replace(/\\hat\{([^}]+)\}/g, "$1̂").replace(/\\sqrt\{([^}]+)\}/g, "√($1)").replace(/\\\{/g, "{").replace(/\\\}/g, "}");
  return new Paragraph({
    tabStops: [{ type: TabStopType.CENTER, position: TEXT_W / 2 }, { type: TabStopType.RIGHT, position: TEXT_W }],
    spacing: { line: 240, before: 240, after: 240 },
    children: [new TextRun({ text: "\t", font: FONT }), new OMath({ children: parseMath(src) }),
      new TextRun({ text: `\t(${num})`, font: FONT, size: 24 })],
  });
}

const body = (t, o = {}) => new Paragraph({ spacing: { line: 480, after: 240 }, children: runs(t, { size: 24 }), ...o });
const h1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { line: 480, before: 360, after: 120 }, children: [new TextRun({ text: t, font: FONT, size: 28, bold: true })] });
const h2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { line: 480, before: 240, after: 60 }, children: runs(t, { size: 24, bold: true }) });

function figure(b) {
  const file = path.join(ROOT, "figures", b.file);
  const buf = fs.readFileSync(file);
  // read PNG size
  const w = buf.readUInt32BE(16), h = buf.readUInt32BE(20);
  const maxW = 600; const width = maxW, height = Math.round(maxW * h / w);
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 240, after: 120 }, children: [new TextRun({ text: `[Figure ${b.n} near here]`, font: FONT, size: 24, bold: true })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, children: [new ImageRun({ type: "png", data: buf, transformation: { width, height },
      altText: { title: `Figure ${b.n}`, description: b.caption.replace(/[*^~]/g, "").slice(0, 250), name: `Figure${b.n}` } })] }),
    new Paragraph({ spacing: { line: 360, after: 360 }, children: runs(b.caption, { size: 20 }) }),
  ];
}

function table(b) {
  const border = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
  const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
  const W = b.widths; const tot = W.reduce((a, c) => a + c, 0);
  const cell = (t, i, head, last) => new TableCell({
    width: { size: W[i], type: WidthType.DXA },
    borders: { top: head ? border : none, bottom: (head || last) ? border : none, left: none, right: none },
    margins: { top: 40, bottom: 40, left: 80, right: 80 },
    children: [new Paragraph({ spacing: { line: 240 }, children: runs(String(t), { size: 18, bold: head }) })],
  });
  const rows = [new TableRow({ tableHeader: true, children: b.header.map((t, i) => cell(t, i, true, false)) })];
  b.rows.forEach((r, k) => rows.push(new TableRow({ children: r.map((t, i) => cell(t, i, false, k === b.rows.length - 1)) })));
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 240, after: 60 }, children: [new TextRun({ text: `[Table ${b.n} near here]`, font: FONT, size: 24, bold: true })] }),
    new Paragraph({ keepNext: true, spacing: { line: 276, after: 80 }, children: runs(`**Table ${b.n} | ${b.caption}**`, { size: 20 }) }),
    new Table({ width: { size: tot, type: WidthType.DXA }, columnWidths: W, rows }),
    new Paragraph({ spacing: { line: 276, after: 360, before: 60 }, children: runs(b.note || "", { size: 18 }) }),
  ];
}

const children = [];
children.push(new Paragraph({ spacing: { line: 360, after: 240 }, children: [new TextRun({ text: M.title, font: FONT, size: 32, bold: true })] }));
children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { line: 360 }, children: [
  new TextRun({ text: "[AUTHOR NAME]", font: FONT, size: 24 }), new TextRun({ text: "1,", font: FONT, size: 24, superScript: true }),
  new TextRun({ text: "*", font: FONT, size: 24, superScript: true })] }));
children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { line: 276 }, children: [
  new TextRun({ text: "1", font: FONT, size: 19, superScript: true, italics: true }),
  new TextRun({ text: "[AFFILIATION: Department, Institution, City, Country]", font: FONT, size: 19, italics: true })] }));
children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { line: 276, after: 360 }, children: [
  new TextRun({ text: "*Correspondence: lgonzalezpaz@gmail.com ([INITIALS])", font: FONT, size: 20 })] }));
children.push(new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: "Abstract", font: FONT, size: 28, bold: true })] }));
children.push(new Paragraph({ spacing: { line: 480, after: 240 }, children: runs(M.abstract, { size: 22 }) }));
children.push(new Paragraph({ spacing: { line: 360, after: 240 }, children: [new TextRun({ text: "Keywords: ", font: FONT, size: 20, bold: true }), ...runs(M.keywords, { size: 20 })] }));

for (const b of M.blocks) {
  if (b.type === "h1") { if (b.text === "Introduction") children.push(new Paragraph({ children: [new PageBreak()] })); children.push(h1(b.text)); }
  else if (b.type === "h2") children.push(h2(b.text));
  else if (b.type === "p") children.push(body(b.text));
  else if (b.type === "eq") children.push(eqParagraph(b.key));
  else if (b.type === "fig") figure(b).forEach((x) => children.push(x));
  else if (b.type === "table") table(b).forEach((x) => children.push(x));
}
children.push(h1("References"));
M.references.forEach((r, i) => children.push(new Paragraph({
  spacing: { line: 276, after: 60 }, indent: { left: 454, hanging: 454 },
  children: [new TextRun({ text: `${i + 1}.\t`, font: FONT, size: 19 }), ...runs(r, { size: 19 })],
  tabStops: [{ type: TabStopType.LEFT, position: 454 }],
})));

const doc = new Document({
  creator: "[AUTHOR]", title: M.title,
  styles: { default: { document: { run: { font: FONT, size: 24, color: "000000" } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 28, bold: true, color: "000000" }, paragraph: { outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 24, bold: true, color: "000000" }, paragraph: { outlineLevel: 1 } }] },
  sections: [{
    properties: {
      page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } },
      lineNumbers: { countBy: 1, restart: LineNumberRestartFormat.CONTINUOUS, distance: 360 },
    },
    headers: { default: new Header({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 20 })] })] }) },
    children,
  }],
});
fs.mkdirSync(path.dirname(OUT), { recursive: true });
Packer.toBuffer(doc).then((b) => { fs.writeFileSync(OUT, b); console.log("wrote", OUT); });
