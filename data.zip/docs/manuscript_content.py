"""Builds manuscript.json (structured blocks) from the results files.

Inline markup:  *italic*  **bold**  ^superscript^  ~subscript~  [@key1,key2] citations.
Every number in the text is read from results/ so that text and analysis cannot diverge.
"""
import json, re
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "results"
J = lambda f: json.load(open(R / f))
bs, pm, abc, sb, es = J("brainspan_timing.json"), J("postmortem_stats.json"), J("abc_summary.json"), \
    J("sensitivity_bistability.json"), J("entry_signature_stats.json")
idn, lr = J("insilico_identifiability.json"), J("insilico_loop_recovery.json")
sf = pd.read_csv(R / "sfari_go_enrichment.csv")
pw = pd.read_csv(R / "insilico_power.csv")
dg = pd.read_csv(R / "insilico_design_grid.csv")
eff = pd.read_csv(R / "postmortem_dx_effects.csv")
par = pd.read_csv(R / "table1_parameters.csv")
ptj = J("prediction_trial.json")
pe = pd.read_csv(R / "prediction_external.csv")
phz = pd.read_csv(R / "prediction_horizon.csv")
plc = pd.read_csv(R / "prediction_learning_curve.csv")
def pex(r2l, feat, harm=True):
    return pe[(pe.R2_latent == r2l) & (pe.features == feat) & (pe.harmonized == harm)].iloc[0]
def phv(last, feat):
    return phz[(phz.last_wave == last) & (phz.features == feat)].R2_external.iloc[0]
plcm = plc.groupby(["n_train", "features"]).R2_external.mean()
alloc = ptj["allocation"]; gain = ptj["gain_rule_vs_best_single"]
best_single_v = max(alloc["Everyone: glial therapy"], alloc["Everyone: microexon therapy"])
oracle_gain = alloc["Oracle (true best)"] - best_single_v
FA, FB, FC = "Clinical", "Clinical + imaging", "Clinical + imaging + omics"


def f2(x): return f"{x:.2f}"
def f1(x): return f"{x:.1f}"
def pf(p):
    if p < 1e-3:
        m, e = f"{p:.1e}".split("e")
        return f"{m} × 10^{int(e)}^"
    return f"{p:.3f}" if p < 0.01 else f"{p:.2f}"
def ci(l, h, d=2): return f"{l:.{d}f}–{h:.{d}f}"
def pct(x): return f"{100 * x:.0f}%"


# ---- derived numbers --------------------------------------------------------
mG, mS = pm["meta"]["GLIA_PRUNE"], pm["meta"]["NEURO_SPLICE"]
mGc, mSc = pm["meta_cell_adjusted"]["GLIA_PRUNE"], pm["meta_cell_adjusted"]["NEURO_SPLICE"]
het = pm["heterogeneity"]; cp = pm["coupling"]; ai = pm["age_interaction_GSE102741"]
g_coh = pm["per_cohort"]["GLIA_PRUNE"]
an = bs["antiphase_GLIA_vs_SRRM4"]
gl, spc, cal = abc["glia"], abc["splice"], abc["calibration"]
sfr = sf[sf.sfari_set == "SFARI score 1-2"].set_index("term")
ns = sfr.loc["A-priori NEURO_SPLICE module"]; gp = sfr.loc["A-priori GLIA_PRUNE module"]
alt = sfr.loc["Regulation Of Alternative mRNA Splicing, Via Spliceosome (GO:0000381)"]
syn = sfr.loc["Chemical Synaptic Transmission (GO:0007268)"]; chrm = sfr.loc["Chromatin Remodeling (GO:0006338)"]
sf1 = sf[(sf.sfari_set == "SFARI score 1") & (sf.arm == "Glial arm")]
cs = idn["cross_sectional"]
auc_cs = [v["auc_route"] for v in cs.values()]
s = pw.assign(sig_xy=pw.p_xy < 0.05, sig_yx=pw.p_yx < 0.05)
pow_tab = s.groupby(["model", "rel_C", "N"])[["sig_xy", "sig_yx"]].mean().reset_index()


def nmin(model, rel, col, thr=0.8):
    q = pow_tab[(pow_tab.model == model) & (pow_tab.rel_C == rel)].sort_values("N")
    ok = q[q[col] >= thr]
    return int(ok.N.iloc[0]) if len(ok) else None


def nstr(n): return f"{n:,}" if n else "> 1,600"
est_xy = s[s.model == 'RI-CLPM'].groupby('rel_C').b_xy.mean().to_dict()
est_xy_clpm = s[(s.model == 'CLPM') & (s.rel_C == 0.6)].b_xy.mean()
both = {r: max([x or 10 ** 9 for x in (nmin("RI-CLPM", r, "sig_xy"), nmin("RI-CLPM", r, "sig_yx"))]) for r in (0.29, 0.6, 0.9)}
both = {k: (v if v < 10 ** 9 else None) for k, v in both.items()}
clpm_xy_pow = pow_tab[(pow_tab.model == "CLPM") & (pow_tab.rel_C == 0.6)].set_index("N").sig_xy
dgm = dg.groupby(["design", "rel_C"]).acc.mean()
B = []
def H1(t): B.append(dict(type="h1", text=t))
def H2(t): B.append(dict(type="h2", text=t))
def P(t): B.append(dict(type="p", text=t))
def EQ(key): B.append(dict(type="eq", key=key))
def FIG(n, file, cap): B.append(dict(type="fig", n=n, file=file, caption=cap))
def TAB(n, cap, header, rows, widths, note=""): B.append(dict(type="table", n=n, caption=cap, header=header, rows=rows, widths=widths, note=note))

TITLE = ("Neurobiological developmental trajectories in idiopathic autism: a calibrated pruning–splicing model and "
         "multicentre in-silico trial define the design for stratification and individual prediction")

ABSTRACT = (
    "A prospective, multicentre, longitudinal multi-omic and neuroimaging cohort has been proposed as the definitive "
    "design for biological stratification and individual outcome prediction in idiopathic autism, yet no study has "
    "specified what such a cohort must measure, when, and in how many participants. We built a minimal, "
    "literature-calibrated model in which synaptic pruning and SRRM4-dependent splicing of the CPEB4 microexon form a "
    "reciprocal loop, and used it as a design instrument. The model reproduced held-out data, including the postnatal "
    f"SRRM4 minimum in BrainSpan ({f1(gl['ctl_R_trough_age'][1])} versus {f1(an['trough_age_median'])} years) and autistic "
    f"microexon inclusion ({f2(gl['psi_asd'][1])} versus 0.55). In three post-mortem cohorts (57 autistic, 84 control "
    f"brains), glial-pruning expression was increased (Hedges' *g* = {f2(mG['est'])}, *P* = {pf(mG['p'])}) and rose with "
    f"age, and splicing regulators were enriched for risk genes (odds ratio {f1(ns.OR)}). Glia-first and splicing-first "
    "entry converged cross-sectionally but differed in when microexon loss appeared relative to the pruning epoch. In a "
    "six-site in-silico trial validated on held-out sites, trajectories identified entry routes (area under the curve "
    f"{f2(idn['long_supervised_external'])}); data from 2–6 years predicted outcome at 18 years modestly (external "
    f"*R*^2^ {f2(pex(0.5, FC).R2_external)}, rising to {f2(phv(12, FC))} with waves to 12 years), with neuroimaging "
    "adding most to clinical predictors; and route-based allocation of equipotent therapies outperformed the best single "
    f"therapy (+{gain['mean']:.3f} s.d., *P* = {pf(gain['p_one_sided'])}). Infancy enrolment, reliability of at least 0.6, "
    f"random-intercept models, site-specific normative charts and about {nstr(both[0.6])}–800 autistic participants were "
    "required. This provides a falsifiable blueprint for the definitive cohort.")

KEYWORDS = ("idiopathic autism; developmental trajectories; individual prediction; multicentre validation; "
            "in-silico trial; CPEB4 microexon; synaptic pruning; biological stratification")

# =============================================================================
H1("Introduction")
P("Autism spectrum disorder affects about 1% of children and is among the most heritable neurodevelopmental conditions, "
  "with twin and family estimates of heritability near 80% [@lord,hirota,bai]. Yet no single gene explains more than a "
  "small fraction of cases, common variants of small effect capture only part of the heritability, and rare damaging "
  "variants converge on chromatin regulation and synaptic signalling without accounting for most idiopathic presentations "
  "[@grove,fu,munir]. The central unresolved question is therefore one of convergence: how hundreds of genetic and "
  "environmental perturbations acting on disparate pathways produce a relatively convergent behavioural phenotype, and "
  "how that heterogeneity can be stratified into biologically meaningful subgroups that support targeted intervention "
  "[@bey,munir].")
P("Post-mortem transcriptomics has provided the clearest molecular evidence of convergence. Co-expression studies of "
  "autistic cortex repeatedly identify a down-regulated neuronal module enriched for risk genes and splicing regulators "
  "such as *RBFOX1*, and an up-regulated module of microglial and immune genes [@voineagu,gupta,parikshak,gandal2018,velmeshev,gandal2022]. "
  "Splicing is a recurrent theme: neural microexons controlled by SRRM4 (nSR100) are mis-spliced in a substantial "
  "fraction of autistic brains [@irimia], reduced SRRM4 dosage causes autistic-like phenotypes in mice [@quesnel], and "
  "decreased inclusion of a 24-nucleotide microexon in the translational regulator CPEB4 deadenylates the transcripts of "
  "most high-confidence risk genes [@parras]. Most recently, this microexon was shown to keep CPEB4 condensates "
  "reversible after neuronal depolarization: below about 60% inclusion, condensates convert to aggregates, and the "
  "isoform ratio of autistic cortex lies beyond this threshold [@garcia]. In parallel, the up-regulated glial module "
  "connects to a second literature on synaptic pruning: microglia and astrocytes eliminate synapses through complement, "
  "fractalkine and MEGF10/MERTK pathways [@paolicelli,schafer,chung], primary microglial deficits reduce functional "
  "connectivity and produce autism-relevant behaviour [@zhan], and autistic temporal cortex shows a marked deficit of "
  "adolescent spine pruning [@tang,penzes]. Mouse and organoid studies show that either over-pruning or under-pruning by "
  "microglia can follow from autism-associated lesions [@wu,gao2026,chen2026].")
P("These two literatures are usually joined by an implicit one-way arrow: splicing and other neuronal gene-regulatory "
  "defects are assumed to precede, and cause, aberrant pruning and connectivity. The reverse arrow is mechanistically "
  "plausible and has received growing attention. Neuronal activity regulates alternative splicing through calcium-dependent "
  "pathways [@xie,hermey,furlanis,lopezsoto], depolarization reprogrammes broad classes of exons in activated neurons [@krick], "
  "and increased activity rapidly decreases SRRM4 and the inclusion of the same microexons that are misregulated in "
  "autistic brains [@quesnel]. A circuit that escapes pruning should therefore be expected to change the splicing state "
  "of its own neurons. A recent phase-based framework further proposes that microglial activation may be causal early "
  "in development and largely consequential later [@gabr]. If both arrows exist, the relationship between pruning and "
  "splicing is a loop, and the meaningful question becomes not which direction is true but where, and when, each "
  "individual's perturbation enters that loop. Establishing an average causal order across a population does not "
  "reveal which route a particular child has taken; only prospective measurement in the same individuals can do so.")
P("Answering this question is a design problem as much as a biological one. Biomarker studies in autism have produced "
  "hundreds of candidate molecules with little replication [@parellada], large consortia have achieved harmonized, "
  "reliable electrophysiological and eye-tracking measures without yet delivering a clinically actionable stratification "
  "marker [@loth,mcpartland,holiga,griffin], and the strongest replicated subtypes are phenotypic or genomic rather than "
  "multi-omic [@litman,chan,mandelli]. Integrative studies remain largely cross-sectional and post-mortem [@ramaswami,buch]. "
  "Directional inference requires repeated measures, but cross-lagged panel models confound stable between-person "
  "differences with within-person dynamics unless random intercepts are modelled [@hamaker,mulder], and published "
  "longitudinal brain–behaviour analyses in autism have reached opposite conclusions [@lin,durkut]. Genetic instruments "
  "for splicing and cell-type-specific expression offer complementary leverage [@qi,haglund,hao,sebenius], but no study "
  "has specified, before data collection, which measurements, how many waves and how many participants would be needed "
  "to discriminate competing causal routes.")
P("Here we address this design problem directly, taking as our target the study that has been proposed as the "
  "definitive answer for idiopathic autism: a prospective, multicentre cohort that integrates longitudinal multi-omic "
  "and neuroimaging trajectories for biological stratification and individual outcome prediction, with independent "
  "external validation. Such a cohort is too costly to be designed by trial and error. We therefore built a minimal "
  "pruning–splicing reciprocity (PSR) model as a design instrument, constrained it with literature values, and tested "
  "it against held-out normative developmental data, three independent post-mortem cohorts and the genetic loading of "
  "its two arms. We then used the calibrated model as a data-generating process for an in-silico version of the "
  "definitive cohort, with three questions: can longitudinal multimodal trajectories identify where each individual "
  "entered the loop (stratification); how well can early data predict each child's later outcome across sites "
  "(individual prediction with external validation); and does mechanism-based stratification improve the allocation "
  "of route-specific interventions? Our working hypothesis was that distinct entry routes converge on a shared state "
  "and can be distinguished only by the developmental timing of microexon loss relative to the pruning epoch.")

# =============================================================================
H1("Methods")
H2("Study design and reporting")
P("The study combined four components (Fig. 1a): (i) a mechanistic model calibrated by approximate Bayesian computation "
  "(ABC); (ii) validation against held-out normative transcriptomic data and three independent post-mortem cohorts; "
  "(iii) a genetic-loading analysis; and (iv) simulation studies of the proposed longitudinal, multicentre cohort, "
  "covering stratification, individual outcome prediction and treatment allocation. All analyses used publicly "
  "available, de-identified data (Table 1). Hypotheses, gene modules and calibration targets were fixed before the "
  "validation data were analysed; one pre-specified prediction that was not supported (negative glia–splicing "
  "coupling) is reported in full. The mechanistic model serves as a design instrument—a calibrated "
  "data-generating process for the simulated cohort—rather than as an end in itself. All code runs on a two-core laptop in under two hours.")

H2("Pruning–splicing reciprocity model")
P("The model describes cortical synaptic (spine) density *S*, network activity *A*, a reactive glial pruning state *P*, "
  "the SRRM4 level *R*, the inclusion fraction ψ of the CPEB4 24-nucleotide microexon (me4) and the reversible, functional "
  "fraction *F* of CPEB4, with time *t* in years from birth. Synapses are formed at a developmentally programmed rate σ(*t*) "
  "and eliminated by baseline turnover *k*~0~ plus glial pruning whose efficacy depends on CPEB4-dependent refinement:")
EQ("dS")
P("where *k*~P~ is the pruning rate constant, ε the glial engulfment efficacy (ε = 1 in controls) and Φ(*F*) the "
  "efficacy of activity-dependent refinement. Synaptogenesis is a gamma-shaped pulse on a maintenance rate σ~b~:")
EQ("sigma")
P("with *x* = (*t* − *t*~0~)/τ~s~ and *t*~0~ = −0.5 years (mid-gestation), consistent with synapse formation beginning in "
  "the fetal cortex [@hutt]. Network activity scales with synaptic density, *A* = *S*^η^. The glial state follows a "
  "maturation programme *m*(*t*) and responds to synaptic load, reflecting activity- and complement-dependent recruitment "
  "of microglia to synapses [@schafer,badimon]:")
EQ("P")
P("Activity represses SRRM4, as increased neuronal activity rapidly lowers nSR100 [@quesnel], and SRRM4 drives microexon "
  "inclusion through a Hill function:")
EQ("R")
EQ("psi")
P("The reversible CPEB4 fraction is a steep sigmoid of the mole fraction of the microexon-lacking isoform, χ = 1 − ψ, "
  "centred between the control (0.30) and autistic (0.45) values at which aggregation becomes irreversible [@garcia]:")
EQ("F")
P("Equations (1)–(7) form a positive-feedback loop (Fig. 1a): an excess of synapses raises activity, lowers SRRM4 and "
  "ψ, reduces reversible CPEB4 and refinement efficacy, and further slows elimination. Two constants were fixed by "
  "normalizing the adult control steady state to *S* = *A* = 1 and ψ = 0.70:")
EQ("norm")
P("where *R*~ad~ = 1/(1 + *A*~h~^−n^), *P*~ad~ = 1 − *d*~m~ and Φ~ad~ = Φ(*F*(0.70)). Glia-first entry was modelled as "
  "reduced engulfment efficacy, ε = 1 − δ~G~, and splicing-first entry as reduced SRRM4 production, *R*~0~ = 1 − δ~S~. "
  "Equations were integrated with a vectorized fourth-order Runge–Kutta scheme (step 0.005 years) from −0.5 to 40 years.")

H2("Priors, calibration and prior-predictive comparison")
P("Seventeen parameters received uniform priors spanning physiologically plausible ranges (Table 2). Calibration "
  "targets were taken from human post-mortem studies: the 1.82-fold decline in layer V spine density from childhood "
  "(2–9 years) to adolescence (13–20 years) in control temporal cortex [@tang]; a childhood peak two- to three-fold above "
  "adult values with remodelling continuing into the third decade [@petanjek]; a prefrontal peak after 15 months [@hutt]; "
  "and adult control me4 inclusion of 0.70 [@garcia]. ABC rejection [@beaumont,sunnaker] drew 60,000 prior samples and "
  "retained the 1% closest to the targets under the distance")
EQ("abc")
P("where *s*~j~ are simulated summaries, *s*~j~^∗^ targets and δ~j~ tolerances (0.10 on the log scale for the "
  "childhood-to-adolescence ratio, log 1.5 for the peak-to-adult ratio, 0.05 for stabilization and 0.02 for adult ψ), and "
  "Π penalizes peak ages outside 1.25–5 years. Prior-predictive distributions were compared with the targets to verify "
  "that the priors covered the data without forcing them. For each accepted parameter set, δ~G~ or δ~S~ was found by "
  "grid search with linear interpolation as the smallest lesion reproducing the 1.66-fold adolescent spine excess "
  "observed in autism [@tang]. The autistic childhood spine ratio (1.08), autistic me4 inclusion (0.55) [@garcia], the "
  "BrainSpan ages of the SRRM4 minimum and glial maximum, and the direction and age dependence of the glial-state change "
  "in autism were withheld from fitting and used as out-of-sample tests.")

H2("Entry-route signatures, sensitivity and fixed points")
P("For each route the deviation of variable *X* from the matched control trajectory, *D*~X~(*t*), was computed "
  "(relative excess for *S* and *P*; absolute loss for ψ), and its onset age was defined as")
EQ("onset")
P("Global sensitivity of Δ, of the adolescent spine ratio and of adult ψ was quantified with Sobol total-order indices "
  "[@sobol,saltelli] (Saltelli sampling, 256 base samples, 4,864 simulations per condition; SALib [@salib]) over the "
  "2.5–97.5% posterior range of every parameter, with lesion size fixed at the posterior median. Adult fixed points were "
  "obtained by solving *S* = σ~b~/[*k*~0~ + *k*~P~ε*P*(*S*)Φ(*S*)] on a 4,000-point logarithmic grid for lesion sizes 0–0.9; "
  "parameter sets with more than one stable fixed point were classified as bistable.")

H2("Normative developmental transcriptome")
P("Gene-level RNA-sequencing data (RPKM) from the BrainSpan atlas [@kang,miller] were restricted to 362 neocortical "
  "samples from 42 donors (8 post-conceptional weeks to 40 years). Expression was log~2~(RPKM + 1)-transformed and z-scored "
  "per gene, module scores were averaged per sample and then per donor to avoid pseudo-replication, and trajectories were "
  "estimated by LOWESS (span 0.45) on log post-conceptional age, with 95% bands from 1,000 donor bootstraps. Peak and "
  "trough ages and the correlation between postnatal glial and *SRRM4* curves were bootstrapped in the same way.")

H2("Post-mortem cohorts and a-priori modules")
P("Three independent cortical cohorts were analysed (Table 1): GSE28521 (frontal and temporal cortex, averaged per "
  "donor; 16 autistic, 16 control) [@voineagu], GSE28475 (prefrontal cortex, frozen DASL arrays; duplicate dissections "
  "of one donor collapsed; 28 autistic, 29 control) [@chow] and GSE102741 (dorsolateral prefrontal RNA-seq with age, "
  "sex and RNA integrity; 13 autistic, 39 control) [@wright]. Illumina probes were mapped with the GPL6883 annotation, "
  "DASL intensities were log~2~-transformed and quantile-normalized, and the most-expressed probe per gene was retained. "
  "Four modules were defined a priori from the literature (Table 1): glial pruning (16 genes: complement *C1QA–C*, *C3*, "
  "*C4A/B*, CR3 *ITGAM*, *CX3CR1*, *TREM2*, *TYROBP*, *P2RY12*, *CSF1R*, *CD68*, *AIF1*, *MEGF10*, *MERTK*), neuronal "
  "splicing regulators (13 genes including *SRRM4*, *RBFOX1*, *NOVA1/2* and *PTBP2*), activity-regulated immediate-early "
  "genes (11) and synaptic structural genes (13). Neuronal, astrocytic and oligodendrocyte marker scores, disjoint from "
  "the modules, served as cell-composition covariates.")

H2("Statistical analysis of post-mortem data")
P("Within each cohort, module scores were regressed on diagnosis (with log age, sex and RNA integrity in GSE102741). "
  "*t* statistics were converted to Hedges' *g*, and two-sided permutation *P* values were obtained from 10,000 "
  "label permutations with covariates fixed. Cohort estimates were pooled by DerSimonian–Laird random-effects "
  "meta-analysis [@dersim]:")
EQ("meta")
P("Sensitivity analyses added the three cell-composition scores. Glia–splicing coupling was tested by partial Spearman "
  "correlation of covariate-residualized scores, pooled across cohorts by Fisher *z*. Heterogeneity was assessed on "
  "control-referenced *z* scores by Brown–Forsythe tests of dispersion [@brown], a one-sided Mann–Whitney test of "
  "radial distance, and Gaussian mixture models compared by the Bayesian information criterion [@schwarz], with the "
  "significance of the 2- versus 1-component difference obtained from 500 parametric bootstrap samples under the "
  "single-Gaussian null. Age dependence was tested by a diagnosis × log(age) interaction in GSE102741.")

H2("Genetic loading of the two arms")
P("High-confidence SFARI Gene risk genes (score 1–2; 957 genes, of which 826 were annotated) [@abrahams] were tested for "
  "over-representation in pre-specified Gene Ontology Biological Process 2023 sets (splicing arm, glial arm and two "
  "comparators) and in the a-priori modules by two-sided Fisher exact tests against all 14,698 annotated genes, with "
  "Benjamini–Hochberg correction [@bh]. Score-1 genes were analysed separately.")

H2("In-silico longitudinal trial")
P("Virtual participants were generated by resampling parameter sets from the posterior (restricted to the sets in which "
  "both lesions reproduced the adolescent excess) and assigning them to control, glia-first or splicing-first groups, "
  "with lesion sizes multiplied by log-normal jitter (s.d. 0.25). Ornstein–Uhlenbeck processes perturbed log engulfment "
  "efficacy and log SRRM4 production in every participant, representing infections and other transient exposures:")
EQ("ou")
P("with τ = 1 year and σ~ξ~ = 0.15. Three read-outs were measured at scheduled waves, a synaptic/connectivity proxy "
  "*C* = log *S* (for example SV2A positron emission tomography [@finnema] or functional connectivity), a microexon "
  "proxy logit ψ and a glial proxy log *P* (for example translocator-protein imaging or cerebrospinal fluid complement "
  "[@suzuki,zurcher]), each with error variance set by its test–retest reliability *r*:")
EQ("meas")
P("Reliability scenarios were anchored to empirical values: 0.29 for edge-level functional connectivity [@noble], "
  "0.6 for network-level and electrophysiological measures [@levin] and 0.9 as an optimistic bound; default values were "
  "0.6 (*C*), 0.8 (ψ) and 0.7 (*G*). Each read-out was referenced to a site-specific normative chart estimated from "
  "controls [@marquand,bethlehem]. Entry routes were then inferred by (i) single-wave logistic classifiers (five-fold "
  "cross-validation), (ii) a supervised classifier using all waves, trained in cohort A and applied to an independent "
  "cohort B with systematic site shifts, (iii) an unsupervised onset-order rule assigning the route whose marker first "
  "exceeded |*z*| = 1, and (iv) unsupervised Gaussian mixtures. Loop recovery used a bivariate random-intercept "
  "cross-lagged panel model (RI-CLPM) [@hamaker,mulder]:")
EQ("riclpm")
EQ("riclpm2")
P("where *x* is the synaptic proxy, *y* the microexon proxy, κ random intercepts (stable between-person differences), "
  "β~xy~ the effect of *x* on later *y* and β~yx~ the reverse, with (*u*, *v*) correlated innovations; and its conventional counterpart without random intercepts (CLPM), both fitted by maximum likelihood to the "
  "covariance matrix with time-invariant lagged effects and Wald tests from the observed information. The estimator was "
  "validated on data simulated from a known RI-CLPM. Power to detect each cross-lagged path (two-sided α = 0.05) was "
  "estimated from 60 replicates per cell over *N* = 100–1,600 autistic participants and three reliabilities, with six "
  "biennial waves between 6 and 16 years.")

H2("Multicentre trial of individual prediction and treatment allocation")
P("To emulate the primary end-point of the proposed cohort, we simulated six sites, each with 300 autistic and 150 "
  "control participants, a site-specific case mix (splicing-first fraction 30–70%), additive measurement biases "
  "(s.d. 0.3) and modality reliabilities drawn around the default values (s.d. 0.1). Four read-outs were observed at "
  "2, 4 and 6 years: a clinical severity score *K* (reliability 0.7), the synaptic/neuroimaging proxy *C*, the "
  "microexon proxy and the glial proxy. The outcome at 18 years was defined from the latent circuit burden *B*~i~, the "
  "mean synaptic excess between 8 and 18 years in units of the untreated control distribution:")
EQ("outcome")
P("where the share of outcome variance explained by circuit burden, *R*^2^~B~, is an explicit assumption varied over "
  "0.3, 0.5 and 0.7. Ridge regression models with nested feature sets (clinical; clinical + imaging; clinical + "
  "imaging + omics; levels and slopes) were trained on four sites and evaluated on two held-out sites, with and without "
  "site-specific normative harmonization; bootstrap (500 resamples) intervals were computed for the external "
  "*R*^2^. Learning curves (30 replicates per training size) and the prediction horizon (last observed wave 6–12 "
  "years) were evaluated in the same way. For treatment allocation, two hypothetical interventions were applied to "
  "autistic participants from 6 to 14 years: a microexon-restoring therapy (SRRM4 production × 1.3) and a glial "
  "therapy increasing engulfment efficacy, whose dose was calibrated by bisection to be equipotent on average. Each "
  "participant was simulated three times with identical stochastic paths, so that individual benefit (reduction in "
  "*B*~i~) under each therapy was known exactly. Strategies were compared in the held-out sites: a single therapy for "
  "everyone, random allocation, allocation by the label-free onset-order rule applied to the 2–6-year waves, a "
  "multimodal model of differential benefit trained on the training sites, and the oracle. The route × therapy "
  "interaction was tested by least squares, and the gain of the onset-order rule over the best single therapy by "
  "2,000 bootstrap resamples.")

H2("Statistics and reproducibility")
P("Tests were two-sided unless stated. Effect sizes are reported with 95% confidence or credible intervals. Random seeds "
  "were fixed (20261020). Analyses used Python 3.13 with NumPy, SciPy, pandas, statsmodels, scikit-learn, SALib and "
  "Matplotlib (exact versions in the repository). A single script regenerates every number, table and figure from the "
  "public raw data.")

# =============================================================================
H1("Results")
H2("The design model reproduces held-out human developmental data")
P("The prior-predictive distribution spanned the calibration targets without concentrating on them: the "
  f"childhood-to-adolescence spine ratio ranged {ci(*cal['child_over_adol']['prior_95'])} a priori (target 1.82) and "
  f"the peak-to-adult ratio {ci(*cal['peak_over_adult']['prior_95'])} (target 2–3). After ABC (acceptance rate "
  f"{pct(cal['accept_rate'])}), the posterior reproduced the targets (childhood-to-adolescence ratio "
  f"{ci(*cal['child_over_adol']['post_95'])}; peak-to-adult ratio {ci(*cal['peak_over_adult']['post_95'])}; peak age "
  f"{f1(cal['peak_age_post'][1])} years, 95% interval {ci(cal['peak_age_post'][0], cal['peak_age_post'][2], 1)}; adult ψ "
  f"{f2(cal['psi_ctl_post'][1])}) (Fig. 1b; Table 3). Posterior contraction was modest for most individual parameters "
  f"(median {pct(par.contraction.median())}; Table 2), the hallmark of a sloppy but predictive model, so we evaluated "
  "the model on predictions rather than on individual parameter values.")
P("Three predictions were not used in fitting. First, in controls, the loop produced a postnatal SRRM4 minimum at "
  f"{f1(gl['ctl_R_trough_age'][1])} years (95% interval {ci(gl['ctl_R_trough_age'][0], gl['ctl_R_trough_age'][2], 1)}), "
  "emerging solely from activity-dependent repression during the period of maximal synaptic density (Fig. 1e). Second, "
  "the glia-first lesion that reproduced the adolescent spine excess predicted adult autistic me4 inclusion of "
  f"{f2(gl['psi_asd'][1])} ({ci(gl['psi_asd'][0], gl['psi_asd'][2])}), against an observed 0.55 [@garcia] (Fig. 1c). "
  "Third, because the glial state is reactive to synaptic load, both lesions predicted that glial-pruning activity "
  f"would be elevated in autism and would rise with age, from {f2(gl['P_ratio_child'][1])}-fold in childhood to "
  f"{f2(gl['P_ratio_adult'][1])}-fold in adulthood (Fig. 1d). The model over-predicted the small childhood spine "
  f"excess (predicted {f2(gl['child_ratio'][1])}, observed 1.08). A glia-first lesion reproduced the adolescent excess "
  f"in all {gl['n_fit']} posterior sets, whereas a splicing-first lesion did so in only {spc['n_fit']} "
  f"({pct(spc['frac_fit'])}), indicating that a primary splicing defect generates a pruning deficit of this size only "
  "when refinement depends strongly on reversible CPEB4 (low φ~0~). The model also predicted that control ψ "
  "transiently approaches the aggregation threshold during the childhood pruning peak (Fig. 1c), defining a "
  "physiological window of CPEB4 vulnerability.")
FIG(1, "Figure1_model_calibration.png",
    "**Figure 1 | The pruning–splicing reciprocity model and its calibration.** **a**, Model structure. Synaptic density "
    "*S* increases network activity *A*; activity represses SRRM4 (*R*), which controls inclusion ψ of the CPEB4 "
    "microexon; the reversible CPEB4 fraction *F*(ψ) sets refinement efficacy Φ and hence glial synapse elimination, "
    "closing a positive-feedback loop. The glial state *P* is reactive to synaptic load. Glia-first entry reduces "
    "engulfment efficacy ε; splicing-first entry reduces SRRM4 production *R*~0~. **b**, Spine density (posterior median "
    "and 10–90% band; 80 posterior parameter sets in which both lesions reproduce the adolescent excess) with the human "
    "layer V data used for calibration (Tang et al., mean ± s.d.; control values fitted, autistic adolescent value used "
    "to fit lesion size, autistic childhood value held out). **c–e**, Trajectories of microexon inclusion ψ, glial state "
    "*P* and SRRM4 *R*. Dotted lines in **c** mark control (0.70) and autistic (0.55, held out) inclusion; the dashed "
    "line marks the CPEB4 aggregation threshold (χ = 0.375). Ages are shown on a symmetric-log axis.")
TAB(2, "Model parameters, priors and posterior estimates.",
    ["Parameter", "Meaning", "Prior (uniform)", "Posterior median (95% CrI)", "Basis"],
    [], [1250, 3100, 1300, 1900, 1476], note="")
H2("Normative cortical development places the SRRM4 minimum inside the pruning window")
P("In BrainSpan neocortex (42 donors), the synaptic and activity modules rose steeply around birth, the glial-pruning "
  f"module rose postnatally to a maximum at about {f1(an['glia_peak_age_median'])} years, and *SRRM4* declined from "
  f"mid-gestation to a minimum at {f1(an['trough_age_median'])} years (95% bootstrap interval "
  f"{ci(an['trough_age_CI'][0], an['trough_age_CI'][1], 1)}) before rising again through adulthood (postnatal Spearman "
  f"ρ = {f2(bs['SRRM4']['rho_postnatal_age'])}, *P* = {pf(bs['SRRM4']['p_postnatal_age'])}; Fig. 2a–e). The fitted "
  f"postnatal glial and *SRRM4* curves were strongly anti-correlated (*r* = {f2(an['curve_r'])}), although donor-level "
  f"uncertainty was wide (bootstrap 95% interval {ci(*an['curve_r_CI'])}; bootstrap *P* = {f2(an['P_boot_r_ge_0'])}). "
  "The observed *SRRM4* minimum coincided with the model's held-out prediction, and the observed glial maximum lay "
  f"within the model's predicted interval ({ci(gl['ctl_P_peak_age'][0], gl['ctl_P_peak_age'][2], 1)} years) (Fig. 2f). "
  "Normative development therefore places the nadir of the microexon regulator inside the epoch of maximal synaptic "
  "density and glial pruning, as the reciprocal loop requires.")
FIG(2, "Figure2_brainspan.png",
    "**Figure 2 | Normative cortical development (BrainSpan) and model-predicted timing.** **a–e**, Donor-level module "
    "scores (points; 42 donors, 362 neocortical samples) with LOWESS trajectories and 95% donor-bootstrap bands for the "
    "synaptic, activity-regulated, glial-pruning and neuronal-splicing modules and for *SRRM4*. The dashed line marks "
    "birth; Spearman correlations are for postnatal donors (*n* = 22). **f**, Observed ages of the postnatal *SRRM4* "
    "minimum and glial maximum (filled circles, bootstrap 95% intervals) compared with the model predictions, which were "
    "not used in calibration (open diamonds, posterior 95% intervals).")
H2("Glial-pruning transcripts are elevated in autistic cortex and diverge with age")
P(f"Across the three post-mortem cohorts, the glial-pruning module was increased in autism in every cohort "
  f"(*g* = {f2(g_coh['GSE28521']['g'])}, {f2(g_coh['GSE28475']['g'])} and {f2(g_coh['GSE102741']['g'])}) with no "
  f"between-cohort heterogeneity (pooled *g* = {f2(mG['est'])}, 95% CI {ci(mG['lo'], mG['hi'])}, *P* = {pf(mG['p'])}, "
  f"*I*^2^ = {pct(mG['I2'])}; Fig. 3a; Supplementary Table 1). The neuronal-splicing module showed a smaller, "
  f"non-significant decrease (*g* = {f2(mS['est'])}, {ci(mS['lo'], mS['hi'])}, *P* = {pf(mS['p'])}), driven by the "
  "largest-effect cohort (GSE28521). Adjustment for cell-composition markers attenuated both effects (glial "
  f"*g* = {f2(mGc['est'])}, *P* = {pf(mGc['p'])}; splicing *g* = {f2(mSc['est'])}), indicating that part of each "
  "signal reflects cellular composition, as expected for a reactive glial state and a neuron-enriched regulator set. "
  "In the cohort with ages (GSE102741), the autism effect on the glial module increased with age (diagnosis × log age, "
  f"*P* = {pf(ai['GLIA_PRUNE']['p_int'])}; *g* = {f2(ai['GLIA_PRUNE']['lt20']['g'])} before and "
  f"{f2(ai['GLIA_PRUNE']['ge20']['g'])} after 20 years), while activity-regulated genes were reduced in younger autistic "
  f"donors (*g* = {f2(ai['ACTIVITY_IEG']['lt20']['g'])}, *P* = {pf(ai['ACTIVITY_IEG']['lt20']['p'])}; interaction "
  f"*P* = {pf(ai['ACTIVITY_IEG']['p_int'])}) (Fig. 3c,d). The direction and age dependence of the glial change matched "
  "the model's held-out prediction of a reactive glial state that tracks accumulating synaptic excess.")
H2("Autistic brains are over-dispersed in the glia–splicing plane")
P("The pre-specified prediction of negative glia–splicing coupling across individuals was not supported (pooled "
  f"partial ρ = {f2(cp['all']['rho_pooled'])}, 95% CI {ci(cp['all']['lo'], cp['all']['hi'])}, *P* = {pf(cp['all']['p'])}); "
  f"coupling was positive in controls (ρ = {f2(cp['CTL']['rho_pooled'])}, *P* = {pf(cp['CTL']['p'])}) and absent in "
  f"autism (ρ = {f2(cp['ASD']['rho_pooled'])}). Instead, autistic brains were markedly over-dispersed in the "
  f"glia–splicing plane relative to controls (s.d. of glial *z* {f2(het['GLIA_PRUNE_zc']['sd_asd'])} versus "
  f"{f2(het['GLIA_PRUNE_zc']['sd_ctl'])}, Brown–Forsythe *P* = {pf(het['GLIA_PRUNE_zc']['p'])}; splicing "
  f"{f2(het['NEURO_SPLICE_zc']['sd_asd'])} versus {f2(het['NEURO_SPLICE_zc']['sd_ctl'])}, *P* = {pf(het['NEURO_SPLICE_zc']['p'])}; "
  f"radial distance *P* = {pf(het['radius']['p'])}) (Fig. 3b). A two-component mixture fitted the autistic distribution "
  f"better than a single Gaussian (ΔBIC = {het['gmm']['dBIC_1v2']:.0f}, bootstrap *P* = {pf(het['gmm']['p_boot'])}), "
  "and each cohort independently preferred two components. The minority component (about one in five autistic brains) "
  "combined strong splicing-regulator loss with glial elevation, whereas the majority lay close to the control "
  "distribution. Among strongly deviant autistic brains (radial *z* > 1.5), glia-dominant and splicing-dominant "
  f"deviations were equally common ({het['dominance']['glia_dominant']} versus {het['dominance']['splice_dominant']}). "
  "This pattern—no linear coupling, inflated dispersion and a minority in a joint deviant state—is what a mixture of "
  "entry routes into a shared positive-feedback loop predicts, and it is consistent with the convergent molecular "
  "subtype previously reported in a subset of autistic brains [@ramaswami,irimia].")
FIG(3, "Figure3_postmortem.png",
    "**Figure 3 | Validation in three independent post-mortem cortical cohorts and genetic loading.** **a**, Hedges' *g* "
    "(autism − control, 95% CI) for each a-priori module and for *SRRM4* and *CPEB4* in each cohort (grey) and pooled by "
    "random-effects meta-analysis (diamonds). **b**, Control-referenced glial-pruning and neuronal-splicing scores; the "
    "dashed circle marks a radial *z* of 1.5. **c,d**, Age dependence of the glial and activity-regulated modules in "
    "GSE102741 (lines, least-squares fits on log age). **e**, Enrichment of high-confidence SFARI genes (score 1–2) in "
    "splicing-arm, glial-arm and comparator gene sets (odds ratio, 95% CI; * a-priori modules; † Benjamini–Hochberg "
    "*q* < 0.05). Autism, *n* = 57; control, *n* = 84.")
H2("Genetic risk loads asymmetrically onto the splicing arm")
P(f"High-confidence SFARI genes were strongly over-represented among the a-priori neuronal splicing regulators "
  f"(odds ratio {f1(ns.OR)}, 95% CI {ci(ns.OR_lo, ns.OR_hi, 1)}, *q* = {pf(ns.q_BH)}; {int(ns.overlap)} of "
  f"{int(ns.n_term)} genes) and nominally in regulators of alternative splicing (odds ratio {f1(alt.OR)}, "
  f"*q* = {pf(alt.q_BH)}), whereas no glial-arm set survived correction (Fig. 3e). Strikingly, none of the "
  f"{int(sf1.n_term.sum())} glial-arm annotations contained a single score-1 gene. Synaptic transmission (odds ratio "
  f"{f1(syn.OR)}) and chromatin remodelling ({f1(chrm.OR)}) were enriched as expected. The glial arm therefore appears "
  "largely non-genetic, in agreement with the absence of GWAS signal in the immune–glial module of autistic cortex "
  "[@voineagu], implying that glia-first entry is predominantly environmental or immune, whereas splicing-first entry "
  "is the route most likely to carry rare-variant burden.")
H2("Convergent routes differ in the timing of microexon loss relative to the pruning epoch")
P("Both lesions produced indistinguishable spine trajectories, adolescent excesses and glial elevation (Fig. 1b,d), "
  "illustrating how distinct perturbations converge on one phenotype. They differed in timing (Fig. 4a,b). After a "
  "splicing-first lesion, microexon loss was present from birth in "
  f"{pct(es['frac_psi_deficit_at_birth_splice'])} of parameter sets and preceded the onset of spine excess by a median of "
  f"{f1(-es['splice_leadlag'][1])} years (95% interval {f1(-es['splice_leadlag'][2])}–{f1(-es['splice_leadlag'][0])}). "
  "After a glia-first lesion, microexon loss was never present at birth; it emerged at "
  f"{f1(es['glia_onset_psi'][1])} years, within the pruning epoch, only {f1(-es['glia_leadlag'][1])} years before the "
  f"spine excess crossed the same relative threshold. The lead–lag statistic discriminated the routes almost perfectly "
  f"(area under the curve {f2(es['auc_leadlag'])}; paired Wilcoxon *P* = {pf(es['wilcoxon_paired_p'])}; Fig. 4c). Global "
  "sensitivity analysis showed that the lead–lag was governed by the strength of the loop (refinement dependence φ~0~, "
  "activity half-repression *A*~h~, the microexon Hill coefficient *h* and glial reactivity λ; Fig. 4d). Across the full "
  "posterior range with fixed lesion size, splicing-first entry produced microexon loss before spine excess in "
  f"{pct(1 - sb['sobol']['splice']['P_leadlag_pos'])} of samples, whereas the sign for glia-first entry depended on loop "
  f"strength ({pct(sb['sobol']['glia']['P_leadlag_pos'])} positive), making the presence or absence of a perinatal "
  "microexon deficit the most robust discriminator. Adult fixed-point analysis revealed bistability in up to "
  f"{pct(max(sb['bistability']['glia']['frac_bistable_by_lesion'].values()))} of parameter sets near the fitted glial "
  "lesion range (Fig. 4e), indicating that some individuals sit close to a tipping point at which the loop locks into a "
  "high-synapse, low-microexon state. In adulthood, the two routes overlapped extensively in glial state and partly in "
  "microexon inclusion (Fig. 4f), so cross-sectional adult tissue cannot assign the route reliably.")
FIG(4, "Figure4_entry_signatures.png",
    "**Figure 4 | Convergent entry routes are distinguished by the timing of microexon loss.** **a,b**, Deviations from "
    "matched controls after glia-first (**a**) and splicing-first (**b**) lesions, each normalized to its maximum "
    "(posterior median and 10–90% band); the dotted line marks the 25% onset threshold. **c**, Posterior distribution of "
    "the lead–lag Δ = onset(ψ) − onset(*S*). **d**, Sobol total-order indices for Δ (eight most influential parameters). "
    "**e**, Fraction of posterior parameter sets with two stable adult fixed points as a function of lesion size; shaded "
    "bands mark the interquartile range of fitted lesions. **f**, Adult (20–30 years) glial state and microexon inclusion "
    "for each route.")
H2("Only normative-referenced trajectories with random intercepts locate the entry point")
P("In the in-silico cohort, single-wave classifiers distinguished autistic from control participants with increasing "
  f"accuracy across childhood (area under the curve {f2(cs['2']['auc_dx'])} at 2 years to {f2(cs['18']['auc_dx'])} at 18 "
  f"years) but distinguished the two entry routes only moderately at any single age ({f2(min(auc_cs))}–{f2(max(auc_cs))}; "
  "Fig. 5a). A classifier using all waves referenced to normative charts reached an area under the curve of "
  f"{f2(idn['long_supervised_internal_cv'])} on internal cross-validation and {f2(idn['long_supervised_external'])} in "
  "an independent cohort with systematic site shifts, demonstrating external transportability (Fig. 5a,b). The "
  "label-free onset-order rule assigned the route correctly in "
  f"{pct(idn['onset_rule_acc_A'])} of autistic participants in cohort A and {pct(idn['onset_rule_acc_B'])} in cohort B, "
  "whereas unsupervised Gaussian mixtures on the same longitudinal features failed to recover the routes (adjusted Rand "
  f"index {f2(idn['gmm_ARI_A'])} and {f2(idn['gmm_ARI_B'])}). Theory-agnostic clustering of multi-omic trajectories "
  "therefore cannot be expected to rediscover mechanistic routes without a model that specifies which temporal features "
  "matter. Across designs, accuracy depended more on including infancy and on measurement reliability than on the "
  f"total number of waves (Fig. 5c; for example {pct(dgm[('2 waves (8,16)', 0.29)])} with two mid-childhood waves at "
  f"reliability 0.29 versus {pct(dgm[('4 waves (2,6,10,14)', 0.9)])} with four waves from 2 years at reliability 0.9).")
P("Fitted to noise-free latent trajectories (3,000 participants per route), the RI-CLPM recovered reciprocal negative "
  f"cross-lagged effects in both routes—synaptic excess predicting later microexon loss (glia-first "
  f"{f2(lr['GLIA']['RI']['est']['b_xy'])}, splicing-first {f2(lr['SPLICE']['RI']['est']['b_xy'])}) and microexon loss "
  f"predicting later synaptic excess ({f2(lr['GLIA']['RI']['est']['b_yx'])} and {f2(lr['SPLICE']['RI']['est']['b_yx'])})"
  "—confirming that the loop operates in both directions regardless of where it was entered (Fig. 5d). The "
  "conventional CLPM attenuated these estimates and, in the pooled autistic group, nearly abolished the "
  f"synaptic-to-splicing path ({f2(lr['ASD']['CLPM']['est']['b_xy'])} versus {f2(lr['ASD']['RI']['est']['b_xy'])} with "
  "random intercepts), so a standard analysis would have concluded, wrongly, that causation runs only from splicing to "
  f"connectivity. The RI-CLPM also fitted far better (χ^2^ = {lr['ASD']['chi2_RI']:,.0f} versus "
  f"{lr['ASD']['chi2_CLPM']:,.0f} for 65 and 68 degrees of freedom). Cross-lagged coefficients thus quantify the loop, "
  "not the entry point; locating the entry point requires the onset of deviation from a normative reference.")
FIG(5, "Figure5_insilico_trial.png",
    "**Figure 5 | In-silico longitudinal trial of the proposed cohort design.** **a**, Cross-validated area under the "
    "curve for diagnosis and for entry route from a single assessment at each age, compared with an all-wave classifier "
    "applied to an external, site-shifted cohort (dashed). **b**, Mean normative *z* scores of the synaptic proxy and of "
    "microexon loss (−ψ) by route. **c**, Accuracy of the label-free onset-order rule across designs and reliabilities "
    "of the synaptic proxy (mean ± s.d., 20 replicates). **d**, Cross-lagged coefficients (95% CI) from RI-CLPM and CLPM "
    "fitted to latent trajectories (3,000 participants per route). **e,f**, Power to detect the synaptic-to-splicing "
    "(**e**) and splicing-to-synaptic (**f**) paths as a function of the number of autistic participants and reliability "
    "(solid, RI-CLPM; dotted, CLPM; dashed line, 80% power).")
H2("Early multimodal trajectories predict individual outcomes across sites and improve treatment allocation")
P("In the six-site trial, data collected between 2 and 6 years predicted the outcome at 18 years in held-out sites, "
  f"but modestly (Fig. 6a). With circuit burden explaining half of the outcome variance, external *R*^2^ was "
  f"{f2(pex(0.5, FA).R2_external)} for clinical predictors alone (95% CI {ci(pex(0.5, FA).lo, pex(0.5, FA).hi)}), "
  f"{f2(pex(0.5, FB).R2_external)} after adding neuroimaging ({ci(pex(0.5, FB).lo, pex(0.5, FB).hi)}) and "
  f"{f2(pex(0.5, FC).R2_external)} with the full multimodal set ({ci(pex(0.5, FC).lo, pex(0.5, FC).hi)}), about a "
  "quarter of the explainable variance. Neuroimaging therefore contributed most of the gain over clinical assessment, "
  "whereas omic read-outs added little to outcome prediction. Site-specific normative harmonization mattered when the "
  f"signal was strong (*R*^2^~B~ = 0.7: {f2(pex(0.7, FC).R2_external)} versus {f2(pex(0.7, FC, False).R2_external)} "
  "without harmonization). Prediction improved steadily as trajectories unfolded through the pruning epoch "
  f"(external *R*^2^ {f2(phv(6, FC))}, {f2(phv(8, FC))}, {f2(phv(10, FC))} and {f2(phv(12, FC))} with the last wave at "
  "6, 8, 10 and 12 years; Fig. 6b), indicating that individual prognosis should be updated at every wave rather than "
  "fixed at baseline. Learning curves plateaued at about 800 autistic training participants "
  f"(*R*^2^ {f2(plcm[(800, FC)])} at 800 versus {f2(plcm[(1200, FC)])} at 1,200; Fig. 6c).")
P("The value of the omic layer emerged in treatment allocation. With doses calibrated to be equipotent on average, "
  "the two hypothetical interventions benefited the routes differently (route × therapy interaction "
  f"*P* = {pf(ptj['heterogeneity']['interaction']['p'])}; Fig. 6d): splicing-first participants benefited more from "
  f"microexon restoration ({f2(ptj['heterogeneity']['SPLICE']['splice']['mean'])} versus "
  f"{f2(ptj['heterogeneity']['SPLICE']['glia']['mean'])} s.d.), and glia-first participants from glial therapy "
  f"({f2(ptj['heterogeneity']['GLIA']['glia']['mean'])} versus {f2(ptj['heterogeneity']['GLIA']['splice']['mean'])}). "
  "In held-out sites, allocating therapy with the label-free onset-order rule applied to the 2–6-year waves improved "
  f"mean benefit over the best single therapy by {gain['mean']:.3f} s.d. (95% CI {gain['lo']:.3f}–{gain['hi']:.3f}, "
  f"one-sided *P* = {pf(gain['p_one_sided'])}), and a multimodal model of differential benefit performed similarly "
  f"({alloc['Multimodal benefit model']:.3f} versus {alloc['Onset-order rule (waves 2-6 y)']:.3f}; Fig. 6e). These "
  f"strategies captured about {pct(gain['mean'] / oracle_gain)} of the gain available to an oracle, so early "
  "stratification is useful but leaves substantial individual uncertainty.")
FIG(6, "Figure6_prediction_allocation.png",
    "**Figure 6 | Multicentre in-silico trial of individual outcome prediction and treatment allocation.** **a**, "
    "External *R*^2^ (two held-out sites; bootstrap 95% CI) for predicting the 18-year outcome from 2–6-year data with "
    "clinical, clinical + imaging and full multimodal predictors, after site-specific normative harmonization (bars) or "
    "without it (horizontal ticks), for three assumed shares of outcome variance explained by circuit burden (dotted "
    "line, ceiling). **b**, External *R*^2^ as a function of the last observed wave. **c**, Learning curves (mean ± s.d., "
    "30 replicates). **d**, Mean individual benefit (reduction in circuit burden; 95% CI) of equipotent microexon-"
    "restoring and glial therapies by entry route. **e**, Mean benefit in held-out sites under alternative allocation "
    "strategies.")

H2("Design requirements for a definitive cohort")
P("With six biennial waves between 6 and 16 years, the RI-CLPM required "
  f"{nstr(nmin('RI-CLPM', 0.6, 'sig_xy'))} autistic participants for 80% power to detect the synaptic-to-splicing path "
  f"and {nstr(nmin('RI-CLPM', 0.6, 'sig_yx'))} for the splicing-to-synaptic path at a synaptic-proxy reliability of "
  f"0.6; detecting both required {nstr(both[0.29])} participants at a reliability of 0.29, typical of edge-level "
  f"functional connectivity, and {nstr(both[0.9])} at 0.9 (Fig. 5e,f; Table 4). The splicing-to-synaptic path was "
  "detectable with about 100–200 participants at every reliability, but measurement error attenuated the estimated "
  f"synaptic-to-splicing effect roughly ten-fold (mean estimate {f2(est_xy[0.29])} at reliability 0.29 versus "
  f"{f2(est_xy[0.9])} at 0.9), so that this arm of the loop—the one encoding the circuit-to-splicing direction—is the "
  "most vulnerable to being missed. The CLPM detected an attenuated version of this path only at large sample sizes "
  f"(estimate {f2(est_xy_clpm)} versus {f2(est_xy[0.6])} with random intercepts at reliability 0.6). "
  "These results translate into concrete requirements for the definitive cohort (Fig. 7; Table 4): enrolment before "
  "the pruning epoch (prenatal or neonatal, including high-likelihood siblings), at least one infant assessment of "
  "microexon state, synaptic measures with reliability of at least 0.6, normative charts from a concurrently recruited "
  "population sample, random-intercept cross-lagged analysis, and a harmonized external replication cohort.")
TAB(3, "Calibration targets, held-out predictions and their outcome.", ["Quantity", "Source", "Observed", "Model (95% interval)", "Use"], [], [2300, 1700, 1100, 2400, 1526])
TAB(4, "Design requirements derived from the in-silico trial.", ["Design element", "Recommendation", "Evidence from this study"], [], [2000, 3000, 4026])
FIG(7, "Figure7_design_blueprint.png",
    "**Figure 7 | Blueprint for a prospective, multimodal cohort able to locate the entry point of the loop.** "
    "Assessment waves start at birth so that a perinatal microexon deficit (splicing-first) can be distinguished from "
    "one acquired during the pruning epoch (glia-first). Each read-out is referenced to normative charts; the synaptic, "
    "microexon and glial measures are analysed with random-intercept cross-lagged models, genetic instruments provide "
    "Mendelian-randomization triangulation, and a harmonized external cohort provides independent validation. Example "
    "modalities are indicative and depend on age-appropriate feasibility.")

# =============================================================================
H1("Discussion")
P("The main contribution of this study is a quantitative blueprint for the prospective cohort that has been proposed "
  "as the definitive design for idiopathic autism. Rather than collecting every available layer and relying on "
  "unsupervised integration, we used a minimal mechanistic model as an instrument to specify what such a cohort must "
  "measure, when, with what reliability and in how many participants. Before using it in this way, we verified that "
  "the loop linking synaptic pruning, network activity, SRRM4-dependent microexon splicing and CPEB4 condensate "
  "reversibility reproduced independent observations in human brain data: the developmental decline of spine density, "
  "the timing of the postnatal *SRRM4* minimum, the microexon inclusion of autistic cortex, and the elevated, "
  "age-diverging glial-pruning signature of autistic brains. The same loop shows why distinct perturbations converge: "
  "entering through glial engulfment or through microexon splicing produces the same adolescent spine excess, the same "
  "glial elevation and, in some individuals, the same locked high-synapse, low-microexon state. Convergence, in this "
  "view, is a property of the shared circuit rather than of a shared upstream cause—and it is precisely why "
  "cross-sectional studies cannot assign individuals to routes.")
P("Framed as a population-level choice, the question of whether failed pruning alters splicing or altered splicing "
  "impairs pruning has limited value for stratification. In the calibrated model, and in the cross-lagged analysis of "
  "its trajectories, both directions operate in every individual. What differs between individuals is the entry point, "
  "and the entry point leaves a temporal fingerprint: a splicing-first route carries a microexon deficit before the "
  "pruning epoch, whereas a glia-first route acquires it during that epoch, after the circuit has begun to escape "
  "elimination. This individual-level framing connects the classical splicing-to-pruning view with the "
  "activity-to-splicing literature [@quesnel,krick,furlanis] and gives operational content to phase-based accounts of "
  "microglial causality [@gabr]. It also accommodates an apparent paradox in the post-mortem data: glial-pruning "
  "transcripts are increased in autistic cortex [@voineagu,gupta,morgan], yet the core anatomical finding is too little "
  "pruning [@tang]. A reactive glial state that tracks synaptic load predicts exactly this combination of more glial "
  "activity and less effective elimination, and it predicts the age divergence we observed.")
P("Several observations argue against simpler alternatives. A purely cell-autonomous splicing account does not easily "
  "explain why the glial signature grows with age, nor why the glial arm carries essentially no high-confidence genetic "
  "risk while the splicing arm is strongly loaded. A purely inflammatory account does not explain the microexon deficit "
  "or its quantitative match to the CPEB4 aggregation threshold. Neither account predicts the over-dispersed, partly "
  "bimodal distribution of autistic brains in the glia–splicing plane, which follows naturally from a mixture of entry "
  "routes into a positive-feedback system with a tipping point. The failed prediction of negative linear coupling is "
  "informative here: in a mixture of routes, deviations along the two axes need not covary linearly, whereas within "
  "controls the positive coupling may reflect shared cellular composition.")
P("For the definitive cohort, the prediction analyses temper expectations in an informative way. Early "
  "multimodal data predicted outcome at 18 years only modestly, because the circuit burden that drives the outcome "
  "accumulates during the pruning epoch, after the earliest waves. Individual prognosis should therefore be treated as "
  "a rolling estimate, updated as trajectories unfold, which matches the regulatory logic of qualifying biomarkers for "
  "a defined context of use [@griffin,mcpartland]. The analyses also clarify which layer earns its cost for which aim: "
  "neuroimaging carried most of the gain in outcome prediction, whereas the microexon and glial read-outs were what "
  "made mechanism-based treatment allocation possible. Finally, harmonization through site-specific normative charts "
  "and validation on held-out sites, rather than pooled cross-validation, were required for estimates that transport "
  "across centres—precisely the step that has been missing from previous neuroimaging and multi-omic findings "
  "[@parellada,holiga].")
P("The study has important limitations. The model is deliberately minimal: a single cortical compartment without "
  "excitatory–inhibitory structure, regional heterochrony or cell-type resolution, and with CPEB4 standing in for a "
  "broader activity-sensitive microexon programme [@irimia,gonatopoulos]. Most parameters were weakly identified, and "
  "the splicing-first route reproduced the adolescent excess in only a minority of posterior sets; conclusions rest on "
  "predictions that were robust across the posterior, not on point estimates. The model over-predicted the small "
  "childhood spine excess. The post-mortem cohorts are small, mostly adult and analysed with bulk expression, so glial "
  "abundance and activation cannot be separated, and age effects were testable in only one cohort of 13 autistic "
  "donors. Gene modules were defined a priori to avoid circularity, but they remain proxies, and SFARI curation may be "
  "biased towards neuronal genes. Finally, the in-silico trial assumes measurable in vivo proxies of microexon state; "
  "measuring neural microexon inclusion in accessible tissue (for example neural-derived extracellular vesicles or "
  "induced neurons) is a technical bottleneck that the definitive cohort must solve. The outcome model links "
  "adaptive outcome to circuit burden with an assumed strength, which we varied rather than estimated, and the "
  "interventions are hypothetical and dose-calibrated, so the allocation results establish feasibility, not efficacy. Mendelian randomization with "
  "splicing and cell-type-specific instruments [@qi,haglund,hao,hemani] should be added to triangulate the "
  "longitudinal inference.")
P("The framework makes testable predictions. First, a subset of autistic children should show reduced CPEB4 microexon "
  "inclusion at or soon after birth, enriched for rare damaging variants in splicing regulators, whereas a second subset "
  "should show normal perinatal inclusion that declines during early childhood, enriched for immune or environmental "
  "exposures. Second, glial-pruning markers in autism should rise with age in proportion to synaptic excess. Third, in "
  "typical development, CPEB4 condensate reversibility should be lowest during the early-childhood pruning peak, "
  "defining a window of vulnerability to further microexon loss. Fourth, in longitudinal data, RI-CLPM should detect "
  "bidirectional negative cross-lagged effects between synaptic and microexon measures in both subgroups, whereas "
  "conventional cross-lagged models should not. Fifth, interventions should be route-specific: microexon-restoring "
  "approaches, such as the me4-mimetic peptide that restores CPEB4 condensate reversibility [@garcia], should be most "
  "effective when started before the pruning epoch in splicing-first children, whereas modulation of glial engulfment "
  "should be most effective during the pruning epoch in glia-first children.")
P("More broadly, the work illustrates how a calibrated mechanistic model can serve as a design instrument. Rather than "
  "collecting every available layer in the hope that unsupervised integration will reveal biotypes—a strategy our "
  "simulations suggest is unlikely to recover mechanistic routes—the model specifies which variables, at which ages, "
  "with what reliability and in how many participants a cohort must be measured to adjudicate between explicit causal "
  "hypotheses. This converts the long-standing search for the cause of idiopathic autism into a falsifiable question "
  "about where, and when, each individual enters a shared loop.")

H1("Conclusions")
P("A prospective, multicentre cohort able to stratify idiopathic autism and predict individual outcomes must be "
  "designed around explicit mechanistic hypotheses. Using a minimal pruning–splicing loop calibrated to the literature "
  "and validated against held-out developmental and post-mortem data, we show that distinct entry routes converge on a "
  "shared synaptic and glial phenotype and differ chiefly in when microexon loss appears relative to the pruning epoch. "
  "Real data supported key elements: glial-pruning transcripts were elevated and age-divergent across three cohorts, "
  "autistic brains were over-dispersed in the glia–splicing plane, and genetic risk loaded onto the splicing arm. In a "
  "six-site in-silico trial, normative-referenced trajectories beginning in infancy identified entry routes in held-out "
  "sites, early data predicted later outcomes modestly but improved with each wave, neuroimaging drove outcome "
  "prediction while omic read-outs enabled better treatment allocation, and random-intercept models with adequately "
  "reliable measures and several hundred participants were required. These results provide a falsifiable framework "
  "and a concrete blueprint for the definitive cohort.")

H1("CRediT authorship contribution statement")
P("**[AUTHOR]**: Conceptualization, Methodology, Software, Formal analysis, Investigation, Data curation, Validation, "
  "Visualization, Writing – original draft, Writing – review & editing. [Add co-authors and roles as applicable.]")
H1("Ethics Statement")
P("This study used only publicly available, de-identified data (BrainSpan atlas, NCBI Gene Expression Omnibus series "
  "GSE28521, GSE28475 and GSE102741, SFARI Gene and Gene Ontology) and published summary values. The original studies "
  "obtained ethical approval and informed consent as described in their publications. No new human or animal data were "
  "collected, and no additional ethical approval was required.")
H1("Funding")
P("[FUNDING: state grant numbers and funders, or 'This research received no specific grant from any funding agency in "
  "the public, commercial, or not-for-profit sectors.']")
H1("Declaration of Competing Interest")
P("The author(s) declare no competing interests. [Confirm or amend.]")
H1("Data Availability Statement")
P("All input data are publicly available: BrainSpan RNA-seq (https://www.brainspan.org), GEO series GSE28521, GSE28475 "
  "and GSE102741 and platform GPL6883 (https://www.ncbi.nlm.nih.gov/geo), SFARI Gene (https://gene.sfari.org) and the "
  "Enrichr GO Biological Process 2023 library (https://maayanlab.cloud/Enrichr). All code, processed data, posterior "
  "samples, simulation outputs and figure source files are available at [GITHUB URL] and archived at Zenodo "
  "[DOI: 10.5281/zenodo.XXXXXXX] under the MIT licence (code) and CC BY 4.0 (derived data). A single script "
  "(run_all.sh) downloads the raw data and regenerates every number, table and figure.")
H1("Declaration of Generative AI and AI-Assisted Technologies in the Writing Process")
P("During the preparation of this work the author(s) used Claude (Anthropic) to assist with code development, "
  "literature verification, data analysis and drafting of the manuscript. After using this tool, the author(s) "
  "reviewed and edited the content as needed and take full responsibility for the content of the publication.")

# ---------------- tables ------------------------------------------------------
meaning = {
 "tau_s": ("Synaptogenesis time scale (y)", "Huttenlocher 1997; Petanjek 2011"),
 "a_s": ("Synaptogenesis pulse shape", "Petanjek 2011"),
 "sig_amp": ("Synaptogenesis pulse amplitude (× maintenance)", "Petanjek 2011 (2–3× overshoot)"),
 "t_m": ("Glial maturation midpoint (y)", "Paolicelli 2011; Schafer 2012"),
 "w_m": ("Glial maturation width (y)", "Schafer 2012"),
 "d_m": ("Late decline of glial programme", "BrainSpan (this study)"),
 "kP": ("Pruning rate constant (y⁻¹)", "Tang 2014"),
 "k0_frac": ("Baseline turnover share", "Tang 2014 (autophagy-dependent elimination)"),
 "tauP": ("Glial state time constant (y)", "Badimon 2020"),
 "lam": ("Glial reactivity to synaptic load λ", "Schafer 2012; Badimon 2020"),
 "Ah": ("Activity for half-repression of SRRM4", "Quesnel-Vallières 2016"),
 "n": ("Hill coefficient, activity → SRRM4", "Quesnel-Vallières 2016"),
 "h": ("Hill coefficient, SRRM4 → me4", "Irimia 2014 (switch-like microexons)"),
 "tauR": ("SRRM4 time constant (y)", "Quesnel-Vallières 2016 (rapid)"),
 "taupsi": ("Microexon relaxation time (y)", "Irimia 2014"),
 "phi0": ("Refinement efficacy without reversible CPEB4 φ~0~", "Parras 2018; Garcia-Cabau 2025"),
 "eta": ("Activity–synapse exponent η", "Zhan 2014"),
}
sym = {"tau_s": "τ~s~", "a_s": "*a*", "sig_amp": "*a*~σ~", "t_m": "*t*~m~", "w_m": "*w*~m~", "d_m": "*d*~m~",
       "kP": "*k*~P~", "k0_frac": "*f*~0~", "tauP": "τ~P~", "lam": "λ", "Ah": "*A*~h~", "n": "*n*", "h": "*h*",
       "tauR": "τ~R~", "taupsi": "τ~ψ~", "phi0": "φ~0~", "eta": "η"}
rows1 = []
for _, r in par.iterrows():
    m, src = meaning[r.param]
    rows1.append([sym[r.param], m, f"{r.prior_lo:g}–{r.prior_hi:g}", f"{r.post_med:.2f} ({r.post_lo:.2f}–{r.post_hi:.2f})", src])
rows1 += [["χ*", "CPEB4 aggregation threshold (fixed)", "0.375", "—", "Garcia-Cabau 2025"],
          ["*w*~χ~", "Sigmoid width (fixed)", "0.035", "—", "Garcia-Cabau 2025"],
          ["ψ~ad~", "Adult control me4 inclusion (fixed)", "0.70", "—", "Garcia-Cabau 2025"]]
for b in B:
    if b["type"] == "table" and b["n"] == 2:
        b["rows"] = rows1
        b["note"] = ("Posterior from ABC rejection (600 of 60,000 prior samples). Fixed constants were taken directly from "
                     "the literature. CrI, credible interval.")
rows3 = [
 ["Spine density, child/adolescent (control)", "Tang 2014", "1.82", f"{ci(*cal['child_over_adol']['post_95'])}", "Fitted"],
 ["Peak/adult spine density", "Petanjek 2011", "2–3", f"{ci(*cal['peak_over_adult']['post_95'])}", "Fitted"],
 ["Age of peak synaptic density (y)", "Huttenlocher 1997", "> 1.25", f"{f1(cal['peak_age_post'][1])} ({ci(cal['peak_age_post'][0], cal['peak_age_post'][2], 1)})", "Fitted"],
 ["Adult control me4 inclusion", "Garcia-Cabau 2025", "0.70", f"{f2(cal['psi_ctl_post'][1])} ({ci(cal['psi_ctl_post'][0], cal['psi_ctl_post'][2])})", "Fitted"],
 ["Adolescent spine excess, ASD/control", "Tang 2014", "1.66", "1.66 (by construction)", "Lesion fit"],
 ["Childhood spine excess, ASD/control", "Tang 2014", "1.08", f"{f2(gl['child_ratio'][1])} ({ci(gl['child_ratio'][0], gl['child_ratio'][2])})", "Held out (over-predicted)"],
 ["Adult ASD me4 inclusion", "Garcia-Cabau 2025", "0.55", f"{f2(gl['psi_asd'][1])} ({ci(gl['psi_asd'][0], gl['psi_asd'][2])})", "Held out (matched)"],
 ["Age of SRRM4 minimum (y)", "BrainSpan", f"{f1(an['trough_age_median'])} ({ci(*an['trough_age_CI'], 1)})", f"{f1(gl['ctl_R_trough_age'][1])} ({ci(gl['ctl_R_trough_age'][0], gl['ctl_R_trough_age'][2], 1)})", "Held out (matched)"],
 ["Age of glial maximum (y)", "BrainSpan", f"{f1(an['glia_peak_age_median'])} (wide)", f"{f1(gl['ctl_P_peak_age'][1])} ({ci(gl['ctl_P_peak_age'][0], gl['ctl_P_peak_age'][2], 1)})", "Held out (consistent)"],
 ["Glial state in ASD (direction, age trend)", "Three GEO cohorts", f"g = {f2(mG['est'])}; increases with age", f"×{f2(gl['P_ratio_child'][1])} child → ×{f2(gl['P_ratio_adult'][1])} adult", "Held out (matched)"],
]
rows4 = [
 ["Enrolment", "Prenatal or neonatal, before the pruning epoch", f"Single-wave route AUC ≤ {f2(max(auc_cs))}; perinatal ψ deficit present in {pct(es['frac_psi_deficit_at_birth_splice'])} of splicing-first vs 0% of glia-first trajectories"],
 ["Waves", "≥ 4, including infancy (≈ 2 y) and spanning 2–16 y", f"Onset-rule accuracy {pct(dgm[('4 waves (2,6,10,14)', 0.6)])} (4 waves from 2 y) vs {pct(dgm[('2 waves (8,16)', 0.6)])} (2 mid-childhood waves) at reliability 0.6"],
 ["Read-outs", "Synaptic/connectivity, microexon (CPEB4 me4) and glial state in the same individuals", "Routes are defined by the relative timing of synaptic and microexon deviations"],
 ["Reliability", "Synaptic proxy ICC ≥ 0.6 (avoid edge-level fMRI alone)", f"Participants for 80% power on both paths: {nstr(both[0.29])} at ICC 0.29 vs {nstr(both[0.6])} at 0.6"],
 ["Reference", "Concurrent population sample for site-specific normative charts", "Entry route is identified by onset of deviation from normative trajectories"],
 ["Analysis", "RI-CLPM (not CLPM); theory-guided onset features (not unsupervised clustering alone)", f"CLPM synaptic→splicing estimate {f2(lr['ASD']['CLPM']['est']['b_xy'])} vs RI-CLPM {f2(lr['ASD']['RI']['est']['b_xy'])}; GMM ARI {f2(idn['gmm_ARI_A'])}"],
 ["Validation", "Harmonized external cohort with independent site", f"External AUC {f2(idn['long_supervised_external'])} despite site shifts"],
 ["Genetics", "Whole-genome sequencing; splicing and cell-type sQTL instruments for MR triangulation", f"Splicing arm enriched for SFARI genes (OR {f1(ns.OR)}); glial arm not"],
 ["Individual prediction", "Rolling prognosis updated at every wave; neuroimaging as core predictor", f"External R² {f2(phv(6, FC))} (to 6 y) → {f2(phv(12, FC))} (to 12 y); imaging adds {f2(pex(0.5, FB).R2_external - pex(0.5, FA).R2_external)} over clinical"],
 ["Multicentre harmonization", "Site-specific normative charts from concurrently recruited controls", f"External R² {f2(pex(0.7, FC).R2_external)} vs {f2(pex(0.7, FC, False).R2_external)} without harmonization (R²~B~ = 0.7)"],
 ["Sample size", f"≥ {nstr(both[0.6])} autistic participants for causal inference; ≈ 800 for prediction", "Power of RI-CLPM; plateau of learning curves"],
 ["Treatment allocation", "Embed route-stratified intervention arms (microexon vs glial)", f"Rule-based allocation +{gain['mean']:.3f} s.d. over best single therapy (P = {pf(gain['p_one_sided'])})"],
]
for b in B:
    if b["type"] == "table" and b["n"] == 3:
        b["rows"] = rows3; b["note"] = "Model values are posterior medians (95% intervals) over parameter sets in which the route reproduced the adolescent excess."
    if b["type"] == "table" and b["n"] == 4:
        b["rows"] = rows4; b["note"] = "AUC, area under the receiver-operating-characteristic curve; ICC, intraclass correlation; MR, Mendelian randomization; OR, odds ratio."

# Table 1 (data sources) inserted at the start of Methods
rows2 = [
 ["BrainSpan RNA-seq", "Normative neocortex, 8 pcw–40 y", "42 donors / 362 samples", "Developmental trajectories; held-out timing", "Kang 2011; Miller 2014"],
 ["GSE28521", "Frontal + temporal cortex (Illumina)", "16 ASD / 16 CTL", "Validation cohort 1", "Voineagu 2011"],
 ["GSE28475", "Prefrontal cortex (DASL)", "28 ASD / 29 CTL", "Validation cohort 2", "Chow 2012"],
 ["GSE102741", "DLPFC RNA-seq; age 2–68 y", "13 ASD / 39 CTL", "Validation cohort 3; age interaction", "Wright 2017"],
 ["SFARI Gene", "Curated autism risk genes", "957 score 1–2", "Genetic loading", "Abrahams 2013"],
 ["GO BP 2023 (Enrichr)", "Gene Ontology sets", "14,698 genes", "Background and arm definitions", "—"],
 ["Literature values", "Spine density, me4 inclusion, reliability", "—", "Calibration and measurement model", "Tang 2014; Petanjek 2011; Garcia-Cabau 2025; Noble 2019"],
]
idx = next(i for i, b in enumerate(B) if b["type"] == "h2" and b["text"].startswith("Study design"))
B.insert(idx + 2, dict(type="table", n=1, caption="Public data sources and their role in the study.",
                       header=["Resource", "Content", "Size", "Role", "Reference"], rows=rows2,
                       widths=[1500, 2200, 1500, 2100, 1726],
                       note="ASD, autism spectrum disorder; CTL, control; DLPFC, dorsolateral prefrontal cortex; pcw, post-conceptional weeks."))
# move the parameter table (Table 2) to just after the priors paragraph
t2 = next(b for b in B if b["type"] == "table" and b["n"] == 2); B.remove(t2)
idx = next(i for i, b in enumerate(B) if b["type"] == "h2" and b["text"].startswith("Priors"))
B.insert(idx + 2, t2)
# Table 3 is first cited in the opening Results subsection: place it there,
# directly after Figure 1, instead of at the end of the Results.
t3 = next(b for b in B if b["type"] == "table" and b["n"] == 3); B.remove(t3)
idx = next(i for i, b in enumerate(B) if b["type"] == "fig" and b["n"] == 1)
B.insert(idx + 1, t3)

# ---------------- citations: number in order of first appearance -------------
refs = json.load(open(ROOT / "docs" / "refs_verified.json"))
order = []
def repl(m):
    keys = [k.strip() for k in m.group(1).split(",")]
    nums = []
    for k in keys:
        if k not in refs:
            raise KeyError(k)
        if k not in order:
            order.append(k)
        nums.append(order.index(k) + 1)
    nums = sorted(set(nums)); out = []; i = 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
            j += 1
        out.append(f"{nums[i]}–{nums[j]}" if j - i >= 2 else ",".join(str(x) for x in nums[i:j + 1]))
        i = j + 1
    return "^" + ",".join(out) + "^"
for b in B:
    for k in ("text", "caption"):
        if k in b:
            b[k] = re.sub(r"\[@([^\]]+)\]", repl, b[k])
# table 'Basis' columns cite by name only (no numbers) -> fine

def fmt_ref(k):
    r = refs[k]; au = r["authors"]
    a = ", ".join(au[:6]) + (", et al." if (len(au) > 6 or r.get("etal")) else "")
    pages = r["pages"] or ""
    vol = r["vol"] if r["vol"] not in (None, "None") else ""
    issue = f"({r['issue']})" if r.get("issue") and r["issue"] not in ("None",) else ""
    title = r["title"].rstrip(".")
    j = r["journal"].replace(".", "")
    s = f"{a}. {title}. {j}. {r['year']}"
    if vol:
        s += f";{vol}{issue}:{pages}"
    elif pages:
        s += f":{pages}"
    s += f". doi:{r['doi']}"
    return s

REFS = [fmt_ref(k) for k in order]
json.dump(dict(title=TITLE, abstract=ABSTRACT, keywords=KEYWORDS, blocks=B, references=REFS,
               ref_keys=order), open(ROOT / "docs" / "manuscript.json", "w"), indent=1, ensure_ascii=False)
print("references:", len(REFS), "| abstract words:", len(re.sub(r"[*^~]", "", ABSTRACT).split()))
print("uncited verified refs:", sorted(set(refs) - set(order)))
