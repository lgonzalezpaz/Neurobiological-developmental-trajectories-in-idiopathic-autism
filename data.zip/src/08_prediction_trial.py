"""Multicentre in-silico trial of individual outcome prediction and treatment allocation.

Implements the primary end-point of the proposed definitive cohort: prediction of
each child's developmental outcome, and of the response to route-specific
intervention, from early longitudinal multimodal data, with leave-sites-out
external validation.

Design
------
* 6 sites; each site has its own case mix (fraction of splicing-first entry
  30-70%), additive measurement biases and modality reliabilities.
* Waves at 2, 4 and 6 years are 'observed'; the outcome is measured at 18 years.
* Read-outs: clinical/behavioural severity (K), synaptic/connectivity imaging (C),
  microexon state (PSI) and glial state (G).
* Outcome (adaptive function at 18 y, Y) = -(latent circuit burden L) + e, where L
  integrates synaptic excess and microexon loss between 8 and 18 years relative
  to control trajectories. The share of outcome variance explained by L (R2_L) is
  an explicit, varied assumption (0.3, 0.5, 0.7).
* Counterfactual interventions (6-14 y): microexon-restoring therapy (SRRM4
  production x1.3) or glial therapy (engulfment efficacy x1.3), simulated with
  identical stochastic paths, so that individual benefit is known exactly.
Analyses: (A) external R2 of ridge models with nested feature sets, with and
without site-specific normative harmonization; (B) learning curve; (C)
route-by-treatment heterogeneity and the gain from allocating therapy by the
early onset-order rule or by a model of individual benefit.
"""
import json
import numpy as np, pandas as pd
from sklearn.linear_model import RidgeCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
from model import simulate_stoch, PARAM_NAMES
from config import RES, PROC, SEED

POST = pd.read_csv(RES / "abc_posterior.csv").dropna(subset=["d_glia", "d_splice"]).reset_index(drop=True)
WAVES = (2, 4, 6)
N_SITES, N_ASD, N_CTL = 6, 300, 150
REL = dict(K=0.7, C=0.6, PSI=0.8, G=0.7)


def build_population(rng):
    rows = []
    for s in range(N_SITES):
        f_splice = 0.3 + 0.4 * s / (N_SITES - 1)                 # case-mix shift across sites
        n_sp = int(round(N_ASD * f_splice))
        grp = ["CTL"] * N_CTL + ["SPLICE"] * n_sp + ["GLIA"] * (N_ASD - n_sp)
        for g in grp:
            rows.append(dict(site=s, group=g))
    pop = pd.DataFrame(rows)
    n = len(pop)
    idx = rng.integers(0, len(POST), n)
    j = np.exp(rng.normal(0, 0.25, n))
    pop["post_idx"] = idx
    pop["dG"] = np.where(pop.group == "GLIA", np.clip(POST.d_glia.values[idx] * j, 0, 0.95), 0.0)
    pop["dS"] = np.where(pop.group == "SPLICE", np.clip(POST.d_splice.values[idx] * j, 0, 0.95), 0.0)
    return pop


def run(pop, seed, interv=None):
    p = {k: POST[k].values[pop.post_idx.values] for k in PARAM_NAMES}
    return simulate_stoch(p, pop.dG.values, pop.dS.values, rng=np.random.default_rng(seed),
                          t_end=18.5, interv=interv)


def latent_at(res, ages):
    ii = np.array([np.argmin(np.abs(res["t"] - a)) for a in ages])
    lp = np.clip(res["psi"][:, ii], 1e-4, 1 - 1e-4)
    return dict(C=np.log(res["S"][:, ii]), PSI=np.log(lp / (1 - lp)), G=np.log(res["P"][:, ii]))


def _lat18(res):
    m = (res["t"] >= 8) & (res["t"] <= 18)
    lp = np.clip(res["psi"][:, m], 1e-4, 1 - 1e-4)
    return np.log(res["S"][:, m]), np.log(lp / (1 - lp))


def burden(res, ref):
    """Latent circuit burden 8-18 y: synaptic excess + microexon loss, in z units of the
    UNTREATED control distribution (ref = base run, control mask)."""
    lS, lP = _lat18(res)
    zS = (lS - ref["muS"]) / ref["sdS"]
    # outcome burden is defined at the circuit level (synaptic excess) only, so that
    # neither therapy acts on the outcome definition directly
    return zS.mean(1)


def observe(lat, pop, rng, site_par):
    obs = {}
    for k in ("C", "PSI", "G", "K"):
        X = (-(lat["C"] - lat["C"].mean(0)) / lat["C"].std(0) + (lat["PSI"] - lat["PSI"].mean(0)) / lat["PSI"].std(0)) / 2 \
            if k == "K" else lat[k]
        out = np.empty_like(X)
        for s in range(N_SITES):
            m = pop.site.values == s
            r = site_par[s]["rel"][k]
            vb = X.var(0, keepdims=True)
            out[m] = X[m] + rng.normal(size=X[m].shape) * np.sqrt(vb * (1 - r) / r) + site_par[s]["bias"][k]
        obs[k] = out
    return obs


def harmonize(obs, pop, site_specific=True):
    z = {}
    ctl = pop.group.values == "CTL"
    for k, X in obs.items():
        Z = np.empty_like(X)
        if site_specific:
            for s in range(N_SITES):
                m = pop.site.values == s
                mu, sd = X[m & ctl].mean(0), X[m & ctl].std(0)
                Z[m] = (X[m] - mu) / sd
        else:
            Z = (X - X[ctl].mean(0)) / X[ctl].std(0)
        z[k] = Z
    return z


FEATS = {"Clinical": ["K"], "Clinical + imaging": ["K", "C"],
         "Clinical + imaging + omics": ["K", "C", "PSI", "G"]}


def design(z, keys):
    cols = [z[k] for k in keys]
    X = np.hstack(cols)
    # slopes (trajectory features)
    X = np.hstack([X] + [c[:, -1:] - c[:, :1] for c in cols])
    return X


def onset_rule(z, thr=1.0):
    devC, devP = z["C"], -z["PSI"]
    T = devC.shape[1]
    first = lambda D: np.where((D >= thr).any(1), np.argmax(D >= thr, 1), T)
    fC, fP = first(devC), first(devP)
    return np.where(fP < fC, "SPLICE", np.where(fC < fP, "GLIA",
                    np.where(devP.sum(1) > devC.sum(1), "SPLICE", "GLIA")))


def main():
    rng = np.random.default_rng(SEED + 8)
    pop = build_population(rng)
    asd = pop.group.values != "CTL"; ctl = ~asd
    site_par = {s: dict(bias={k: rng.normal(0, 0.3) for k in REL},
                        rel={k: float(np.clip(REL[k] + rng.normal(0, 0.1), 0.35, 0.95)) for k in REL})
                for s in range(N_SITES)}
    sim_seed = SEED + 80
    base = run(pop, sim_seed)
    # interventions given to autistic participants only (mask), 6-14 y
    lS0, lP0 = _lat18(base)
    ref = dict(muS=lS0[ctl].mean(0), sdS=lS0[ctl].std(0), muP=lP0[ctl].mean(0), sdP=lP0[ctl].std(0))
    L0 = burden(base, ref)
    mask = asd.astype(float)
    tx = {"splice": run(pop, sim_seed, dict(kind="splice", t0=6.0, t1=14.0, size=0.3, mask=mask))}
    target = (L0 - burden(tx["splice"], ref))[asd].mean()
    # equipotent glial dose: bisection so that mean ASD benefit equals that of microexon therapy
    lo_, hi_ = 0.0, 3.0
    for it in range(12):
        mid = 0.5 * (lo_ + hi_)
        gl_run = run(pop, sim_seed, dict(kind="glia", t0=6.0, t1=14.0, size=mid, mask=mask))
        bm = (L0 - burden(gl_run, ref))[asd].mean()
        lo_, hi_ = (mid, hi_) if bm < target else (lo_, mid)
    tx["glia"] = gl_run
    glia_dose = mid
    Lt = {k: burden(v, ref) for k, v in tx.items()}
    # sanity check: identical stochastic paths -> controls unchanged by masked interventions
    out_check = {k: float(np.abs(Lt[k][ctl] - L0[ctl]).max()) for k in tx}
    lat = latent_at(base, WAVES)
    obs = observe(lat, pop, rng, site_par)
    out = {"control_invariance_check": out_check, "glia_equipotent_dose": glia_dose,
           "design": dict(n_sites=N_SITES, n_asd_per_site=N_ASD, n_ctl_per_site=N_CTL, waves=WAVES,
                          site_par={str(s): v for s, v in site_par.items()})}

    # ---------- (A) external prediction of outcome --------------------------
    train_sites, test_sites = [0, 1, 3, 5], [2, 4]
    tr = asd & np.isin(pop.site.values, train_sites); te = asd & np.isin(pop.site.values, test_sites)
    res_rows = []
    for r2L in (0.3, 0.5, 0.7):
        e_sd = np.sqrt(L0[asd].var() * (1 - r2L) / r2L)
        e = rng.normal(0, e_sd, len(pop))
        Y = -L0 + e
        for harm in (True, False):
            z = harmonize(obs, pop, site_specific=harm)
            for name, keys in FEATS.items():
                X = design(z, keys)
                sc = StandardScaler().fit(X[tr])
                m = RidgeCV(alphas=np.logspace(-2, 3, 20)).fit(sc.transform(X[tr]), Y[tr])
                pred = m.predict(sc.transform(X[te]))
                # bootstrap CI of external R2
                bs = []
                yt = Y[te]
                for b in range(500):
                    ii = rng.integers(0, len(yt), len(yt)); bs.append(r2_score(yt[ii], pred[ii]))
                res_rows.append(dict(R2_latent=r2L, harmonized=harm, features=name,
                                     R2_external=r2_score(yt, pred),
                                     lo=np.percentile(bs, 2.5), hi=np.percentile(bs, 97.5),
                                     ceiling=r2L))
    pred_df = pd.DataFrame(res_rows)
    pred_df.to_csv(RES / "prediction_external.csv", index=False)

    # ---------- (B) learning curve (R2_L = 0.5, harmonized, all features) --
    e = rng.normal(0, np.sqrt(L0[asd].var()), len(pop)); Y = -L0 + e
    z = harmonize(obs, pop, True)
    lc = []
    tr_idx = np.where(tr)[0]
    for n in (50, 100, 200, 400, 800, 1200):
        for rep in range(30):
            ii = rng.choice(tr_idx, min(n, len(tr_idx)), replace=False)
            for name, keys in FEATS.items():
                X = design(z, keys)
                sc = StandardScaler().fit(X[ii])
                m = RidgeCV(alphas=np.logspace(-2, 3, 20)).fit(sc.transform(X[ii]), Y[ii])
                lc.append(dict(n_train=n, rep=rep, features=name,
                               R2_external=r2_score(Y[te], m.predict(sc.transform(X[te])))))
    pd.DataFrame(lc).to_csv(RES / "prediction_learning_curve.csv", index=False)

    # ---------- (B2) prediction horizon: last observed wave -------------------
    hz = []
    for last in (6, 8, 10, 12):
        wv = tuple(range(2, last + 1, 2))
        lat_h = latent_at(base, wv)
        obs_h = observe(lat_h, pop, rng, site_par)
        z_h = harmonize(obs_h, pop, True)
        for name, keys in FEATS.items():
            X = design(z_h, keys)
            sc = StandardScaler().fit(X[tr])
            m = RidgeCV(alphas=np.logspace(-2, 3, 20)).fit(sc.transform(X[tr]), Y[tr])
            hz.append(dict(last_wave=last, features=name, R2_external=r2_score(Y[te], m.predict(sc.transform(X[te])))))
    pd.DataFrame(hz).to_csv(RES / "prediction_horizon.csv", index=False)
    out["ceiling_R2_L_for_horizon"] = 0.5

    # ---------- (C) treatment heterogeneity and allocation ------------------
    ben = {k: (L0 - Lt[k]) for k in tx}          # reduction in burden = benefit (z units)
    g = pop.group.values
    het = {}
    for grp in ("GLIA", "SPLICE"):
        m = g == grp
        het[grp] = {k: dict(mean=float(ben[k][m].mean()), sd=float(ben[k][m].std()),
                            frac_benefit_gt_0p2=float((ben[k][m] > 0.2).mean())) for k in tx}
    # interaction test (route x therapy), ASD only
    import statsmodels.formula.api as smf
    d = pd.DataFrame({"route": np.r_[g[asd], g[asd]], "therapy": ["splice"] * asd.sum() + ["glia"] * asd.sum(),
                      "benefit": np.r_[ben["splice"][asd], ben["glia"][asd]]})
    fit = smf.ols("benefit ~ C(route) * C(therapy)", d).fit()
    key = [k for k in fit.params.index if ":" in k][0]
    het["interaction"] = dict(beta=float(fit.params[key]), p=float(fit.pvalues[key]))
    best_true = np.where(ben["splice"] > ben["glia"], "splice", "glia")
    # allocation strategies evaluated in external sites
    zz = harmonize(obs, pop, True)
    route_hat = onset_rule(zz)
    alloc_rule = np.where(route_hat == "SPLICE", "splice", "glia")
    # model of individual differential benefit trained on training sites
    X = design(zz, FEATS["Clinical + imaging + omics"])
    sc = StandardScaler().fit(X[tr])
    diff = ben["splice"] - ben["glia"]
    mdl = RidgeCV(alphas=np.logspace(-2, 3, 20)).fit(sc.transform(X[tr]), diff[tr])
    alloc_model = np.where(mdl.predict(sc.transform(X)) > 0, "splice", "glia")
    def realized(alloc, mask):
        return float(np.where(alloc[mask] == "splice", ben["splice"][mask], ben["glia"][mask]).mean())
    one_best = "splice" if ben["splice"][tr].mean() > ben["glia"][tr].mean() else "glia"
    strat = {
        "Everyone: glial therapy": realized(np.array(["glia"] * len(pop)), te),
        "Everyone: microexon therapy": realized(np.array(["splice"] * len(pop)), te),
        "Random allocation": float(0.5 * (ben["splice"][te].mean() + ben["glia"][te].mean())),
        "Onset-order rule (waves 2-6 y)": realized(alloc_rule, te),
        "Multimodal benefit model": realized(alloc_model, te),
        "Oracle (true best)": realized(best_true, te),
    }
    acc = dict(rule=float(np.mean(alloc_rule[te] == best_true[te])),
               model=float(np.mean(alloc_model[te] == best_true[te])),
               rule_route_accuracy=float(np.mean(route_hat[te] == g[te])))
    # bootstrap CI for gain of rule over best single therapy
    te_idx = np.where(te)[0]; gains = []
    best_single = max(strat["Everyone: glial therapy"], strat["Everyone: microexon therapy"])
    single = "glia" if strat["Everyone: glial therapy"] >= strat["Everyone: microexon therapy"] else "splice"
    for b in range(2000):
        ii = rng.choice(te_idx, len(te_idx))
        r = np.where(alloc_rule[ii] == "splice", ben["splice"][ii], ben["glia"][ii]).mean()
        s_ = ben[single][ii].mean()
        gains.append(r - s_)
    out.update(heterogeneity=het, allocation=strat, allocation_accuracy=acc,
               gain_rule_vs_best_single=dict(mean=float(np.mean(gains)), lo=float(np.percentile(gains, 2.5)),
                                             hi=float(np.percentile(gains, 97.5)),
                                             p_one_sided=float(np.mean(np.array(gains) <= 0))),
               best_single_therapy=single)
    json.dump(out, open(RES / "prediction_trial.json", "w"), indent=1, default=float)
    pd.DataFrame({"site": pop.site, "group": g, "benefit_splice": ben["splice"], "benefit_glia": ben["glia"],
                  "route_hat": route_hat, "alloc_rule": alloc_rule, "alloc_model": alloc_model,
                  "burden": L0}).to_csv(PROC / "prediction_trial_individuals.csv.gz", index=False)
    print(pred_df.round(3).to_string())
    print(json.dumps({k: out[k] for k in ("heterogeneity", "allocation", "allocation_accuracy", "gain_rule_vs_best_single")}, indent=1))


if __name__ == "__main__":
    main()
