"""Three independent post-mortem ASD cortex cohorts: harmonised module scores.

Cohorts (GEO):  GSE28521 (Voineagu 2011; frontal+temporal cortex, Illumina),
                GSE28475 (Chow 2012; prefrontal cortex, frozen DASL subset),
                GSE102741 (Wright 2017; DLPFC RNA-seq, with age/sex/RIN).
Output: per-individual module scores (z, within cohort) + covariates.
"""
import gzip, re
import numpy as np, pandas as pd
from config import RAW, PROC, MODULES

CELL_PROXY = {  # cell-composition proxies, disjoint from the modules
    "NEURON": ["SLC17A7", "GAD1", "GAD2", "STMN2", "NEFL", "NEFM", "VSNL1", "SST"],
    "ASTRO": ["GFAP", "AQP4", "SLC1A3", "ALDH1L1", "SLC1A2"],
    "OLIGO": ["MBP", "MOBP", "PLP1", "MOG", "MAG"],
}
GENES = sorted(set(sum(MODULES.values(), [])) | set(sum(CELL_PROXY.values(), []))
               | {"CPEB4", "SRRM4"})


def read_series(f):
    meta, rows, inside = {}, [], False
    with gzip.open(f, "rt") as fh:
        for line in fh:
            if line.startswith("!series_matrix_table_begin"):
                inside = True; continue
            if line.startswith("!series_matrix_table_end"):
                break
            if inside:
                rows.append(line.rstrip("\n").split("\t"))
            elif line.startswith("!Sample_"):
                p = line.rstrip("\n").split("\t"); k = p[0]
                while k in meta:
                    k += "_"
                meta[k] = [x.strip('"') for x in p[1:]]
    hdr = [x.strip('"') for x in rows[0]]
    df = pd.DataFrame(rows[1:], columns=hdr).set_index("ID_REF")
    df.index = df.index.str.strip('"')
    df = df.apply(pd.to_numeric, errors="coerce")
    return pd.DataFrame(meta), df


def ilmn_symbols():
    lines = [l for l in gzip.open(RAW / "GPL6883.annot.gz", "rt")
             if not l.startswith(("#", "!", "^"))]
    from io import StringIO
    a = pd.read_csv(StringIO("".join(lines)), sep="\t", low_memory=False)
    a = a[a.columns[:3]]; a.columns = ["ID", "title", "symbol"]
    return a.dropna().set_index("ID").symbol


def quantile_norm(X):
    r = X.rank(axis=0, method="first").astype(int) - 1
    srt = np.sort(X.values, axis=0).mean(1)
    return pd.DataFrame(srt[r.values], index=X.index, columns=X.columns)


def collapse(X, sym):
    s = sym.reindex(X.index)
    X = X[s.notna()]; X.index = s[s.notna()].values
    X = X[X.index.isin(GENES)]
    # keep the most-expressed probe per gene
    X = X.assign(_m=X.mean(1)).sort_values("_m", ascending=False)
    return X[~X.index.duplicated()].drop(columns="_m")


def scores(X, meta):
    Z = X.sub(X.mean(1), axis=0).div(X.std(1) + 1e-9, axis=0)
    out = meta.copy()
    for name, gl in {**MODULES, **CELL_PROXY}.items():
        g = [x for x in gl if x in Z.index]
        out[name] = Z.loc[g].mean(0).reindex(out.index).values
        out[name + "_ngenes"] = len(g)
    for g in ["CPEB4", "SRRM4"]:
        out[g] = Z.loc[g].reindex(out.index).values if g in Z.index else np.nan
    return out


def gse28521(sym):
    m, X = read_series(RAW / "GSE28521_series_matrix.txt.gz")
    meta = pd.DataFrame({"gsm": m["!Sample_geo_accession"],
                         "title": m["!Sample_title"],
                         "dx": m["!Sample_characteristics_ch1"].str.contains("autism").map({True: "ASD", False: "CTL"}),
                         "region": m["!Sample_characteristics_ch1_"].str.split(": ").str[1]})
    meta = meta[~meta.region.str.contains("Cerebellum")]
    meta["subject"] = meta.title.str.split("_").str[1]
    X = collapse(X[meta.gsm], sym)
    # average frontal + temporal per subject (cortex)
    X.columns = meta.subject.values
    X = X.T.groupby(level=0).mean().T
    md = meta.groupby("subject").agg(dx=("dx", "first"), n_regions=("region", "nunique"))
    md["cohort"] = "GSE28521"
    return scores(X, md)


def gse28475(sym):
    m, X = read_series(RAW / "GSE28475-GPL6883_series_matrix.txt.gz")
    meta = pd.DataFrame({"gsm": m["!Sample_geo_accession"], "title": m["!Sample_title"]})
    ch = m[[c for c in m.columns if "characteristics" in c]].agg("|".join, axis=1)
    keep = ch.str.contains("Frozen") & ch.str.contains("DASL")
    meta = meta[keep.values].copy()
    meta["dx"] = np.where(ch[keep].str.contains("Autism").values, "ASD", "CTL")
    meta["subject"] = "C" + meta.title.str.extract(r"DASL_(\d+)")[0]  # A/B blocks of one donor collapsed
    Xs = X[meta.gsm].clip(lower=1.0)
    Xs = np.log2(quantile_norm(Xs))
    Xs = collapse(Xs, sym)
    Xs.columns = meta.subject.values
    Xs = Xs.T.groupby(level=0).mean().T
    md = meta.groupby("subject").agg(dx=("dx", "first"))
    md["cohort"] = "GSE28475"
    return scores(Xs, md)


def gse102741():
    m, _ = read_series(RAW / "GSE102741_series_matrix.txt.gz")
    ch = {c: m[c] for c in m.columns if "characteristics" in c}
    def field(key):
        for v in ch.values():
            if v.str.lower().str.startswith(key).all():
                return v.str.split(": ", n=1).str[1]
    md = pd.DataFrame({"title": m["!Sample_title"],
                       "dx": np.where(field("disease").str.contains("ASD"), "ASD", "CTL"),
                       "age": pd.to_numeric(field("age")),
                       "sex": field("sex"), "rin": pd.to_numeric(field("rin"))})
    md.index = ["sample%d" % (i + 1) for i in range(len(md))]
    X = pd.read_excel(RAW / "GSE102741_log2RPKMcounts.xlsx", index_col=0)
    rows = pd.read_csv(RAW / "brainspan" / "rows_metadata.csv")
    sym = rows.drop_duplicates("ensembl_gene_id").set_index("ensembl_gene_id").gene_symbol
    X = collapse(X, sym)
    md["cohort"] = "GSE102741"
    return scores(X[md.index], md)


def main():
    sym = ilmn_symbols()
    parts = [gse28521(sym), gse28475(sym), gse102741()]
    df = pd.concat(parts)
    df.index.name = "subject"
    df.to_csv(PROC / "postmortem_module_scores.csv")
    print(df.groupby(["cohort", "dx"]).size())
    print(df.filter(like="_ngenes").groupby(df.cohort).first().T)


if __name__ == "__main__":
    main()
