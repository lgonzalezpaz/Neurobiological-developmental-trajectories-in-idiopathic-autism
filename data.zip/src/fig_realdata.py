"""Figures 2 and 3: normative development (BrainSpan) and post-mortem ASD cohorts."""
import json
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from config import PROC, RES, COL, MOD_LABEL, style, save

style()
AGE_TICKS = [-0.4, 0, 1, 5, 20, 40]
AGE_LAB = ["20 pcw", "birth", "1 y", "5 y", "20 y", "40 y"]


def age2x(a):
    return np.log10(np.asarray(a) * 365.25 + 280.0)


def fig2():
    d = pd.read_csv(PROC / "brainspan_donor_module_scores.csv")
    t = pd.read_csv(RES / "brainspan_trajectories.csv")
    tim = json.load(open(RES / "brainspan_timing.json"))
    post = pd.read_csv(RES / "abc_posterior.csv")
    fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.3))
    panels = [("SYNAPSE", "a"), ("ACTIVITY_IEG", "b"), ("GLIA_PRUNE", "c"),
              ("NEURO_SPLICE", "d"), ("SRRM4", "e")]
    for ax, (f, lab) in zip(axs.flat, panels):
        c = COL.get(f, COL["splice"])
        ax.scatter(d.log_pc_days, d[f], s=7, color=c, alpha=0.55, lw=0)
        ax.plot(t.log_pc_days, t[f], color=c)
        ax.fill_between(t.log_pc_days, t[f + "_lo"], t[f + "_hi"], color=c, alpha=0.18, lw=0)
        ax.axvline(age2x(0), color="0.6", lw=0.6, ls="--")
        ax.set_xticks(age2x(AGE_TICKS)); ax.set_xticklabels(AGE_LAB, rotation=40, ha="right")
        ax.set_ylabel("Module score (z)")
        ax.set_title(MOD_LABEL.get(f, f), loc="left", fontweight="bold")
        ax.text(-0.22, 1.08, lab, transform=ax.transAxes, fontsize=9, fontweight="bold")
        rho, p = tim[f]["rho_postnatal_age"], tim[f]["p_postnatal_age"]
        ax.text(0.98, 0.04, f"postnatal ρ = {rho:.2f}\nP = {p:.2g}", transform=ax.transAxes,
                ha="right", va="bottom", fontsize=5.5)
    # panel f: model-emergent timing vs observed
    ax = axs.flat[5]
    obs = tim["antiphase_GLIA_vs_SRRM4"]
    items = [("SRRM4 trough\n(observed)", obs["trough_age_median"], obs["trough_age_CI"], COL["splice"]),
             ("SRRM4 trough\n(model, held out)", None, None, COL["splice"]),
             ("Glial peak\n(observed)", obs["glia_peak_age_median"], obs["glia_peak_age_CI"], COL["glia"]),
             ("Glial peak\n(model, held out)", None, None, COL["glia"])]
    mR = post.ctl_R_trough_age.dropna(); mP = post.ctl_P_peak_age.dropna()
    items[1] = (items[1][0], mR.median(), list(mR.quantile([0.025, 0.975])), COL["splice"])
    items[3] = (items[3][0], mP.median(), list(mP.quantile([0.025, 0.975])), COL["glia"])
    for i, (nm, m, ci, c) in enumerate(items):
        y = 3 - i
        ax.plot(ci, [y, y], color=c, lw=1.4)
        ax.plot(m, y, "o" if "observed" in nm else "D", color=c, ms=4,
                mfc="white" if "model" in nm else c)
    ax.set_yticks([3, 2, 1, 0]); ax.set_yticklabels([x[0] for x in items], fontsize=5.5)
    ax.set_xscale("symlog", linthresh=1); ax.set_xlim(-0.1, 45)
    ax.set_xlabel("Postnatal age (years)")
    ax.set_title("Timing: data vs model", loc="left", fontweight="bold")
    ax.text(-0.22, 1.08, "f", transform=ax.transAxes, fontsize=9, fontweight="bold")
    fig.tight_layout()
    save(fig, "Figure2_brainspan")


def fig3():
    eff = pd.read_csv(RES / "postmortem_dx_effects.csv")
    st = json.load(open(RES / "postmortem_stats.json"))
    Z = pd.read_csv(PROC / "postmortem_control_referenced.csv", index_col=0)
    df = pd.read_csv(PROC / "postmortem_module_scores.csv", index_col=0)
    sf = pd.read_csv(RES / "sfari_go_enrichment.csv")
    fig = plt.figure(figsize=(7.2, 5.6))
    gs = fig.add_gridspec(2, 3, height_ratios=[1, 1], hspace=0.6, wspace=0.75)
    # a forest
    ax = fig.add_subplot(gs[0, 0])
    feats = ["GLIA_PRUNE", "NEURO_SPLICE", "ACTIVITY_IEG", "SYNAPSE", "SRRM4", "CPEB4"]
    cohorts = ["GSE28521", "GSE28475", "GSE102741", "META"]
    y = 0; yt, yl = [], []
    for f in feats[::-1]:
        for c in cohorts[::-1]:
            r = eff[(eff.feature == f) & (eff.cohort == c)].iloc[0]
            col = COL.get(f, COL["splice"]) if c == "META" else "0.55"
            mk = "D" if c == "META" else "o"
            ax.plot([r.g - 1.96 * r.se, r.g + 1.96 * r.se], [y, y], color=col, lw=1.2 if c == "META" else 0.7)
            ax.plot(r.g, y, mk, color=col, ms=3.5 if c == "META" else 2.5)
            y += 1
        yt.append(y - 2.5); yl.append(MOD_LABEL.get(f, f)); y += 0.8
    ax.axvline(0, color="0.3", lw=0.6)
    ax.set_yticks(yt); ax.set_yticklabels(yl)
    ax.set_xlabel("Hedges' g (ASD − control)")
    ax.set_title("Diagnosis effects", loc="left", fontweight="bold")
    m = st["meta"]["GLIA_PRUNE"]
    ax.text(0.5, -0.30, f"glial-pruning meta-analysis: P = {m['p']:.3f}, I² = {m['I2']:.0%}\n(grey: single cohorts; diamonds: random-effects)", transform=ax.transAxes, fontsize=5.3, va="top", ha="center")
    ax.text(-0.45, 1.05, "a", transform=ax.transAxes, fontsize=9, fontweight="bold")
    # b plane
    ax = fig.add_subplot(gs[0, 1:])
    ctl = Z[Z.dx == "CTL"]; asd = Z[Z.dx == "ASD"]
    th = np.linspace(0, 2 * np.pi, 200)
    ax.plot(1.5 * np.cos(th), 1.5 * np.sin(th), color="0.6", lw=0.6, ls="--")
    mk = {"GSE28521": "o", "GSE28475": "s", "GSE102741": "^"}
    for c, mm in mk.items():
        a = ctl[ctl.cohort == c]; b = asd[asd.cohort == c]
        ax.scatter(a.GLIA_PRUNE_zc, a.NEURO_SPLICE_zc, s=10, marker=mm, color=COL["ctrl"], alpha=0.35, lw=0)
        ax.scatter(b.GLIA_PRUNE_zc, b.NEURO_SPLICE_zc, s=14, marker=mm, color=COL["asd"], alpha=0.85, edgecolor="k", lw=0.3)
    ax.axhline(0, color="0.8", lw=0.5); ax.axvline(0, color="0.8", lw=0.5)
    ax.set_xlabel("Glial-pruning score (control-referenced z)")
    ax.set_ylabel("Neuronal-splicing score (z)")
    h = st["heterogeneity"]
    ax.set_title("ASD dispersion in the glia–splicing plane", loc="left", fontweight="bold")
    ax.text(0.99, 0.99, f"radial dispersion ASD vs CTL: Brown–Forsythe P = {h['radius']['p']:.4f}\n"
            f"2- vs 1-component GMM: ΔBIC = {h['gmm']['dBIC_1v2']:.0f}, bootstrap P = {h['gmm']['p_boot']:.3f}",
            transform=ax.transAxes, ha="right", va="top", fontsize=5.5)
    leg = [Line2D([], [], marker=mm, ls="", color="0.4", label=c, ms=4) for c, mm in mk.items()]
    leg += [Line2D([], [], marker="o", ls="", color=COL["ctrl"], alpha=0.5, label="Control", ms=4),
            Line2D([], [], marker="o", ls="", color=COL["asd"], mec="k", label="ASD", ms=4)]
    ax.legend(handles=leg, loc="lower left", frameon=False, ncol=2)
    ax.text(-0.12, 1.05, "b", transform=ax.transAxes, fontsize=9, fontweight="bold")
    # c age interaction (GSE102741)
    d = df[df.cohort == "GSE102741"]
    for i, f in enumerate(["GLIA_PRUNE", "ACTIVITY_IEG"]):
        ax = fig.add_subplot(gs[1, i])
        for dx, c in (("CTL", COL["ctrl"]), ("ASD", COL["asd"])):
            s = d[d.dx == dx]
            ax.scatter(s.age, s[f], s=10, color=c, alpha=0.7, lw=0.3, edgecolor="k" if dx == "ASD" else "none", label=dx)
            b = np.polyfit(np.log(s.age), s[f], 1)
            xx = np.geomspace(s.age.min(), s.age.max(), 50)
            ax.plot(xx, np.polyval(b, np.log(xx)), color=c)
        ax.set_xscale("log"); ax.set_xlabel("Age at death (years)"); ax.set_ylabel("Module score (z)")
        from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
        ax.xaxis.set_major_locator(FixedLocator([2, 5, 10, 20, 50])); ax.xaxis.set_major_formatter(FixedFormatter(["2", "5", "10", "20", "50"]))
        ax.xaxis.set_minor_locator(NullLocator())
        ai = st["age_interaction_GSE102741"][f]
        ax.set_title(f"{MOD_LABEL[f]} × age", loc="left", fontweight="bold")
        ax.text(0.02, 0.98, f"dx × log(age): P = {ai['p_int']:.3f}", transform=ax.transAxes, va="top", fontsize=5.5)
        if i == 0:
            ax.legend(frameon=False, loc="lower right")
        ax.text(-0.3, 1.05, "cd"[i], transform=ax.transAxes, fontsize=9, fontweight="bold")
    # e SFARI enrichment
    ax = fig.add_subplot(gs[1, 2])
    s = sf[sf.sfari_set == "SFARI score 1-2"].copy()
    lab = {"A-priori NEURO_SPLICE module": "Neuronal splicing regulators*",
           "A-priori GLIA_PRUNE module": "Glial pruning module*",
           "Regulation Of Alternative mRNA Splicing, Via Spliceosome (GO:0000381)": "Reg. alternative mRNA splicing",
           "Regulation Of mRNA Splicing, Via Spliceosome (GO:0048024)": "Reg. mRNA splicing",
           "mRNA Splicing, Via Spliceosome (GO:0000398)": "mRNA splicing (spliceosome)",
           "Regulation Of Microglial Cell Activation (GO:1903978)": "Reg. microglial activation",
           "Regulation Of Complement Activation (GO:0030449)": "Reg. complement activation",
           "Microglial Cell Activation (GO:0001774)": "Microglial activation",
           "Phagocytosis, Engulfment (GO:0006911)": "Phagocytosis, engulfment",
           "Chemical Synaptic Transmission (GO:0007268)": "Chemical synaptic transmission",
           "Chromatin Remodeling (GO:0006338)": "Chromatin remodelling"}
    s["lab"] = [lab.get(t, t.split(" (GO")[0]) for t in s.term]
    s = s.sort_values(["arm", "OR"])
    colmap = {"Splicing arm": COL["splice"], "Glial arm": COL["glia"], "Comparator": "0.45"}
    for i, (_, r) in enumerate(s.iterrows()):
        ax.plot([r.OR_lo, r.OR_hi], [i, i], color=colmap[r.arm], lw=1)
        ax.plot(r.OR, i, "o", color=colmap[r.arm], ms=3)
        if r.q_BH < 0.05:
            ax.text(r.OR_hi * 1.15, i, "†", va="center", fontsize=6)
    ax.set_xscale("log"); ax.axvline(1, color="0.3", lw=0.6)
    ax.set_yticks(range(len(s))); ax.set_yticklabels(list(s.lab), fontsize=5.2)
    ax.set_xlabel("Odds ratio (SFARI score 1–2)")
    ax.set_title("SFARI loading", loc="left", fontweight="bold")
    fig.text(0.672, 0.455, "e", fontsize=9, fontweight="bold")
    save(fig, "Figure3_postmortem")


if __name__ == "__main__":
    fig3()
    fig2()
