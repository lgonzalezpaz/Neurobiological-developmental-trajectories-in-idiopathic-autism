"""ABC-rejection calibration of the PSR model + lesion fitting.

Calibration targets (human post-mortem literature):
  Tang et al. 2014 (layer V temporal cortex, spines/10 um):
     control child (2-9 y) 11.37, adolescent (13-20 y) 6.24 -> ratio 1.822
     ASD child 12.32, adolescent 10.33 -> ASD/CTL 1.084 (child), 1.655 (adolescent)
  Petanjek et al. 2011: childhood spine density 2-3x adult; remodelling
     continues into the third decade (stabilisation ~30 y).
  Huttenlocher & Dabholkar 1997: PFC synaptic density peaks after 15 months.
  Garcia-Cabau et al. 2025: chi_Delta4 0.30 (control) vs 0.45 (ASD).
Held-out (not used in fitting): BrainSpan SRRM4 trough age and glial peak age;
ASD child ratio; ASD microexon inclusion (psi = 0.55); direction and age-
dependence of the glial-state change in ASD.
"""
import json
import numpy as np, pandas as pd
from model import sample_prior, simulate, summaries, PARAM_NAMES, onset_age
from config import RES, PROC, SEED

N_PRIOR, N_ACCEPT = 60000, 600
TGT = dict(child_over_adol=11.37 / 6.24, peak_over_adult=2.5,
           asd_child=12.32 / 11.37, asd_adol=10.33 / 6.24, psi_asd=0.55)


def distance(s):
    d = (np.log(s["child_over_adol"] / TGT["child_over_adol"]) / 0.10) ** 2
    d += (np.log(s["peak_over_adult"] / TGT["peak_over_adult"]) / np.log(1.5)) ** 2
    d += (np.clip(1.25 - s["peak_age"], 0, None) / 0.5) ** 2 + (np.clip(s["peak_age"] - 5, 0, None) / 0.5) ** 2
    d += (np.log(s["stab_25_30"]) / 0.05) ** 2
    d += ((s["psi_ctl_adult"] - 0.70) / 0.02) ** 2
    return d


def fit_lesion(p, kind, grid=np.linspace(0, 0.9, 46)):
    """Per parameter set, smallest lesion matching ASD adolescent ratio 1.655."""
    n = p["kP"].size
    ctl = simulate(p)
    rat = np.empty((grid.size, n)); child = np.empty_like(rat); psi = np.empty_like(rat)
    for j, g in enumerate(grid):
        les = simulate(p, dG=g if kind == "glia" else 0.0, dS=g if kind == "splice" else 0.0)
        s = summaries(ctl, les)
        rat[j], child[j], psi[j] = s["asd_adol_ratio"], s["asd_child_ratio"], s["psi_asd_adult"]
    best = np.full(n, np.nan)
    for i in range(n):
        ok = np.where(rat[:, i] >= TGT["asd_adol"])[0]
        if ok.size:
            j = ok[0]
            if j == 0:
                best[i] = 0.0; continue
            # linear interpolation between grid points
            x0, x1 = grid[j - 1], grid[j]; y0, y1 = rat[j - 1, i], rat[j, i]
            best[i] = x0 + (TGT["asd_adol"] - y0) * (x1 - x0) / (y1 - y0)
    return best, dict(grid=grid, rat=rat, child=child, psi=psi)


def main():
    rng = np.random.default_rng(SEED)
    chunks = []
    for c in range(N_PRIOR // 10000):
        p = sample_prior(10000, rng)
        s = summaries(simulate(p, record=("S", "psi")))
        df = pd.DataFrame(p); df["dist"] = distance(s)
        for k, v in s.items():
            df["sum_" + k] = v
        chunks.append(df); print("prior chunk", c, flush=True)
    prior = pd.concat(chunks, ignore_index=True)
    prior.to_csv(PROC / "abc_prior_samples.csv.gz", index=False)
    post = prior.nsmallest(N_ACCEPT, "dist").reset_index(drop=True)
    p = {k: post[k].values for k in PARAM_NAMES}

    # lesions
    out = {}
    for kind in ("glia", "splice"):
        best, aux = fit_lesion(p, kind)
        post["d_" + kind] = best
        ok = ~np.isnan(best)
        les = simulate({k: v[ok] for k, v in p.items()},
                       dG=np.where(kind == "glia", best[ok], 0.0),
                       dS=np.where(kind == "splice", best[ok], 0.0),
                       record=("S", "P", "R", "psi"))
        ctl = simulate({k: v[ok] for k, v in p.items()}, record=("S", "P", "R", "psi"))
        s = summaries(ctl, les)
        t = ctl["t"]
        tS = onset_age(t, les["S"] / ctl["S"] - 1)
        tpsi = onset_age(t, ctl["psi"] - les["psi"])
        tP = onset_age(t, les["P"] / ctl["P"] - 1)
        from model import window_mean
        post0 = (t >= 0)
        Rtr = t[post0][np.argmin(ctl["R"][:, post0], 1)]
        Ppk = t[post0][np.argmax(ctl["P"][:, post0], 1)]
        Pr_child = window_mean(les, "P", 2, 9) / window_mean(ctl, "P", 2, 9)
        Pr_adol = window_mean(les, "P", 13, 20) / window_mean(ctl, "P", 13, 20)
        Pr_adult = window_mean(les, "P", 25, 40) / window_mean(ctl, "P", 25, 40)
        post.loc[ok, "ctl_R_trough_age"] = Rtr
        post.loc[ok, "ctl_P_peak_age"] = Ppk
        post.loc[ok, f"{kind}_P_child"] = Pr_child
        post.loc[ok, f"{kind}_P_adol"] = Pr_adol
        post.loc[ok, f"{kind}_P_adult"] = Pr_adult
        post.loc[ok, f"{kind}_child_ratio"] = s["asd_child_ratio"]
        post.loc[ok, f"{kind}_adol_ratio"] = s["asd_adol_ratio"]
        post.loc[ok, f"{kind}_psi_asd"] = s["psi_asd_adult"]
        post.loc[ok, f"{kind}_onset_S"] = tS
        post.loc[ok, f"{kind}_onset_psi"] = tpsi
        post.loc[ok, f"{kind}_leadlag"] = tpsi - tS
        out[kind] = dict(n_fit=int(ok.sum()), frac_fit=float(ok.mean()),
                         lesion=np.percentile(best[ok], [2.5, 50, 97.5]).tolist(),
                         child_ratio=np.percentile(s["asd_child_ratio"], [2.5, 50, 97.5]).tolist(),
                         psi_asd=np.percentile(s["psi_asd_adult"], [2.5, 50, 97.5]).tolist(),
                         onset_S=np.percentile(tS, [2.5, 50, 97.5]).tolist(),
                         onset_psi=np.percentile(tpsi, [2.5, 50, 97.5]).tolist(),
                         leadlag=np.percentile(tpsi - tS, [2.5, 50, 97.5]).tolist(),
                         P_leadlag_pos=float(np.mean(tpsi - tS > 0)),
                         P_ratio_child=np.percentile(Pr_child, [2.5, 50, 97.5]).tolist(),
                         P_ratio_adol=np.percentile(Pr_adol, [2.5, 50, 97.5]).tolist(),
                         P_ratio_adult=np.percentile(Pr_adult, [2.5, 50, 97.5]).tolist(),
                         ctl_R_trough_age=np.percentile(Rtr, [2.5, 50, 97.5]).tolist(),
                         ctl_P_peak_age=np.percentile(Ppk, [2.5, 50, 97.5]).tolist())
    post.to_csv(RES / "abc_posterior.csv", index=False)
    # prior-predictive coverage
    cov = {}
    for k, tv in [("child_over_adol", TGT["child_over_adol"]), ("peak_over_adult", 2.5)]:
        v = prior["sum_" + k]
        cov[k] = dict(prior_pct_of_target=float((v < tv).mean() * 100),
                      prior_95=np.nanpercentile(v, [2.5, 97.5]).tolist(),
                      post_95=np.percentile(post["sum_" + k], [2.5, 97.5]).tolist())
    cov["peak_age_post"] = np.percentile(post.sum_peak_age, [2.5, 50, 97.5]).tolist()
    cov["psi_ctl_post"] = np.percentile(post.sum_psi_ctl_adult, [2.5, 50, 97.5]).tolist()
    cov["accept_rate"] = N_ACCEPT / N_PRIOR
    cov["max_accepted_dist"] = float(post.dist.max())
    out["calibration"] = cov
    json.dump(out, open(RES / "abc_summary.json", "w"), indent=1)
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
