"""Global sensitivity (Sobol) and adult fixed-point (bistability) analysis.

Sobol: parameters varied over their posterior 2.5-97.5% ranges; lesion size
fixed at the posterior median for each route; outputs = lead-lag (onset of
psi deviation minus onset of S deviation), adolescent S ratio, adult psi.
Fixed points: the adult quasi-steady map S = sigma_b / (k0 + kP eps P(S) Phi(S))
is solved on a fine grid; bistability = >1 stable fixed point.
"""
import json
import numpy as np, pandas as pd
from SALib.sample import sobol as sobol_sample
from SALib.analyze import sobol as sobol_analyze
from model import (simulate, summaries, onset_age, derived, F_of_psi, PARAM_NAMES)
from config import RES, SEED


def sobol_part(post, N=256):
    lo = post[PARAM_NAMES].quantile(0.025); hi = post[PARAM_NAMES].quantile(0.975)
    prob = dict(num_vars=len(PARAM_NAMES), names=PARAM_NAMES,
                bounds=[[lo[k], hi[k] + 1e-9] for k in PARAM_NAMES])
    X = sobol_sample.sample(prob, N, calc_second_order=False, seed=SEED)
    p = {k: X[:, i] for i, k in enumerate(PARAM_NAMES)}
    ctl = simulate(p, record=("S", "psi"))
    out = {}
    for kind, col in (("glia", "d_glia"), ("splice", "d_splice")):
        dlev = float(post[col].median())
        les = simulate(p, dG=dlev if kind == "glia" else 0.0,
                       dS=dlev if kind == "splice" else 0.0, record=("S", "psi"))
        s = summaries(ctl, les)
        t = ctl["t"]
        ll = onset_age(t, ctl["psi"] - les["psi"]) - onset_age(t, les["S"] / ctl["S"] - 1)
        Ys = dict(leadlag=ll, adol_ratio=s["asd_adol_ratio"], psi_adult=s["psi_asd_adult"])
        out[kind] = {"lesion_fixed": dlev,
                     "P_leadlag_pos": float(np.mean(ll > 0)),
                     "leadlag_pct": np.percentile(ll, [2.5, 50, 97.5]).tolist()}
        for nm, Y in Ys.items():
            Y = np.nan_to_num(Y, nan=np.nanmedian(Y))
            Si = sobol_analyze.analyze(prob, Y, calc_second_order=False, seed=SEED)
            out[kind][nm] = {"S1": dict(zip(PARAM_NAMES, Si["S1"])),
                             "ST": dict(zip(PARAM_NAMES, Si["ST"])),
                             "ST_conf": dict(zip(PARAM_NAMES, Si["ST_conf"]))}
    out["N_base"] = N; out["n_sims_per_condition"] = int(X.shape[0])
    return out


def fixed_points(row, eps=1.0, r0=1.0, grid=np.geomspace(0.2, 8, 4000)):
    p = {k: np.array([row[k]]) for k in PARAM_NAMES}
    d = derived(p)
    S = grid
    A = S ** row["eta"]
    R = r0 / (1 + (A / row["Ah"]) ** row["n"])
    psi = R ** row["h"] / (R ** row["h"] + d["Kpsi"][0] ** row["h"])
    Phi = row["phi0"] + (1 - row["phi0"]) * F_of_psi(psi)
    P = (1 - row["d_m"]) * S ** row["lam"]
    G = d["sig_b"][0] / (d["k0"][0] + row["kP"] * eps * P * Phi) - S
    sgn = np.sign(G); idx = np.where(np.diff(sgn) != 0)[0]
    fps = S[idx]
    stable = [S[i] for i in idx if G[i] > 0 > G[i + 1]]    # G decreasing through 0
    return fps, stable, psi[idx]


def bistability(post, n_grid=41):
    lev = np.linspace(0, 0.9, n_grid)
    rows = []
    for _, r in post.iterrows():
        for kind in ("glia", "splice"):
            for L in lev:
                fps, st, ps = fixed_points(r, eps=1 - L if kind == "glia" else 1.0,
                                           r0=1 - L if kind == "splice" else 1.0)
                rows.append(dict(kind=kind, lesion=L, n_stable=len(st),
                                 S_low=min(st) if st else np.nan, S_high=max(st) if st else np.nan))
    df = pd.DataFrame(rows)
    df.to_csv(RES / "bistability_scan.csv", index=False)
    summ = {}
    for kind, d in df.groupby("kind"):
        summ[kind] = {"frac_bistable_any_lesion": float(d.groupby(d.index // n_grid).n_stable.max().gt(1).mean()),
                      "frac_bistable_by_lesion": d.groupby("lesion").n_stable.apply(lambda x: float((x > 1).mean())).to_dict()}
    summ["frac_bistable_control"] = float(df[(df.lesion == 0)].groupby("kind").n_stable.apply(lambda x: (x > 1).mean()).mean())
    return summ


def main():
    post = pd.read_csv(RES / "abc_posterior.csv").dropna(subset=["d_glia", "d_splice"])
    out = {"sobol": sobol_part(post)}
    out["bistability"] = bistability(post)
    json.dump(out, open(RES / "sensitivity_bistability.json", "w"), indent=1, default=float)
    for kind in ("glia", "splice"):
        o = out["sobol"][kind]
        print(kind, "P(leadlag>0)=", o["P_leadlag_pos"], o["leadlag_pct"])
        for nm in ("leadlag", "adol_ratio", "psi_adult"):
            st = sorted(o[nm]["ST"].items(), key=lambda kv: -kv[1])[:5]
            print("  ", nm, [(k, round(v, 2)) for k, v in st])
    print(json.dumps({k: v for k, v in out["bistability"].items() if "by_lesion" not in str(v)}, indent=1, default=float))
    print({k: out["bistability"][k]["frac_bistable_any_lesion"] for k in ("glia", "splice")})


if __name__ == "__main__":
    main()
