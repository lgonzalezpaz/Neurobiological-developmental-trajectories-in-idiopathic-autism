"""Asymmetric genetic loading of the two arms of the loop (SFARI Gene x GO BP).

Fisher exact tests of SFARI high-confidence genes (score 1-2) and of all
scored genes in pre-specified GO Biological Process 2023 gene sets, against a
background of all genes annotated in the library. BH-FDR across tests.
"""
import json
import numpy as np, pandas as pd
from scipy.stats import fisher_exact
from statsmodels.stats.multitest import multipletests
from config import RAW, RES, MODULES

TERMS = {
    "Splicing arm": ["mRNA Splicing, Via Spliceosome (GO:0000398)",
                     "Regulation Of Alternative mRNA Splicing, Via Spliceosome (GO:0000381)",
                     "Regulation Of mRNA Splicing, Via Spliceosome (GO:0048024)"],
    "Glial arm": ["Microglial Cell Activation (GO:0001774)",
                  "Regulation Of Microglial Cell Activation (GO:1903978)",
                  "Phagocytosis, Engulfment (GO:0006911)",
                  "Regulation Of Complement Activation (GO:0030449)"],
    "Comparator": ["Chemical Synaptic Transmission (GO:0007268)",
                   "Chromatin Remodeling (GO:0006338)"],
}


def load_go():
    gs = {}
    for line in open(RAW / "GO_BP_2023.txt"):
        p = line.rstrip("\n").split("\t")
        gs[p[0]] = {g.split(",")[0] for g in p[2:] if g}
    return gs


def or_ci(a, b, c, d):
    a, b, c, d = [x + 0.5 for x in (a, b, c, d)]          # Haldane correction for CI
    lor = np.log(a * d / (b * c)); se = np.sqrt(1 / a + 1 / b + 1 / c + 1 / d)
    return np.exp(lor - 1.96 * se), np.exp(lor + 1.96 * se)


def main():
    go = load_go()
    bg = set().union(*go.values())
    sf = pd.read_csv(RAW / "sfari_genes.csv")
    sets = {"SFARI score 1-2": set(sf.loc[sf["gene-score"].isin([1, 2]), "gene-symbol"]) & bg,
            "SFARI score 1": set(sf.loc[sf["gene-score"] == 1, "gene-symbol"]) & bg}
    rows = []
    tests = [(arm, t, go[t]) for arm, tl in TERMS.items() for t in tl]
    tests += [("Glial arm", "A-priori GLIA_PRUNE module", set(MODULES["GLIA_PRUNE"]) & bg),
              ("Splicing arm", "A-priori NEURO_SPLICE module", set(MODULES["NEURO_SPLICE"]) & bg)]
    for sname, S in sets.items():
        for arm, term, G in tests:
            a = len(S & G); b = len(G - S); c = len(S - G); d = len(bg - S - G)
            OR, p = fisher_exact([[a, b], [c, d]], alternative="two-sided")
            lo, hi = or_ci(a, b, c, d)
            rows.append(dict(sfari_set=sname, arm=arm, term=term, n_term=len(G), overlap=a,
                             expected=len(G) * len(S) / len(bg), OR=OR, OR_lo=lo, OR_hi=hi, p=p,
                             genes=";".join(sorted(S & G))))
    df = pd.DataFrame(rows)
    df["q_BH"] = np.nan
    for s, idx in df.groupby("sfari_set").groups.items():
        df.loc[idx, "q_BH"] = multipletests(df.loc[idx, "p"], method="fdr_bh")[1]
    df.to_csv(RES / "sfari_go_enrichment.csv", index=False)
    print(df.drop(columns="genes").round(4).to_string())
    json.dump(dict(background=len(bg), n_sfari12=len(sets["SFARI score 1-2"])),
              open(RES / "sfari_meta.json", "w"))


if __name__ == "__main__":
    main()
