"""In-silico longitudinal trial of the proposed 'definitive' cohort design.

Virtual individuals draw mechanistic parameters from the ABC posterior and are
assigned to control, glia-first or splicing-first entry routes (lesion size =
posterior-fitted value x log-normal jitter). Stochastic OU forcing acts on
glial engulfment efficacy and SRRM4 production in everyone. Three noisy
read-outs are 'measured' at scheduled waves:
   C   synaptic/connectivity proxy  = log S + e     (e.g. SV2A-PET, fMRI)
   PSI microexon inclusion proxy    = logit psi + e (CPEB4 me4 PSI)
   G   glial-state proxy            = log P + e     (TSPO-PET, CSF C1q/C3)
with error variance set by test-retest reliability (ICC).
Analyses: (A) cross-sectional vs longitudinal identifiability of the entry
route; (B) normative-chart onset-order rule and unsupervised clustering with
external validation in an independent site-shifted cohort; (C) RI-CLPM vs CLPM
recovery of the reciprocal loop; (D) power/sample-size surface.
"""
import json, sys, time
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_predict, StratifiedKFold
from sklearn.metrics import roc_auc_score, adjusted_rand_score
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from model import simulate_stoch, PARAM_NAMES
from riclpm import fit as riclpm_fit
from config import RES, PROC, SEED

POST = pd.read_csv(RES / "abc_posterior.csv").dropna(subset=["d_glia", "d_splice"]).reset_index(drop=True)
GROUPS = np.array(["CTL", "GLIA", "SPLICE"])
REL_DEFAULT = dict(C=0.60, PSI=0.80, G=0.70)


def make_cohort(n_per, rng, ou_sd=0.15, jitter=0.25):
    idx = rng.integers(0, len(POST), 3 * n_per)
    p = {k: POST[k].values[idx] for k in PARAM_NAMES}
    g = np.repeat(GROUPS, n_per)
    j = np.exp(rng.normal(0, jitter, 3 * n_per))
    dG = np.where(g == "GLIA", np.clip(POST.d_glia.values[idx] * j, 0, 0.95), 0.0)
    dS = np.where(g == "SPLICE", np.clip(POST.d_splice.values[idx] * j, 0, 0.95), 0.0)
    res = simulate_stoch(p, dG, dS, rng=rng, ou_sd=ou_sd)
    return g, res


def latent(res, ages):
    ii = np.array([np.argmin(np.abs(res["t"] - a)) for a in ages])
    lp = np.clip(res["psi"][:, ii], 1e-4, 1 - 1e-4)
    return dict(C=np.log(res["S"][:, ii]), PSI=np.log(lp / (1 - lp)), G=np.log(res["P"][:, ii]))


def observe(lat, rel, rng, bias=None):
    obs = {}
    for k, X in lat.items():
        vb = X.var(0, keepdims=True)
        e = rng.normal(size=X.shape) * np.sqrt(vb * (1 - rel[k]) / rel[k])
        obs[k] = X + e + (0 if bias is None else bias.get(k, 0.0))
    return obs


def norm_chart(obs, g):
    """Normative growth chart from controls (mean, sd per wave)."""
    c = g == "CTL"
    return {k: (X[c].mean(0), X[c].std(0)) for k, X in obs.items()}


def zscores(obs, chart):
    return {k: (X - chart[k][0]) / chart[k][1] for k, X in obs.items()}


def onset_rule(z, thr=1.0):
    """Entry route = marker whose deviation (C up / PSI down) crosses thr first.
    Ties -> larger cumulative deviation up to the tie wave."""
    devC = z["C"]; devP = -z["PSI"]
    T = devC.shape[1]
    first = lambda D: np.where((D >= thr).any(1), np.argmax(D >= thr, 1), T)
    fC, fP = first(devC), first(devP)
    lab = np.where(fC < fP, "GLIA", np.where(fP < fC, "SPLICE", ""))
    tie = lab == ""
    cumC = np.cumsum(devC, 1); cumP = np.cumsum(devP, 1)
    k = np.clip(np.minimum(fC, fP), 0, T - 1)
    r = np.arange(len(k))
    lab[tie] = np.where(cumC[r, k][tie] >= cumP[r, k][tie], "GLIA", "SPLICE")
    return lab, np.minimum(fC, fP) < T


def features(z):
    return np.hstack([z["C"], z["PSI"], z["G"]])


# ------------------------------------------------------------------ A + B
def identifiability(rng, n_per=600, ages=(2, 4, 6, 8, 10, 12, 14, 16, 18), rel=REL_DEFAULT):
    gA, rA = make_cohort(n_per, rng)
    gB, rB = make_cohort(n_per, rng)
    latA, latB = latent(rA, ages), latent(rB, ages)
    obsA = observe(latA, rel, rng)
    obsB = observe(latB, rel, rng, bias=dict(C=0.15, PSI=-0.2, G=0.1))   # site shift
    chA = norm_chart(obsA, gA); chB = norm_chart(obsB, gB)   # site-specific charts
    zA, zB = zscores(obsA, chA), zscores(obsB, chB)
    asdA, asdB = gA != "CTL", gB != "CTL"
    yA = (gA[asdA] == "SPLICE").astype(int); yB = (gB[asdB] == "SPLICE").astype(int)
    out = {"cross_sectional": {}, "ages": list(ages)}
    cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
    for w, a in enumerate(ages):
        X = np.c_[zA["C"][asdA, w], zA["PSI"][asdA, w], zA["G"][asdA, w]]
        pr = cross_val_predict(LogisticRegression(max_iter=2000), X, yA, cv=cv, method="predict_proba")[:, 1]
        Xd = np.c_[zA["C"][:, w], zA["PSI"][:, w], zA["G"][:, w]]
        prd = cross_val_predict(LogisticRegression(max_iter=2000), Xd, asdA.astype(int), cv=cv, method="predict_proba")[:, 1]
        out["cross_sectional"][a] = dict(auc_route=roc_auc_score(yA, pr), auc_dx=roc_auc_score(asdA, prd))
    # longitudinal supervised (upper bound) with external validation A -> B
    sc = StandardScaler().fit(features(zA)[asdA])
    clf = LogisticRegression(max_iter=5000, C=0.5).fit(sc.transform(features(zA)[asdA]), yA)
    out["long_supervised_internal_cv"] = roc_auc_score(
        yA, cross_val_predict(LogisticRegression(max_iter=5000, C=0.5), sc.transform(features(zA)[asdA]), yA, cv=cv, method="predict_proba")[:, 1])
    out["long_supervised_external"] = roc_auc_score(yB, clf.predict_proba(sc.transform(features(zB)[asdB]))[:, 1])
    # unsupervised onset-order rule (no labels, no training)
    for nm, z, g, asd in (("A", zA, gA, asdA), ("B", zB, gB, asdB)):
        lab, dev = onset_rule(z)
        acc = np.mean(lab[asd] == g[asd]); accd = np.mean(lab[asd & dev] == g[asd & dev])
        out[f"onset_rule_acc_{nm}"] = acc; out[f"onset_rule_acc_deviant_{nm}"] = accd
        out[f"frac_deviant_{nm}"] = float(np.mean(dev[asd]))
    # unsupervised GMM on longitudinal features, fit on A, applied to B
    gm = GaussianMixture(2, covariance_type="diag", n_init=10, random_state=SEED).fit(sc.transform(features(zA)[asdA]))
    out["gmm_ARI_A"] = adjusted_rand_score(yA, gm.predict(sc.transform(features(zA)[asdA])))
    out["gmm_ARI_B"] = adjusted_rand_score(yB, gm.predict(sc.transform(features(zB)[asdB])))
    # mean deviation trajectories for figure (latent, cohort A)
    traj = {}
    for grp in ("GLIA", "SPLICE"):
        m = gA == grp; c = gA == "CTL"
        traj[grp] = {k: (latA[k][m].mean(0) - latA[k][c].mean(0)).tolist() for k in latA}
    out["mean_latent_deviation"] = traj
    # save one cohort for figures
    pd.DataFrame({"group": gA, **{f"{k}_w{w}": zA[k][:, w] for k in zA for w in range(len(ages))}}).to_csv(
        PROC / "insilico_cohortA_z.csv.gz", index=False)
    return out


# ------------------------------------------------------------------ C + D
def loop_recovery(rng, n_big=3000, ages=(6, 8, 10, 12, 14, 16)):
    g, r = make_cohort(n_big, rng)
    lat = latent(r, ages)
    out = {}
    for grp in ("GLIA", "SPLICE", "ASD"):
        m = (g != "CTL") if grp == "ASD" else (g == grp)
        X, Y = lat["C"][m], lat["PSI"][m]
        a = riclpm_fit(X, Y, ri=True); b = riclpm_fit(X, Y, ri=False)
        out[grp] = dict(RI=dict(est=a["est"], se=a["se"]), CLPM=dict(est=b["est"], se=b["se"]),
                        chi2_RI=a["chi2"], df_RI=a["df"], chi2_CLPM=b["chi2"], df_CLPM=b["df"])
    return out


def power(rng, Ns=(100, 200, 400, 800, 1600), rels=(0.29, 0.6, 0.9), reps=60,
          ages=(6, 8, 10, 12, 14, 16)):
    """Power to detect both cross-lags (C->PSI and PSI->C) with RI-CLPM, pooled ASD."""
    # a large reservoir of latent ASD trajectories, resampled
    g, r = make_cohort(3000, rng)
    lat = latent(r, ages); asd = g != "CTL"
    pool = {k: v[asd] for k, v in lat.items()}
    rows = []
    for rel in rels:
        for N in Ns:
            for rep in range(reps):
                ii = rng.integers(0, asd.sum(), N)
                sub = {k: pool[k][ii] for k in ("C", "PSI")}
                ob = observe(sub, dict(C=rel, PSI=max(rel, 0.8) if rel < 0.8 else rel), rng)
                for ri in (True, False):
                    f = riclpm_fit(ob["C"], ob["PSI"], ri=ri)
                    rows.append(dict(rel_C=rel, N=N, rep=rep, model="RI-CLPM" if ri else "CLPM",
                                     b_xy=f["est"]["b_xy"], p_xy=f["p"]["b_xy"],
                                     b_yx=f["est"]["b_yx"], p_yx=f["p"]["b_yx"]))
            print("power", rel, N, flush=True)
    return pd.DataFrame(rows)


def design_grid(rng, n_per=400):
    """Onset-rule accuracy vs number of waves, starting age and reliability."""
    g, r = make_cohort(n_per, rng)
    designs = {"2 waves (8,16)": (8, 16), "3 waves (4,10,16)": (4, 10, 16),
               "4 waves (2,6,10,14)": (2, 6, 10, 14), "6 waves (2-12)": (2, 4, 6, 8, 10, 12),
               "9 waves (2-18)": (2, 4, 6, 8, 10, 12, 14, 16, 18),
               "5 waves late (12-20)": (12, 14, 16, 18, 20)}
    rows = []
    for nm, ages in designs.items():
        lat = latent(r, ages)
        for relC in (0.29, 0.6, 0.9):
            for rep in range(20):
                ob = observe(lat, dict(C=relC, PSI=0.8, G=0.7), rng)
                z = zscores(ob, norm_chart(ob, g))
                lab, dev = onset_rule(z)
                asd = g != "CTL"
                rows.append(dict(design=nm, n_waves=len(ages), rel_C=relC, rep=rep,
                                 acc=np.mean(lab[asd] == g[asd])))
    return pd.DataFrame(rows)


def main(part="all"):
    rng = np.random.default_rng(SEED)
    t0 = time.time()
    if part in ("all", "ident"):
        res = identifiability(rng)
        json.dump(res, open(RES / "insilico_identifiability.json", "w"), indent=1, default=float)
        print(json.dumps({k: v for k, v in res.items() if k != "mean_latent_deviation"}, indent=1, default=float))
        dg = design_grid(rng); dg.to_csv(RES / "insilico_design_grid.csv", index=False)
        print(dg.groupby(["design", "rel_C"]).acc.mean().unstack().round(3))
    if part in ("all", "loop"):
        lr = loop_recovery(rng)
        json.dump(lr, open(RES / "insilico_loop_recovery.json", "w"), indent=1, default=float)
        print(json.dumps(lr, indent=1, default=float))
    if part in ("all", "power"):
        pw = power(rng); pw.to_csv(RES / "insilico_power.csv", index=False)
        s = pw.assign(sig_xy=pw.p_xy < 0.05, sig_yx=pw.p_yx < 0.05)
        print(s.groupby(["model", "rel_C", "N"])[["sig_xy", "sig_yx", "b_xy", "b_yx"]].mean().round(3))
    print("elapsed", time.time() - t0)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "all")
