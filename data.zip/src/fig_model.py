"""Figures 1, 4, 5 and 6 (model, entry-route signatures, in-silico trial, design)."""
import json
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from model import simulate, PARAM_NAMES
from config import RES, PROC, COL, style, save

style()


def box(ax, xy, w, h, text, fc, ec="k", fs=6.5):
    b = FancyBboxPatch((xy[0] - w / 2, xy[1] - h / 2), w, h, boxstyle="round,pad=0.02,rounding_size=0.04",
                       fc=fc, ec=ec, lw=0.7)
    ax.add_patch(b)
    ax.text(xy[0], xy[1], text, ha="center", va="center", fontsize=fs)


def arrow(ax, p0, p1, text="", col="k", rad=0.0, ls="-", fs=5.5, off=(0, 0)):
    a = FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=8, color=col, lw=0.9,
                        connectionstyle=f"arc3,rad={rad}", linestyle=ls)
    ax.add_patch(a)
    if text:
        mx, my = (p0[0] + p1[0]) / 2 + off[0], (p0[1] + p1[1]) / 2 + off[1]
        ax.text(mx, my, text, fontsize=fs, ha="center", va="center", color=col,
                bbox=dict(fc="white", ec="none", pad=0.4))


def schematic(ax):
    ax.set_xlim(0, 10); ax.set_ylim(-0.1, 7); ax.axis("off")
    box(ax, (5, 6.2), 3.0, 0.8, "Synaptic density  S", "#F3E1EE")
    box(ax, (8.4, 4.3), 2.6, 0.8, "Network activity  A", "#DDF2EA")
    box(ax, (8.4, 2.0), 2.6, 0.8, "SRRM4 (nSR100)  R", "#DCEAF6")
    box(ax, (5, 0.7), 3.2, 0.8, "CPEB4 me4 inclusion  ψ", "#DCEAF6")
    box(ax, (1.6, 2.0), 2.8, 0.8, "Reversible CPEB4  F(ψ)", "#DCEAF6")
    box(ax, (1.6, 4.3), 2.8, 0.8, "Glial pruning  kP·ε·P·Φ(F)", "#FBE3D6")
    arrow(ax, (6.5, 6.0), (8.0, 4.75), "+  (A = S^η)", rad=-0.15, off=(0.55, 0.15))
    arrow(ax, (8.4, 3.9), (8.4, 2.45), "−  activity\nrepresses", col=COL["splice"], off=(0.75, 0))
    arrow(ax, (7.8, 1.6), (6.6, 0.95), "+  Hill", col=COL["splice"], rad=-0.15, off=(0.35, -0.2))
    arrow(ax, (3.4, 0.9), (2.0, 1.6), "chi = 1 − ψ\nthreshold 0.375", col=COL["splice"], rad=-0.15, off=(-0.6, -0.35))
    arrow(ax, (1.6, 2.4), (1.6, 3.9), "+  refinement\nefficacy Φ", col=COL["glia"], off=(-0.05, 0))
    arrow(ax, (2.2, 4.75), (3.5, 6.0), "−  elimination", col=COL["glia"], rad=-0.15, off=(-0.6, 0.15))
    arrow(ax, (4.2, 5.8), (2.7, 4.7), "", col="0.5", rad=0.25, ls="--")
    ax.text(3.75, 4.95, "reactive\nP ∝ S^λ", fontsize=5, color="0.4", ha="center")
    ax.text(5, 3.3, "reciprocal\npositive-feedback loop\n(S↑ → A↑ → R↓ → ψ↓ → F↓ → Φ↓ → S↑)", fontsize=6.2, ha="center", style="italic")
    ax.text(0.1, 6.85, "Glia-first entry:\nengulfment efficacy ε ↓", fontsize=6, color=COL["glia"], fontweight="bold", va="top")
    ax.text(8.4, -0.05, "Splicing-first entry:\nSRRM4 production R0 ↓", fontsize=6, color=COL["splice"], fontweight="bold", ha="center", va="bottom")


def agefmt(ax, lo=0.0):
    from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
    ax.set_xscale("symlog", linthresh=1)
    ticks = [x for x in [0, 1, 5, 10, 20, 40] if x >= lo]
    ax.xaxis.set_major_locator(FixedLocator(ticks)); ax.xaxis.set_major_formatter(FixedFormatter([str(x) for x in ticks]))
    ax.xaxis.set_minor_locator(NullLocator())


def fig1():
    post = pd.read_csv(RES / "abc_posterior.csv").dropna(subset=["d_glia", "d_splice"])
    p = {k: post[k].values for k in PARAM_NAMES}
    ctl = simulate(p, record=("S", "P", "R", "psi"))
    gl = simulate(p, dG=post.d_glia.values, record=("S", "P", "R", "psi"))
    sp = simulate(p, dS=post.d_splice.values, record=("S", "P", "R", "psi"))
    t = ctl["t"]
    fig = plt.figure(figsize=(7.2, 5.2))
    gs = fig.add_gridspec(2, 3, height_ratios=[1.25, 1], hspace=0.45, wspace=0.45)
    ax = fig.add_subplot(gs[0, :2]); schematic(ax)
    ax.text(0.0, 1.0, "a", transform=ax.transAxes, fontsize=9, fontweight="bold")
    # b: S trajectories vs Tang
    ax = fig.add_subplot(gs[0, 2])
    m = t >= 0
    for res, c, lab in ((ctl, COL["ctrl"], "Control"), (gl, COL["glia"], "Glia-first"), (sp, COL["splice"], "Splicing-first")):
        sc = res["S"] / ctl["S"][:, (t >= 30) & (t <= 40)].mean(1, keepdims=True)
        med = np.median(sc, 0); lo, hi = np.percentile(sc, [10, 90], 0)
        ax.plot(t[m], med[m], color=c, label=lab, ls="-" if lab != "Splicing-first" else "--")
        ax.fill_between(t[m], lo[m], hi[m], color=c, alpha=0.12, lw=0)
    # Tang data rescaled to model control child value
    ch = np.median(ctl["S"][:, (t >= 2) & (t <= 9)].mean(1) / ctl["S"][:, (t >= 30) & (t <= 40)].mean(1))
    k = ch / 11.37
    ax.errorbar([5.5, 16.5], [11.37 * k, 6.24 * k], yerr=[0.68 * k, 0.59 * k], fmt="s", color=COL["ctrl"], ms=3.5, capsize=2, lw=0.8, label="Tang 2014 control")
    ax.errorbar([5.5, 16.5], [12.32 * k, 10.33 * k], yerr=[0.60 * k, 0.74 * k], fmt="o", color=COL["asd"], mec="k", mew=0.4, ms=3.5, capsize=2, lw=0.8, label="Tang 2014 ASD")
    agefmt(ax); ax.set_xlim(0, 40)
    ax.set_xlabel("Age (years)"); ax.set_ylabel("Spine density (× adult control)")
    ax.legend(frameon=False, fontsize=5, loc="upper right")
    ax.set_title("Calibration", loc="left", fontweight="bold")
    ax.text(-0.3, 1.02, "b", transform=ax.transAxes, fontsize=9, fontweight="bold")
    # c-e: psi, P, R
    for i, (key, ylab, lab) in enumerate((("psi", "me4 inclusion ψ", "c"), ("P", "Glial state P (× adult)", "d"), ("R", "SRRM4 R (× adult)", "e"))):
        ax = fig.add_subplot(gs[1, i])
        for res, c, nm in ((ctl, COL["ctrl"], "Control"), (gl, COL["glia"], "Glia-first"), (sp, COL["splice"], "Splicing-first")):
            y = res[key] if key == "psi" else res[key] / ctl[key][:, (t >= 30) & (t <= 40)].mean(1, keepdims=True)
            med = np.median(y, 0); lo, hi = np.percentile(y, [10, 90], 0)
            ax.plot(t, med, color=c, ls="--" if nm == "Splicing-first" else "-", label=nm)
            ax.fill_between(t, lo, hi, color=c, alpha=0.12, lw=0)
        if key == "psi":
            ax.axhline(0.70, color="0.5", lw=0.5, ls=":"); ax.axhline(0.55, color=COL["asd"], lw=0.5, ls=":")
            ax.text(39, 0.71, "control 0.70", fontsize=5, ha="right", va="bottom")
            ax.text(39, 0.54, "ASD 0.55 (held out)", fontsize=5, ha="right", va="top", color=COL["asd"])
            ax.axhline(1 - 0.375, color="0.3", lw=0.5, ls="--")
            ax.text(0.2, 0.63, "aggregation threshold", fontsize=5, va="bottom")
        agefmt(ax); ax.set_xlim(-0.5, 40)
        ax.set_xlabel("Age (years)"); ax.set_ylabel(ylab)
        ax.text(-0.3, 1.02, lab, transform=ax.transAxes, fontsize=9, fontweight="bold")
        if i == 0:
            ax.legend(frameon=False, fontsize=5, loc="lower left")
    save(fig, "Figure1_model_calibration")


def fig4():
    post = pd.read_csv(RES / "abc_posterior.csv").dropna(subset=["d_glia", "d_splice"])
    sb = json.load(open(RES / "sensitivity_bistability.json"))
    bs = pd.read_csv(RES / "bistability_scan.csv")
    p = {k: post[k].values for k in PARAM_NAMES}
    ctl = simulate(p, record=("S", "P", "psi"))
    gl = simulate(p, dG=post.d_glia.values, record=("S", "P", "psi"))
    sp = simulate(p, dS=post.d_splice.values, record=("S", "P", "psi"))
    t = ctl["t"]; m = (t >= 0) & (t <= 30)
    fig, axs = plt.subplots(2, 3, figsize=(7.2, 4.6))
    for ax, res, nm, lab in ((axs[0, 0], gl, "Glia-first", "a"), (axs[0, 1], sp, "Splicing-first", "b")):
        dS_ = res["S"] / ctl["S"] - 1; dpsi = ctl["psi"] - res["psi"]; dP = res["P"] / ctl["P"] - 1
        for D, c, l in ((dS_, COL["SYNAPSE"], "S excess"), (dpsi, COL["splice"], "ψ loss"), (dP, COL["glia"], "Glial state P")):
            Dn = D / np.abs(D[:, m]).max(1, keepdims=True)
            med = np.median(Dn, 0); lo, hi = np.percentile(Dn, [10, 90], 0)
            ax.plot(t[m], med[m], color=c, label=l); ax.fill_between(t[m], lo[m], hi[m], color=c, alpha=0.15, lw=0)
        ax.axhline(0.25, color="0.6", lw=0.5, ls=":")
        ax.set_xlabel("Age (years)"); ax.set_ylabel("Deviation (fraction of maximum)")
        ax.set_title(nm, loc="left", fontweight="bold", color=COL["glia"] if "Glia" in nm else COL["splice"])
        ax.text(-0.28, 1.02, lab, transform=ax.transAxes, fontsize=9, fontweight="bold")
        if lab == "a":
            ax.legend(frameon=False, fontsize=5.5, loc="lower right")
    ax = axs[0, 2]
    bins = np.linspace(-15, 15, 61)
    ax.hist(post.glia_leadlag.dropna(), bins=bins, color=COL["glia"], alpha=0.7, label="Glia-first")
    ax.hist(post.splice_leadlag.dropna(), bins=bins, color=COL["splice"], alpha=0.7, label="Splicing-first")
    ax.axvline(0, color="k", lw=0.6)
    ax.set_xlabel("Lead–lag: onset(ψ) − onset(S)  (years)"); ax.set_ylabel("Posterior parameter sets")
    ax.legend(frameon=False, fontsize=5.5)
    ax.set_title("Entry-route signature", loc="left", fontweight="bold")
    ax.text(-0.28, 1.02, "c", transform=ax.transAxes, fontsize=9, fontweight="bold")
    # d: Sobol total indices for lead-lag
    ax = axs[1, 0]
    names = PARAM_NAMES
    stg = np.array([sb["sobol"]["glia"]["leadlag"]["ST"][k] for k in names])
    sts = np.array([sb["sobol"]["splice"]["leadlag"]["ST"][k] for k in names])
    order = np.argsort(-(stg + sts))[:8]
    y = np.arange(len(order))
    ax.barh(y - 0.2, stg[order], 0.4, color=COL["glia"], label="Glia-first")
    ax.barh(y + 0.2, sts[order], 0.4, color=COL["splice"], label="Splicing-first")
    ax.set_yticks(y); ax.set_yticklabels([names[i] for i in order]); ax.invert_yaxis()
    ax.set_xlabel("Sobol total index (lead–lag)")
    ax.legend(frameon=False, fontsize=5.5, loc="lower right")
    ax.set_title("Global sensitivity", loc="left", fontweight="bold")
    ax.text(-0.28, 1.02, "d", transform=ax.transAxes, fontsize=9, fontweight="bold")
    # e: bistability fraction vs lesion
    ax = axs[1, 1]
    for kind, c, nm in (("glia", COL["glia"], "Glia-first (ε ↓)"), ("splice", COL["splice"], "Splicing-first (R0 ↓)")):
        d = bs[bs.kind == kind].groupby("lesion").n_stable.apply(lambda x: (x > 1).mean())
        ax.plot(d.index, d.values, color=c, label=nm)
    for kind, c, col in (("glia", COL["glia"], "d_glia"), ("splice", COL["splice"], "d_splice")):
        ax.axvspan(*post[col].quantile([0.25, 0.75]), color=c, alpha=0.12, lw=0)
    ax.set_xlabel("Lesion size"); ax.set_ylabel("Fraction bistable (adult map)")
    ax.legend(frameon=False, fontsize=5.5)
    ax.set_title("Attractor structure", loc="left", fontweight="bold")
    ax.text(-0.28, 1.02, "e", transform=ax.transAxes, fontsize=9, fontweight="bold")
    # f: cross-sectional equivalence in adulthood
    ax = axs[1, 2]
    for res, c, nm, mk in ((gl, COL["glia"], "Glia-first", "o"), (sp, COL["splice"], "Splicing-first", "s"), (ctl, COL["ctrl"], "Control", ".")):
        mm = (t >= 20) & (t <= 30)
        x = np.log(res["P"][:, mm].mean(1) / ctl["P"][:, mm].mean(1)) if nm != "Control" else np.zeros(len(post))
        yv = res["psi"][:, mm].mean(1)
        ax.scatter(x + (np.random.default_rng(1).normal(0, 0.005, len(x)) if nm == "Control" else 0), yv, s=4, color=c, alpha=0.4, marker=mk, lw=0, label=nm)
    ax.set_xlabel("log glial state (ASD/control), 20–30 y"); ax.set_ylabel("me4 inclusion ψ, 20–30 y")
    ax.legend(frameon=False, fontsize=5.5, markerscale=2)
    ax.set_title("Adult cross-section", loc="left", fontweight="bold")
    ax.text(-0.28, 1.02, "f", transform=ax.transAxes, fontsize=9, fontweight="bold")
    fig.tight_layout()
    save(fig, "Figure4_entry_signatures")


def fig5():
    idn = json.load(open(RES / "insilico_identifiability.json"))
    dg = pd.read_csv(RES / "insilico_design_grid.csv")
    pw = pd.read_csv(RES / "insilico_power.csv")
    lr = json.load(open(RES / "insilico_loop_recovery.json"))
    fig, axs = plt.subplots(2, 3, figsize=(7.2, 5.6))
    ax = axs[0, 0]
    ages = [float(a) for a in idn["cross_sectional"]]
    ax.plot(ages, [v["auc_dx"] for v in idn["cross_sectional"].values()], "o-", color=COL["asd"], ms=3, label="ASD vs control")
    ax.plot(ages, [v["auc_route"] for v in idn["cross_sectional"].values()], "s-", color="0.3", ms=3, label="Entry route (single wave)")
    ax.axhline(idn["long_supervised_external"], color=COL["mixed"], ls="--", lw=1, label="Entry route (all waves, external)")
    ax.axhline(0.5, color="0.6", lw=0.5, ls=":")
    ax.set_ylim(0.4, 1.02); ax.set_xlabel("Age at single assessment (years)"); ax.set_ylabel("Cross-validated AUC")
    ax.legend(frameon=False, fontsize=5, loc="upper center", bbox_to_anchor=(0.5, -0.24), ncol=1)
    ax.set_title("Cross-section vs trajectory", loc="left", fontweight="bold")
    ax.text(-0.28, 1.02, "a", transform=ax.transAxes, fontsize=9, fontweight="bold")
    ax = axs[0, 1]
    z = pd.read_csv(PROC / "insilico_cohortA_z.csv.gz")
    nw = len(idn["ages"]); ag = idn["ages"]
    for grp, c in (("GLIA", COL["glia"]), ("SPLICE", COL["splice"])):
        s = z[z.group == grp]
        ax.plot(ag, [s[f"C_w{w}"].mean() for w in range(nw)], "-", color=c, label=f"{grp.title()}: C (synaptic)")
        ax.plot(ag, [-s[f"PSI_w{w}"].mean() for w in range(nw)], "--", color=c, label=f"{grp.title()}: −ψ")
    ax.axhline(1, color="0.6", lw=0.5, ls=":")
    ax.set_xlabel("Age (years)"); ax.set_ylabel("Normative z (observed)")
    ax.legend(frameon=False, fontsize=5, loc="upper center", bbox_to_anchor=(0.5, -0.24), ncol=2)
    ax.set_title("Normative-chart deviations", loc="left", fontweight="bold")
    ax.text(-0.28, 1.02, "b", transform=ax.transAxes, fontsize=9, fontweight="bold")
    ax = axs[0, 2]
    g = dg.groupby(["design", "rel_C"]).acc.agg(["mean", "std"]).reset_index()
    designs = list(dict.fromkeys(dg.design))
    for i, r in enumerate((0.29, 0.6, 0.9)):
        s = g[g.rel_C == r].set_index("design").loc[designs]
        ax.barh(np.arange(len(designs)) + (i - 1) * 0.27, s["mean"], 0.27, xerr=s["std"],
                color=["#BBBBBB", "#888888", "#333333"][i], label=f"ICC(C) = {r}", error_kw=dict(lw=0.5))
    ax.set_yticks(range(len(designs))); ax.set_yticklabels(designs, fontsize=5.3); ax.invert_yaxis()
    ax.axvline(0.5, color="0.6", lw=0.5, ls=":"); ax.set_xlim(0.4, 1)
    ax.set_xlabel("Entry-route accuracy (onset rule)")
    ax.legend(frameon=False, fontsize=5, loc="upper center", bbox_to_anchor=(0.3, -0.24), ncol=1)
    ax.set_title("Design comparison", loc="left", fontweight="bold")
    ax.text(-0.5, 1.13, "c", transform=ax.transAxes, fontsize=9, fontweight="bold")
    # d: RI-CLPM vs CLPM estimates (latent, large N)
    ax = axs[1, 0]
    labs = []; i = 0
    for grp in ("GLIA", "SPLICE", "ASD"):
        for mod, c in (("RI", COL["mixed"]), ("CLPM", "0.5")):
            for par, mk in (("b_xy", "o"), ("b_yx", "s")):
                e = lr[grp][mod]["est"][par]; s = lr[grp][mod]["se"][par]
                ax.errorbar(e, i, xerr=1.96 * s, fmt=mk, color=c, ms=3, lw=0.8)
                labs.append(f"{grp if grp == 'ASD' else grp.title()} {('RI-CLPM' if mod == 'RI' else 'CLPM')} {'C→ψ' if par == 'b_xy' else 'ψ→C'}")
                i += 1
    ax.axvline(0, color="k", lw=0.5)
    ax.set_yticks(range(len(labs))); ax.set_yticklabels(labs, fontsize=4.6); ax.invert_yaxis()
    ax.set_xlabel("Cross-lagged coefficient (2-y lag)")
    ax.set_title("Loop recovery", loc="left", fontweight="bold")
    ax.text(-0.75, 1.02, "d", transform=ax.transAxes, fontsize=9, fontweight="bold")
    # e, f: power
    s = pw.assign(sig_xy=pw.p_xy < 0.05, sig_yx=pw.p_yx < 0.05)
    for ax, par, lab, ttl in ((axs[1, 1], "sig_xy", "e", "Power: C → ψ"), (axs[1, 2], "sig_yx", "f", "Power: ψ → C")):
        for r, c in zip((0.29, 0.6, 0.9), ("#BBBBBB", "#888888", "#333333")):
            for mod, ls in (("RI-CLPM", "-"), ("CLPM", ":")):
                q = s[(s.rel_C == r) & (s.model == mod)].groupby("N")[par].mean()
                ax.plot(q.index, q.values, ls, color=c, marker="o", ms=2.5, label=f"{mod}, ICC {r}" if mod == "RI-CLPM" or r == 0.6 else None)
        ax.axhline(0.8, color="0.6", lw=0.5, ls="--")
        ax.set_xscale("log"); ax.set_ylim(0, 1.02)
        ax.set_xlabel("ASD participants (N)"); ax.set_ylabel("Power (α = 0.05)")
        ax.set_title(ttl, loc="left", fontweight="bold")
        ax.text(-0.28, 1.02, lab, transform=ax.transAxes, fontsize=9, fontweight="bold")
        if lab == "e":
            ax.legend(frameon=False, fontsize=5, loc="upper center", bbox_to_anchor=(1.1, -0.24), ncol=2)
    fig.subplots_adjust(left=0.13, right=0.98, top=0.95, bottom=0.17, hspace=1.0, wspace=0.75)
    save(fig, "Figure5_insilico_trial")


def fig7():
    """Design blueprint for the prospective cohort derived from the analyses."""
    fig, ax = plt.subplots(figsize=(7.2, 3.3))
    ax.set_xlim(-1, 21); ax.set_ylim(-0.5, 7.2); ax.axis("off")
    waves = [0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 18]
    ax.plot([-0.5, 20], [6.3, 6.3], color="k", lw=0.8)
    for w in waves:
        ax.plot([w, w], [6.15, 6.45], color="k", lw=0.8)
        ax.text(w, 6.6, "birth" if w == 0 else f"{w} y", ha="center", fontsize=5.5)
    ax.text(-0.9, 6.95, "Assessment waves (prenatal/neonatal enrolment of high-likelihood siblings + population sample)", fontsize=6, fontweight="bold")
    rows = [("Synaptic density / connectivity (C)", "SV2A-PET (≥ 8 y), rs-fMRI, EEG/ET (ABC-CT harmonised)", COL["SYNAPSE"], 1, 18),
            ("Microexon / splicing state (ψ)", "Long-read RNA-seq of neural-derived EVs, iPSC-neurons; CPEB4 me4 PSI", COL["splice"], 0, 18),
            ("Glial state (G)", "Plasma/CSF C1q, C3, C4, sTREM2; TSPO-PET (adults)", COL["glia"], 0, 18),
            ("Genome and exposome (baseline, once; exposome updated each wave)", "WGS (rare/de novo, PGS, sQTL instruments), maternal immune activation, infections", "0.45", -0.5, 18),
            ("Phenotype (primary endpoint)", "Language, adaptive function, psychiatric comorbidity, intervention response", "0.2", 1, 18)]
    for i, (nm, desc, c, a0, a1) in enumerate(rows):
        y = 5.2 - i * 1.05
        ax.add_patch(FancyBboxPatch((a0, y - 0.3), a1 - a0, 0.6, boxstyle="round,pad=0.02", fc=c, alpha=0.25, ec=c))
        ax.text(a0 + 0.15, y + 0.08, nm, fontsize=6.2, fontweight="bold", va="center")
        ax.text(a0 + 0.15, y - 0.17, desc, fontsize=5.3, va="center")
    ax.text(19.0, 5.2, "Analysis", fontsize=6.2, fontweight="bold")
    ax.text(19.0, 4.95, "• normative charts per site\n• onset-order rule\n• RI-CLPM loop\n• rolling individual\n  prognosis\n• route-stratified\n  intervention arms\n• MR/sQTL triangulation\n• leave-site-out\n  external validation", fontsize=5.3, va="top")
    save(fig, "Figure7_design_blueprint")




def fig6():
    """Multicentre individual prediction and treatment allocation."""
    pe = pd.read_csv(RES / "prediction_external.csv")
    hz = pd.read_csv(RES / "prediction_horizon.csv")
    lc = pd.read_csv(RES / "prediction_learning_curve.csv")
    pt = json.load(open(RES / "prediction_trial.json"))
    ind = pd.read_csv(PROC / "prediction_trial_individuals.csv.gz")
    feats = ["Clinical", "Clinical + imaging", "Clinical + imaging + omics"]
    fcol = {"Clinical": "#999999", "Clinical + imaging": COL["SYNAPSE"], "Clinical + imaging + omics": COL["mixed"]}
    fig, axs = plt.subplots(2, 3, figsize=(7.2, 5.2))
    ax = axs[0, 0]
    x = np.arange(3); w = 0.26
    for i, f in enumerate(feats):
        s = pe[(pe.features == f) & (pe.harmonized)].sort_values("R2_latent")
        ax.bar(x + (i - 1) * w, s.R2_external, w, yerr=[s.R2_external - s.lo, s.hi - s.R2_external],
               color=fcol[f], label=f, error_kw=dict(lw=0.5))
        s2 = pe[(pe.features == f) & (~pe.harmonized)].sort_values("R2_latent")
        ax.scatter(x + (i - 1) * w, s2.R2_external, marker="_", color="k", s=30, zorder=3)
    ax.plot(x, [0.3, 0.5, 0.7], "k:", lw=0.7)
    ax.set_xticks(x); ax.set_xticklabels(["0.3", "0.5", "0.7"])
    ax.set_xlabel("Outcome variance explained by circuit burden"); ax.set_ylabel("External R² (held-out sites)")
    ax.set_title("Outcome from 2–6 y data", loc="left", fontweight="bold")
    ax.legend(frameon=False, fontsize=5, loc="upper left")
    ax.text(-0.28, 1.04, "a", transform=ax.transAxes, fontsize=9, fontweight="bold")
    ax = axs[0, 1]
    for f in feats:
        s = hz[hz.features == f]
        ax.plot(s.last_wave, s.R2_external, "o-", color=fcol[f], ms=3, label=f)
    ax.axhline(0.5, color="0.6", lw=0.5, ls=":")
    ax.set_xlabel("Last observed wave (years)"); ax.set_ylabel("External R²")
    ax.set_title("Prediction horizon", loc="left", fontweight="bold")
    ax.text(-0.28, 1.04, "b", transform=ax.transAxes, fontsize=9, fontweight="bold")
    ax = axs[0, 2]
    for f in feats:
        s = lc[lc.features == f].groupby("n_train").R2_external
        m, sd = s.mean(), s.std()
        ax.plot(m.index, m.values, "o-", color=fcol[f], ms=3)
        ax.fill_between(m.index, m - sd, m + sd, color=fcol[f], alpha=0.15, lw=0)
    ax.set_xscale("log"); ax.set_xlabel("Autistic training participants"); ax.set_ylabel("External R²")
    ax.set_title("Learning curve", loc="left", fontweight="bold")
    ax.text(-0.28, 1.04, "c", transform=ax.transAxes, fontsize=9, fontweight="bold")
    ax = axs[1, 0]
    a = ind[ind.group != "CTL"]
    pos = 0
    for grp, c in (("GLIA", COL["glia"]), ("SPLICE", COL["splice"])):
        for th, hatch in (("benefit_splice", ""), ("benefit_glia", "///")):
            v = a[a.group == grp][th]
            ax.bar(pos, v.mean(), 0.8, yerr=v.std() / np.sqrt(len(v)) * 1.96, color=c, hatch=hatch, edgecolor="k", lw=0.4)
            pos += 1
        pos += 0.6
    ax.set_xticks([0.5, 3.1]); ax.set_xticklabels(["Glia-first", "Splicing-first"])
    ax.set_ylabel("Benefit (reduction in circuit burden, z)")
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(fc="white", ec="k", label="Microexon therapy"), Patch(fc="white", ec="k", hatch="///", label="Glial therapy")],
              frameon=False, fontsize=5, loc="upper left")
    ax.set_ylim(0, 1.9)
    ax.set_title("Route × therapy", loc="left", fontweight="bold")
    ax.text(0.98, 0.84, f"route × therapy\nP = {pt['heterogeneity']['interaction']['p']:.1e}", transform=ax.transAxes, ha="right", va="top", fontsize=5.5)
    ax.text(-0.28, 1.04, "d", transform=ax.transAxes, fontsize=9, fontweight="bold")
    ax = fig.add_subplot(2, 3, (5, 6)); axs[1, 1].remove(); axs[1, 2].remove()
    st = pt["allocation"]; names = list(st.keys()); vals = [st[k] for k in names]
    cols = ["#BBBBBB", "#BBBBBB", "#DDDDDD", COL["SYNAPSE"], COL["mixed"], "#333333"]
    ax.barh(range(len(names)), vals, color=cols)
    for i, v in enumerate(vals):
        ax.text(v + 0.005, i, f"{v:.3f}", va="center", fontsize=5.5)
    ax.set_yticks(range(len(names))); ax.set_yticklabels(names); ax.invert_yaxis()
    lo = min(vals) - 0.05; ax.set_xlim(lo, max(vals) + 0.08)
    ax.set_xlabel("Mean benefit in external sites (z)")
    g = pt["gain_rule_vs_best_single"]
    ax.set_title("Treatment allocation from early (2–6 y) data", loc="left", fontweight="bold")
    ax.text(0.99, 0.55, f"onset rule vs best single therapy:\n+{g['mean']:.3f} (95% CI {g['lo']:.3f}–{g['hi']:.3f})\none-sided P = {g['p_one_sided']:.4f}",
            transform=ax.transAxes, ha="right", va="center", fontsize=5.5)
    ax.text(-0.22, 1.04, "e", transform=ax.transAxes, fontsize=9, fontweight="bold")
    fig.subplots_adjust(left=0.1, right=0.98, top=0.95, bottom=0.09, hspace=0.6, wspace=0.55)
    save(fig, "Figure6_prediction_allocation")


if __name__ == "__main__":
    import sys
    for f in sys.argv[1:]:
        globals()[f]()
