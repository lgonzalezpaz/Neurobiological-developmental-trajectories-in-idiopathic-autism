"""Maximum-likelihood bivariate (RI-)CLPM with time-invariant lagged effects.

x_it = mu_xt + kx_i + p_it ;  y_it = mu_yt + ky_i + q_it
[p_it, q_it]' = B [p_i,t-1, q_i,t-1]' + e_it,   B = [[a_x, b_yx], [b_xy, a_y]]
e_it ~ N(0, Psi);  [p_i1, q_i1] ~ N(0, Phi1);  [kx, ky] ~ N(0, RI)
CLPM: RI = 0.  Means are saturated (sample means).  Hamaker et al. 2015.
b_xy: lagged effect of x on y;  b_yx: lagged effect of y on x.
"""
import numpy as np
from scipy.optimize import minimize


def _chol(v):
    L = np.array([[np.exp(v[0]), 0.0], [v[1], np.exp(v[2])]])
    return L @ L.T


def implied(theta, T, ri=True):
    B = np.array([[theta[0], theta[1]], [theta[2], theta[3]]])
    Phi1 = _chol(theta[4:7]); Psi = _chol(theta[7:10])
    W = [Phi1]
    for t in range(1, T):
        W.append(B @ W[-1] @ B.T + Psi)
    S = np.zeros((2 * T, 2 * T))
    Bp = [np.eye(2)]
    for k in range(1, T):
        Bp.append(B @ Bp[-1])
    for t in range(T):
        for s in range(t + 1):
            C = Bp[t - s] @ W[s]
            S[2 * t:2 * t + 2, 2 * s:2 * s + 2] = C
            S[2 * s:2 * s + 2, 2 * t:2 * t + 2] = C.T
    if ri:
        RI = _chol(theta[10:13])
        J = np.kron(np.ones((T, 1)), np.eye(2))
        S = S + J @ RI @ J.T
    return S


def _f(theta, Sobs, T, ri):
    try:
        Sig = implied(theta, T, ri)
        sign, logdet = np.linalg.slogdet(Sig)
        if sign <= 0 or not np.isfinite(logdet):
            return 1e10
        return logdet + np.trace(np.linalg.solve(Sig, Sobs))
    except Exception:
        return 1e10


def fit(X, Y, ri=True, start=None):
    """X, Y: (n, T) arrays. Returns dict with estimates, SEs, z, p."""
    n, T = X.shape
    D = np.empty((n, 2 * T)); D[:, 0::2] = X; D[:, 1::2] = Y
    D = D - D.mean(0)
    Sobs = D.T @ D / n
    k = 13 if ri else 10
    if start is None:
        v = np.log(np.sqrt(np.clip(np.diag(Sobs).mean() / 2, 1e-6, None)))
        start = np.r_[0.4, 0.0, 0.0, 0.4, v, 0.0, v, v, 0.0, v, v, 0.0, v][:k]
    best = None
    for s0 in (start, np.r_[0.1, 0, 0, 0.1, start[4:]]):
        r = minimize(_f, s0, args=(Sobs, T, ri), method="L-BFGS-B")
        if best is None or r.fun < best.fun:
            best = r
    th = best.x
    # observed information via central-difference Hessian of (n/2) F
    eps = 1e-4
    H = np.zeros((k, k))
    f0 = _f(th, Sobs, T, ri)
    for i in range(4):          # Hessian block for B (sufficient for Wald on B)
        for j in range(i, 4):
            ei = np.zeros(k); ej = np.zeros(k); ei[i] = eps; ej[j] = eps
            fpp = _f(th + ei + ej, Sobs, T, ri); fpm = _f(th + ei - ej, Sobs, T, ri)
            fmp = _f(th - ei + ej, Sobs, T, ri); fmm = _f(th - ei - ej, Sobs, T, ri)
            H[i, j] = H[j, i] = (fpp - fpm - fmp + fmm) / (4 * eps ** 2)
    # full Hessian needed for correct SEs: compute remaining blocks
    for i in range(k):
        for j in range(max(i, 4), k):
            ei = np.zeros(k); ej = np.zeros(k); ei[i] = eps; ej[j] = eps
            fpp = _f(th + ei + ej, Sobs, T, ri); fpm = _f(th + ei - ej, Sobs, T, ri)
            fmp = _f(th - ei + ej, Sobs, T, ri); fmm = _f(th - ei - ej, Sobs, T, ri)
            H[i, j] = H[j, i] = (fpp - fpm - fmp + fmm) / (4 * eps ** 2)
    try:
        cov = np.linalg.inv(n / 2 * H)
        se = np.sqrt(np.clip(np.diag(cov), 0, None))[:4]
    except np.linalg.LinAlgError:
        se = np.full(4, np.nan)
    from scipy.stats import norm
    est = th[:4]
    z = est / se
    names = ["a_x", "b_yx", "b_xy", "a_y"]
    # chi-square vs saturated
    p_ = 2 * T
    chi2 = n * (best.fun - np.linalg.slogdet(Sobs)[1] - p_)
    df = p_ * (p_ + 1) / 2 - k
    return dict(est=dict(zip(names, est)), se=dict(zip(names, se)),
                z=dict(zip(names, z)), p=dict(zip(names, 2 * norm.sf(np.abs(z)))),
                chi2=chi2, df=df, converged=bool(best.success), theta=th)
