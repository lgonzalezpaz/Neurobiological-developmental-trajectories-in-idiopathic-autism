#!/usr/bin/env bash
# Download all public input data (approx. 110 MB). Run from the repository root.
set -euo pipefail
RAW=data/raw; mkdir -p "$RAW"
dl(){ curl -fsSL --retry 3 -o "$RAW/$1" "$2"; echo "downloaded $1"; }
# BrainSpan developmental transcriptome (RNA-seq, gene-level RPKM; Allen Institute)
dl brainspan_genes.zip "https://www.brainspan.org/api/v2/well_known_file_download/267666525"
unzip -o -q "$RAW/brainspan_genes.zip" -d "$RAW/brainspan"
# Post-mortem ASD cortex cohorts (NCBI GEO)
GEO=https://ftp.ncbi.nlm.nih.gov/geo
dl GSE28521_series_matrix.txt.gz        "$GEO/series/GSE28nnn/GSE28521/matrix/GSE28521_series_matrix.txt.gz"
dl GSE28475-GPL6883_series_matrix.txt.gz "$GEO/series/GSE28nnn/GSE28475/matrix/GSE28475-GPL6883_series_matrix.txt.gz"
dl GSE102741_series_matrix.txt.gz       "$GEO/series/GSE102nnn/GSE102741/matrix/GSE102741_series_matrix.txt.gz"
dl GSE102741_log2RPKMcounts.xlsx        "$GEO/series/GSE102nnn/GSE102741/suppl/GSE102741_log2RPKMcounts.xlsx"
dl GPL6883.annot.gz                     "$GEO/platforms/GPL6nnn/GPL6883/annot/GPL6883.annot.gz"
# SFARI Gene (human gene module) and GO Biological Process 2023 (Enrichr)
dl sfari_genes.csv "https://gene.sfari.org/wp-content/themes/sfari-gene/utilities/download-csv.php?api-endpoint=genes"
dl GO_BP_2023.txt  "https://maayanlab.cloud/Enrichr/geneSetLibrary?mode=text&libraryName=GO_Biological_Process_2023"
sha256sum "$RAW"/*.gz "$RAW"/*.csv "$RAW"/*.txt "$RAW"/*.xlsx > "$RAW/SHA256SUMS_downloaded.txt"
echo "Done. Compare with data/raw/SHA256SUMS.txt (SFARI and Enrichr files are versioned by date)."
