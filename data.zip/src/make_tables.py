"""Export manuscript tables (CSV) and Supplementary Table 1 from results/."""
import json, re, subprocess, sys
import pandas as pd
from config import ROOT, RES

# regenerate the manuscript JSON so tables reflect current results
subprocess.run([sys.executable, str(ROOT / "docs" / "manuscript_content.py")], check=True)
M = json.load(open(ROOT / "docs" / "manuscript.json"))
out = ROOT / "tables"; out.mkdir(exist_ok=True)
strip = lambda s: re.sub(r"[*~^]", "", str(s))
for b in M["blocks"]:
    if b["type"] == "table":
        df = pd.DataFrame([[strip(c) for c in r] for r in b["rows"]], columns=b["header"])
        df.to_csv(out / f"Table{b['n']}.csv", index=False)
eff = pd.read_csv(RES / "postmortem_dx_effects.csv")
eff.to_csv(out / "SupplementaryTable1_postmortem_effects.csv", index=False)
pd.read_csv(RES / "sfari_go_enrichment.csv").to_csv(out / "SupplementaryTable2_sfari_enrichment.csv", index=False)
print("tables written to", out)
