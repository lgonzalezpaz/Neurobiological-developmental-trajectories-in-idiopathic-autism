"""Pruning-splicing reciprocity (PSR) model.

State variables (time t in years from birth; adult control steady state
normalised to S = A = 1, psi = psi_adult):
  S   synaptic (spine) density
  A   network activity (quasi-steady, A = S**eta)
  P   glial pruning capacity (complement/phagocytic state)
  R   SRRM4 (nSR100) level, repressed by activity
  psi inclusion of the CPEB4 24-nt microexon (me4)
  F   reversible (functional) CPEB4 fraction, sigmoid in 1 - psi

Equations (see Methods, Eqs. 1-8):
  dS/dt   = sigma(t) - [k0 + kP * eps * P * Phi(F)] * S
  Phi(F)  = phi0 + (1 - phi0) * F
  A       = S**eta
  dP/dt   = (m(t) * S**lam - P) / tauP        (reactive glial state)
  dR/dt   = (R0 / (1 + (A/Ah)**n) - R) / tauR
  dpsi/dt = (R**h / (R**h + Kpsi**h) - psi) / taupsi
  F       = 1 / (1 + exp(((1 - psi) - chi_star) / w_chi))
Lesions:  glia-first      eps (engulfment efficacy) -> 1 - dG
          splicing-first  R0    -> R0 * (1 - dS)
All integrations are vectorised over parameter sets (RK4, dt = 0.005 y).
"""
import numpy as np

T0, T1, DT = -0.5, 40.0, 0.005
TGRID = np.arange(T0, T1 + 1e-9, DT)
CHI_STAR, W_CHI = 0.375, 0.035     # Garcia-Cabau et al. 2025: threshold 0.30-0.45
PSI_ADULT = 0.70                   # chi_Delta4 = 0.30 in control cortex

PARAM_NAMES = ["tau_s", "a_s", "sig_amp", "t_m", "w_m", "d_m", "kP", "k0_frac",
               "tauP", "lam", "Ah", "n", "h", "tauR", "taupsi", "phi0", "eta"]
# prior bounds (uniform); justification in Table 1
PRIOR = {"tau_s": (0.2, 1.5), "a_s": (1.0, 3.0), "sig_amp": (1.0, 12.0),
         "t_m": (0.0, 4.0), "w_m": (0.3, 2.0), "d_m": (0.0, 0.5),
         "kP": (0.05, 0.6), "k0_frac": (0.02, 0.3), "tauP": (0.1, 2.0), "lam": (0.0, 1.0),
         "Ah": (0.8, 3.0), "n": (1.0, 4.0), "h": (1.0, 4.0),
         "tauR": (0.02, 0.2), "taupsi": (0.05, 0.5), "phi0": (0.05, 0.6),
         "eta": (0.6, 1.5)}


def sample_prior(n, rng):
    return {k: rng.uniform(*v, n) for k, v in PRIOR.items()}


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def F_of_psi(psi):
    return 1.0 / (1.0 + np.exp(((1.0 - psi) - CHI_STAR) / W_CHI))


def derived(p):
    """Constants fixed by normalisation (adult control S = A = 1, psi = 0.70)."""
    R0 = 1.0
    Rad = R0 / (1.0 + (1.0 / p["Ah"]) ** p["n"])
    # Kpsi so that psi_adult = 0.70 at R = Rad
    Kpsi = Rad * ((1 - PSI_ADULT) / PSI_ADULT) ** (1.0 / p["h"])
    Fad = F_of_psi(PSI_ADULT)
    Phi_ad = p["phi0"] + (1 - p["phi0"]) * Fad
    m_inf = 1.0 - p["d_m"]
    Pad = m_inf                       # adult control: S = 1 -> P = m_inf
    kprune = p["kP"] * Pad * Phi_ad
    k0 = p["k0_frac"] * kprune / (1 - p["k0_frac"])   # baseline turnover share
    sig_b = (k0 + kprune) * 1.0
    return dict(R0=R0, Kpsi=Kpsi, k0=k0, sig_b=sig_b)


def m_t(t, p):
    rise = _sigmoid((t - p["t_m"]) / p["w_m"])
    decline = 1.0 - p["d_m"] * _sigmoid((t - 12.0) / 3.0)
    return rise * decline


def sigma_t(t, p, d):
    x = np.maximum(t - T0, 0.0) / p["tau_s"]
    a = p["a_s"]
    pulse = (x ** a) * np.exp(-x) / ((a ** a) * np.exp(-a))   # max = 1 at x=a
    return d["sig_b"] * (1.0 + p["sig_amp"] * pulse)


def simulate(p, dG=0.0, dS=0.0, record=("S", "P", "R", "psi"), every=20):
    """Vectorised RK4. p: dict of arrays (n,). dG/dS scalars or arrays (n,)."""
    p = {k: np.asarray(v, float) for k, v in p.items()}
    n = p["kP"].size
    d = derived(p)
    eps = 1.0 - np.asarray(dG, float) * np.ones(n)
    R0 = d["R0"] * (1.0 - np.asarray(dS, float) * np.ones(n))
    # initial conditions at t = -0.5 y (mid-gestation)
    S = np.full(n, 0.05); P = m_t(np.full(n, T0), p) * S ** p["lam"]
    R = R0 / (1.0 + (S ** p["eta"] / p["Ah"]) ** p["n"])
    psi = R ** p["h"] / (R ** p["h"] + d["Kpsi"] ** p["h"])

    def rhs(t, S, P, R, psi):
        A = np.maximum(S, 1e-6) ** p["eta"]
        F = F_of_psi(psi)
        Phi = p["phi0"] + (1 - p["phi0"]) * F
        dS_ = sigma_t(t, p, d) - (d["k0"] + p["kP"] * eps * P * Phi) * S
        dP_ = (m_t(t, p) * np.maximum(S, 1e-6) ** p["lam"] - P) / p["tauP"]
        dR_ = (R0 / (1.0 + (A / p["Ah"]) ** p["n"]) - R) / p["tauR"]
        dpsi_ = (R ** p["h"] / (R ** p["h"] + d["Kpsi"] ** p["h"]) - psi) / p["taupsi"]
        return dS_, dP_, dR_, dpsi_

    out = {k: [] for k in record}; tt = []
    for i, t in enumerate(TGRID):
        if i % every == 0:
            loc = dict(S=S, P=P, R=R, psi=psi, F=F_of_psi(psi))
            for k in record:
                out[k].append(loc[k].copy())
            tt.append(t)
        if i == len(TGRID) - 1:
            break
        h = DT
        k1 = rhs(t, S, P, R, psi)
        k2 = rhs(t + h / 2, *(x + h / 2 * k for x, k in zip((S, P, R, psi), k1)))
        k3 = rhs(t + h / 2, *(x + h / 2 * k for x, k in zip((S, P, R, psi), k2)))
        k4 = rhs(t + h, *(x + h * k for x, k in zip((S, P, R, psi), k3)))
        S, P, R, psi = (x + h / 6 * (a + 2 * b + 2 * c + e) for x, a, b, c, e in
                        zip((S, P, R, psi), k1, k2, k3, k4))
    res = {k: np.array(v).T for k, v in out.items()}   # (n, T)
    res["t"] = np.array(tt)
    return res


def window_mean(res, key, lo, hi):
    m = (res["t"] >= lo) & (res["t"] <= hi)
    return res[key][:, m].mean(1)


def summaries(ctl, les=None):
    """Calibration summaries (Tang 2014; Petanjek 2011; Huttenlocher 1997)."""
    t = ctl["t"]; S = ctl["S"]
    child = window_mean(ctl, "S", 2, 9); adol = window_mean(ctl, "S", 13, 20)
    peak_age = t[np.argmax(S, 1)]
    peak_over_adult = S.max(1) / window_mean(ctl, "S", 30, 40)
    stab = window_mean(ctl, "S", 25, 30) / window_mean(ctl, "S", 35, 40)
    out = dict(child_over_adol=child / adol, peak_age=peak_age,
               peak_over_adult=peak_over_adult, stab_25_30=stab)
    if les is not None:
        out["asd_child_ratio"] = window_mean(les, "S", 2, 9) / child
        out["asd_adol_ratio"] = window_mean(les, "S", 13, 20) / adol
        out["psi_asd_adult"] = window_mean(les, "psi", 20, 40)
    out["psi_ctl_adult"] = window_mean(ctl, "psi", 20, 40)
    return out


def onset_age(t, dev, frac=0.25, tmax=30.0):
    """First age at which |deviation| reaches frac x its max over [0, tmax]."""
    m = (t >= 0) & (t <= tmax)
    tt, D = t[m], np.abs(dev[:, m])
    thr = frac * D.max(1, keepdims=True)
    idx = np.argmax(D >= thr, 1)
    return tt[idx]


def simulate_stoch(p, dG=0.0, dS=0.0, rng=None, ou_sd=0.15, ou_tau=1.0,
                   dt=0.01, rec_every=0.25, t_end=30.0, interv=None):
    """Stochastic version: log-normal Ornstein-Uhlenbeck forcing of engulfment
    efficacy (immune/environmental fluctuations) and of SRRM4 production
    (transcriptional noise), identical in all individuals. Semi-implicit Euler
    for the OU processes; Heun step for states (forcing frozen within step)."""
    rng = np.random.default_rng() if rng is None else rng
    p = {k: np.asarray(v, float) for k, v in p.items()}
    n = p["kP"].size
    d = derived(p)
    eps0 = 1.0 - np.asarray(dG, float) * np.ones(n)
    R00 = d["R0"] * (1.0 - np.asarray(dS, float) * np.ones(n))
    S = np.full(n, 0.05); P = m_t(np.full(n, T0), p) * S ** p["lam"]
    R = R00 / (1.0 + (S ** p["eta"] / p["Ah"]) ** p["n"])
    psi = R ** p["h"] / (R ** p["h"] + d["Kpsi"] ** p["h"])
    xg = rng.normal(0, ou_sd, n); xs = rng.normal(0, ou_sd, n)
    a = np.exp(-dt / ou_tau); b = ou_sd * np.sqrt(1 - a * a)

    def rhs(t, S, P, R, psi, eps, R0):
        A = np.maximum(S, 1e-6) ** p["eta"]
        Phi = p["phi0"] + (1 - p["phi0"]) * F_of_psi(psi)
        return (sigma_t(t, p, d) - (d["k0"] + p["kP"] * eps * P * Phi) * S,
                (m_t(t, p) * np.maximum(S, 1e-6) ** p["lam"] - P) / p["tauP"],
                (R0 / (1.0 + (A / p["Ah"]) ** p["n"]) - R) / p["tauR"],
                (R ** p["h"] / (R ** p["h"] + d["Kpsi"] ** p["h"]) - psi) / p["taupsi"])

    times = np.arange(T0, t_end + 1e-9, dt)
    k_rec = int(round(rec_every / dt)); out = {k: [] for k in ("S", "P", "R", "psi")}; tt = []
    for i, t in enumerate(times):
        if i % k_rec == 0:
            for k, v in zip(("S", "P", "R", "psi"), (S, P, R, psi)):
                out[k].append(v.copy())
            tt.append(t)
        eps = eps0 * np.exp(xg); R0 = R00 * np.exp(xs)
        if interv is not None and interv["t0"] <= t < interv["t1"]:
            # counterfactual intervention: boost engulfment efficacy (glial
            # therapy) or SRRM4 production (microexon-restoring therapy)
            if interv["kind"] == "glia":
                eps = eps * (1.0 + interv["size"] * interv.get("mask", 1.0))
            else:
                R0 = R0 * (1.0 + interv["size"] * interv.get("mask", 1.0))
        k1 = rhs(t, S, P, R, psi, eps, R0)
        y2 = [x + dt * k for x, k in zip((S, P, R, psi), k1)]
        k2 = rhs(t + dt, *y2, eps, R0)
        S, P, R, psi = (x + dt / 2 * (u + v) for x, u, v in zip((S, P, R, psi), k1, k2))
        xg = a * xg + b * rng.normal(size=n); xs = a * xs + b * rng.normal(size=n)
    res = {k: np.array(v).T for k, v in out.items()}
    res["t"] = np.array(tt)
    return res
