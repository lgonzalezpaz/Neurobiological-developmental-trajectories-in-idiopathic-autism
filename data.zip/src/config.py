"""Shared configuration: paths, a-priori gene modules, plotting style.

All gene modules are defined a priori from the literature (see Methods, Table 2)
and are never tuned on the validation data.
"""
from pathlib import Path
import matplotlib as mpl

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROC = ROOT / "data" / "processed"
RES = ROOT / "results"
FIG = ROOT / "figures"
for d in (PROC, RES, FIG):
    d.mkdir(parents=True, exist_ok=True)

SEED = 20261020

# --- A-priori modules -------------------------------------------------------
MODULES = {
    # Glial synapse-elimination machinery: complement tagging (C1q/C3/C4),
    # CR3 (ITGAM), fractalkine and TREM2-DAP12 signalling, microglial
    # homeostatic/phagocytic markers, astrocytic MEGF10/MERTK.
    "GLIA_PRUNE": ["C1QA", "C1QB", "C1QC", "C3", "C4A", "C4B", "ITGAM",
                   "CX3CR1", "TREM2", "TYROBP", "P2RY12", "CSF1R", "CD68",
                   "AIF1", "MEGF10", "MERTK"],
    # Neuronal (activity-sensitive) splicing regulators, incl. SRRM4 which
    # controls the CPEB4 microexon and the neural microexon programme.
    "NEURO_SPLICE": ["SRRM4", "SRRM3", "RBFOX1", "RBFOX3", "NOVA1", "NOVA2",
                     "PTBP2", "CELF4", "ELAVL3", "ELAVL4", "KHDRBS2",
                     "KHDRBS3", "MBNL2"],
    # Activity-regulated immediate-early genes: read-out of network activity.
    "ACTIVITY_IEG": ["FOS", "FOSB", "NPAS4", "EGR1", "EGR2", "EGR3", "ARC",
                     "NR4A1", "JUNB", "DUSP1", "IER2"],
    # Synaptic structural genes (synaptogenesis read-out in development).
    "SYNAPSE": ["DLG4", "SYP", "SYN1", "SYN2", "SNAP25", "HOMER1", "SHANK2",
                "SHANK3", "GRIN1", "GRIA1", "SYT1", "NRXN1", "NLGN1"],
}
CPEB4_AXIS = ["CPEB4", "SRRM4"]

MOD_LABEL = {"GLIA_PRUNE": "Glial pruning", "NEURO_SPLICE": "Neuronal splicing",
             "ACTIVITY_IEG": "Activity (IEG)", "SYNAPSE": "Synaptic"}

# Okabe-Ito colour-blind-safe palette
COL = {"GLIA_PRUNE": "#D55E00", "NEURO_SPLICE": "#0072B2",
       "ACTIVITY_IEG": "#009E73", "SYNAPSE": "#CC79A7",
       "ctrl": "#444444", "asd": "#E69F00", "glia": "#D55E00",
       "splice": "#0072B2", "mixed": "#009E73", "grey": "#999999"}


def style():
    mpl.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 7, "axes.titlesize": 8,
        "axes.labelsize": 7, "xtick.labelsize": 6, "ytick.labelsize": 6,
        "legend.fontsize": 6, "axes.spines.top": False,
        "axes.spines.right": False, "axes.linewidth": 0.6,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "lines.linewidth": 1.2, "savefig.dpi": 600, "figure.dpi": 150,
        "pdf.fonttype": 42, "svg.fonttype": "none"})


def save(fig, name):
    for ext in ("png", "pdf", "svg"):
        fig.savefig(FIG / f"{name}.{ext}", bbox_inches="tight")
