"""Statistical tests of model predictions in three post-mortem ASD cohorts.

P1 convergence: ASD shifts glial-pruning (up) and neuronal-splicing (down).
P2 coupling:    glial and splicing scores are negatively coupled across people.
P3 heterogeneity: ASD dispersion along the glia/splicing plane exceeds controls.
P4 phase:       diagnosis effects depend on age (GSE102741 only).
Random-effects (DerSimonian-Laird) meta-analysis; permutation P values.
"""
import json
import numpy as np, pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
from sklearn.mixture import GaussianMixture
from config import PROC, RES, SEED, MODULES

FEATS = list(MODULES) + ["SRRM4", "CPEB4"]
COV = {"GSE102741": " + np.log(age) + C(sex) + rin", "GSE28475": "", "GSE28521": ""}
CELL = " + NEURON + ASTRO + OLIGO"
rng = np.random.default_rng(SEED)
NPERM = 10000


def hedges(t, n1, n2):
    d = t * np.sqrt(1 / n1 + 1 / n2)
    J = 1 - 3 / (4 * (n1 + n2) - 9)
    g = J * d
    se = np.sqrt((n1 + n2) / (n1 * n2) + g ** 2 / (2 * (n1 + n2)))
    return g, se


def dl_meta(y, se):
    y, se = np.asarray(y), np.asarray(se)
    w = 1 / se ** 2
    fe = np.sum(w * y) / w.sum()
    Q = np.sum(w * (y - fe) ** 2); k = len(y)
    tau2 = max(0.0, (Q - (k - 1)) / (w.sum() - np.sum(w ** 2) / w.sum()))
    wr = 1 / (se ** 2 + tau2)
    mu = np.sum(wr * y) / wr.sum(); s = np.sqrt(1 / wr.sum())
    z = mu / s
    I2 = max(0.0, (Q - (k - 1)) / Q) if Q > 0 else 0.0
    return dict(est=mu, se=s, lo=mu - 1.96 * s, hi=mu + 1.96 * s,
                p=2 * stats.norm.sf(abs(z)), tau2=tau2, I2=I2, Q=Q,
                p_Q=stats.chi2.sf(Q, k - 1))


def dx_effect(d, f, extra=""):
    form = f"{f} ~ C(dx, Treatment('CTL'))" + COV[d.cohort.iloc[0]] + extra
    m = smf.ols(form, data=d).fit()
    t = m.tvalues.iloc[1]
    n1, n2 = (d.dx == "ASD").sum(), (d.dx == "CTL").sum()
    g, se = hedges(t, n1, n2)
    # permutation P (diagnosis labels shuffled, covariates fixed)
    # vectorised OLS: permute the diagnosis column of the design matrix
    X = np.asarray(m.model.exog, float); y = np.asarray(m.model.endog, float)
    n, k = X.shape
    Xp = np.repeat(X[None], NPERM, 0)
    for i in range(NPERM):
        Xp[i, :, 1] = rng.permutation(X[:, 1])
    XtX = np.einsum("pij,pik->pjk", Xp, Xp)
    inv = np.linalg.inv(XtX)
    beta = np.einsum("pjk,pik,i->pj", inv, Xp, y)
    res_ = y[None] - np.einsum("pij,pj->pi", Xp, beta)
    s2 = (res_ ** 2).sum(1) / (n - k)
    tp = beta[:, 1] / np.sqrt(s2 * inv[:, 1, 1])
    pperm = (1 + np.sum(np.abs(tp) >= abs(t))) / (NPERM + 1)
    return dict(g=g, se=se, t=t, p=m.pvalues.iloc[1], p_perm=pperm,
                n_asd=int(n1), n_ctl=int(n2))


def resid(d, f, with_dx=True):
    form = f"{f} ~ 1" + (" + C(dx)" if with_dx else "") + COV[d.cohort.iloc[0]]
    return smf.ols(form, data=d).fit().resid


def main():
    df = pd.read_csv(PROC / "postmortem_module_scores.csv", index_col=0)
    out = {"per_cohort": {}, "meta": {}, "meta_cell_adjusted": {}}
    rows = []
    for f in FEATS:
        res, resc = [], []
        for c, d in df.groupby("cohort"):
            d = d.dropna(subset=[f])
            r = dx_effect(d, f); rc = dx_effect(d, f, CELL) if f not in ("SYNAPSE",) else r
            out["per_cohort"].setdefault(f, {})[c] = r
            res.append(r); resc.append(rc)
            rows.append(dict(feature=f, cohort=c, **{k: r[k] for k in ("g", "se", "p", "p_perm", "n_asd", "n_ctl")},
                             g_celladj=rc["g"], p_celladj=rc["p"]))
        out["meta"][f] = dl_meta([r["g"] for r in res], [r["se"] for r in res])
        out["meta_cell_adjusted"][f] = dl_meta([r["g"] for r in resc], [r["se"] for r in resc])
        rows.append(dict(feature=f, cohort="META", g=out["meta"][f]["est"],
                         se=out["meta"][f]["se"], p=out["meta"][f]["p"],
                         g_celladj=out["meta_cell_adjusted"][f]["est"],
                         p_celladj=out["meta_cell_adjusted"][f]["p"]))
    pd.DataFrame(rows).to_csv(RES / "postmortem_dx_effects.csv", index=False)

    # ---- P2 coupling: partial Spearman glia vs splicing ------------------
    coup = {}
    for grp in ["all", "ASD", "CTL"]:
        zs, ws, per = [], [], {}
        for c, d in df.groupby("cohort"):
            dd = d if grp == "all" else d[d.dx == grp]
            a = resid(dd, "GLIA_PRUNE", grp == "all"); b = resid(dd, "NEURO_SPLICE", grp == "all")
            rho, p = stats.spearmanr(a, b)
            # permutation
            pr = np.array([stats.spearmanr(a, rng.permutation(b.values))[0] for _ in range(5000)])
            per[c] = dict(rho=rho, p=p, p_perm=(1 + np.sum(np.abs(pr) >= abs(rho))) / 5001, n=len(dd))
            zs.append(np.arctanh(rho)); ws.append(np.sqrt(1.06 / (len(dd) - 3)))
        m = dl_meta(zs, ws)
        coup[grp] = dict(per_cohort=per, rho_pooled=np.tanh(m["est"]),
                         lo=np.tanh(m["lo"]), hi=np.tanh(m["hi"]), p=m["p"], I2=m["I2"])
        # cell-composition-adjusted coupling
    zs, ws = [], []
    for c, d in df.groupby("cohort"):
        a = smf.ols("GLIA_PRUNE ~ C(dx)" + COV[c] + CELL, d).fit().resid
        b = smf.ols("NEURO_SPLICE ~ C(dx)" + COV[c] + CELL, d).fit().resid
        rho, _ = stats.spearmanr(a, b); zs.append(np.arctanh(rho)); ws.append(np.sqrt(1.06 / (len(d) - 3)))
    m = dl_meta(zs, ws)
    coup["all_cell_adjusted"] = dict(rho_pooled=np.tanh(m["est"]), lo=np.tanh(m["lo"]),
                                     hi=np.tanh(m["hi"]), p=m["p"], I2=m["I2"])
    out["coupling"] = coup

    # ---- P3 heterogeneity in the glia/splicing plane ---------------------
    zl = []
    for c, d in df.groupby("cohort"):
        ctl = d[d.dx == "CTL"]
        for f in ["GLIA_PRUNE", "NEURO_SPLICE"]:
            d = d.assign(**{f + "_zc": (d[f] - ctl[f].mean()) / ctl[f].std()})
        zl.append(d)
    Z = pd.concat(zl)
    Z["theta_deg"] = np.degrees(np.arctan2(-Z.NEURO_SPLICE_zc, Z.GLIA_PRUNE_zc))
    Z["radius"] = np.hypot(Z.GLIA_PRUNE_zc, Z.NEURO_SPLICE_zc)
    Z.to_csv(PROC / "postmortem_control_referenced.csv")
    het = {}
    for f in ["GLIA_PRUNE_zc", "NEURO_SPLICE_zc", "radius"]:
        a, b = Z.loc[Z.dx == "ASD", f], Z.loc[Z.dx == "CTL", f]
        bf = stats.levene(a, b, center="median")
        het[f] = dict(sd_asd=a.std(), sd_ctl=b.std(), BF_W=bf.statistic, p=bf.pvalue)
    # radial deviation (Mahalanobis-like) ASD vs CTL, Mann-Whitney
    a, b = Z.loc[Z.dx == "ASD", "radius"], Z.loc[Z.dx == "CTL", "radius"]
    mw = stats.mannwhitneyu(a, b, alternative="greater")
    het["radius_MWU"] = dict(U=mw.statistic, p=mw.pvalue, median_asd=a.median(), median_ctl=b.median())
    # GMM on ASD points
    A = Z.loc[Z.dx == "ASD", ["GLIA_PRUNE_zc", "NEURO_SPLICE_zc"]].values
    bic = {k: GaussianMixture(k, covariance_type="full", n_init=20, random_state=SEED).fit(A).bic(A) for k in (1, 2, 3)}
    # parametric bootstrap of dBIC(1 vs 2) under the 1-component null
    g1 = GaussianMixture(1, covariance_type="full").fit(A)
    dnull = []
    for i in range(500):
        S = g1.sample(len(A))[0]
        dnull.append(GaussianMixture(1).fit(S).bic(S) - GaussianMixture(2, n_init=5, random_state=i).fit(S).bic(S))
    dobs = bic[1] - bic[2]
    het["gmm"] = dict(bic=bic, dBIC_1v2=dobs, p_boot=(1 + np.sum(np.array(dnull) >= dobs)) / 501)
    # dominance classes: glia-dominant (|zG|>|zS|) vs splicing-dominant, among deviant ASD (radius>1.5)
    dev = Z[(Z.dx == "ASD") & (Z.radius > 1.5)]
    het["dominance"] = dict(n_deviant=int(len(dev)),
                            glia_dominant=int((dev.GLIA_PRUNE_zc.abs() > dev.NEURO_SPLICE_zc.abs()).sum()),
                            splice_dominant=int((dev.GLIA_PRUNE_zc.abs() <= dev.NEURO_SPLICE_zc.abs()).sum()),
                            n_ctl_deviant=int(((Z.dx == "CTL") & (Z.radius > 1.5)).sum()),
                            n_asd=int((Z.dx == "ASD").sum()), n_ctl=int((Z.dx == "CTL").sum()))
    out["heterogeneity"] = het

    # ---- P4 age-dependence (GSE102741) ------------------------------------
    d = df[df.cohort == "GSE102741"].copy(); d["lage"] = np.log(d.age)
    agei = {}
    for f in FEATS:
        m = smf.ols(f"{f} ~ C(dx, Treatment('CTL')) * lage + C(sex) + rin", d).fit()
        key = [k for k in m.params.index if ":" in k][0]
        agei[f] = dict(beta_int=m.params[key], p_int=m.pvalues[key])
        # effect in <20 y vs >=20 y
        for lab, sub in [("lt20", d[d.age < 20]), ("ge20", d[d.age >= 20])]:
            mm = smf.ols(f"{f} ~ C(dx, Treatment('CTL')) + lage + rin", sub).fit()
            n1, n2 = (sub.dx == "ASD").sum(), (sub.dx == "CTL").sum()
            g, se = hedges(mm.tvalues.iloc[1], n1, n2)
            agei[f][lab] = dict(g=g, se=se, p=mm.pvalues.iloc[1], n_asd=int(n1), n_ctl=int(n2))
    out["age_interaction_GSE102741"] = agei
    json.dump(out, open(RES / "postmortem_stats.json", "w"), indent=1, default=float)
    for f in FEATS:
        m = out["meta"][f]; mc = out["meta_cell_adjusted"][f]
        print(f"{f:13s} g={m['est']:+.2f} [{m['lo']:+.2f},{m['hi']:+.2f}] p={m['p']:.2g} I2={m['I2']:.2f} | celladj g={mc['est']:+.2f} p={mc['p']:.2g}")
    print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk != 'per_cohort'} for k, v in coup.items()}, indent=1, default=float))
    print(json.dumps(het, indent=1, default=float))
    print(json.dumps(agei, indent=1, default=float))


if __name__ == "__main__":
    main()
