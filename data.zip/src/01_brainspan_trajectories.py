"""Normative developmental trajectories of the a-priori modules (BrainSpan).

Output: donor-level module scores across neocortex, LOWESS trajectories with
donor-bootstrap 95% bands, and timing statistics (age at peak; age at 50% of
postnatal change), used (i) as descriptive validation and (ii) as calibration
targets for the mechanistic model.
"""
import numpy as np, pandas as pd, json
from statsmodels.nonparametric.smoothers_lowess import lowess
from config import RAW, PROC, RES, MODULES, SEED

NEOCTX = {"DFC", "VFC", "MFC", "OFC", "M1C", "S1C", "IPC", "A1C", "STC", "ITC",
          "V1C", "M1C-S1C", "Ocx", "PCx", "TCx"}


def age_years(a):
    v, u = a.split()
    v = float(v)
    if u == "pcw":
        return (v - 40.0) / 52.18          # years relative to birth
    if u == "mos":
        return v / 12.0
    return v


def main():
    bs = RAW / "brainspan"
    cols = pd.read_csv(bs / "columns_metadata.csv")
    rows = pd.read_csv(bs / "rows_metadata.csv")
    genes = sorted(set(sum(MODULES.values(), [])) | {"CPEB4"})
    idx = rows.index[rows.gene_symbol.isin(genes)].to_numpy()
    expr = pd.read_csv(bs / "expression_matrix.csv", header=None, index_col=0,
                       skiprows=lambda i: i not in set(idx), nrows=None)
    expr.index = rows.gene_symbol.iloc[idx].values
    expr = expr.groupby(level=0).mean()
    keep = cols.structure_acronym.isin(NEOCTX).to_numpy()
    X = np.log2(expr.loc[:, keep] + 1.0)
    meta = cols.loc[keep].copy()
    meta["age_y"] = meta.age.map(age_years)
    meta["log_pc_days"] = np.log10((meta.age_y * 365.25) + 280.0)  # post-conception
    # z-score genes across all cortical samples, then average per module
    Z = X.sub(X.mean(1), axis=0).div(X.std(1) + 1e-9, axis=0)
    sc = pd.DataFrame({m: Z.loc[[g for g in gl if g in Z.index]].mean(0).values
                       for m, gl in MODULES.items()}, index=meta.index)
    for g in ["CPEB4", "SRRM4"]:
        sc[g] = Z.loc[g].values
    sc["donor"] = meta.donor_id.values
    sc["age_y"] = meta.age_y.values
    sc["log_pc_days"] = meta.log_pc_days.values
    donor = sc.groupby("donor").mean().sort_values("age_y")
    donor.to_csv(PROC / "brainspan_donor_module_scores.csv")

    grid = np.linspace(donor.log_pc_days.min(), donor.log_pc_days.max(), 200)
    feats = list(MODULES) + ["CPEB4", "SRRM4"]
    rng = np.random.default_rng(SEED)
    B = 1000
    curves = {f: np.empty((B, grid.size)) for f in feats}
    fit = {}
    for f in feats:
        y = donor[f].values; x = donor.log_pc_days.values
        fit[f] = np.interp(grid, *lowess(y, x, frac=0.45, return_sorted=True).T)
        for b in range(B):
            ii = rng.integers(0, len(x), len(x))
            lo = lowess(y[ii], x[ii], frac=0.45, return_sorted=True)
            xs, ind = np.unique(lo[:, 0], return_index=True)
            curves[f][b] = np.interp(grid, xs, lo[ind, 1])
    out = pd.DataFrame({"log_pc_days": grid,
                        "age_y": (10 ** grid - 280.0) / 365.25})
    for f in feats:
        out[f] = fit[f]
        out[f + "_lo"] = np.percentile(curves[f], 2.5, 0)
        out[f + "_hi"] = np.percentile(curves[f], 97.5, 0)
    out.to_csv(RES / "brainspan_trajectories.csv", index=False)

    # timing statistics on postnatal window (birth .. 40 y)
    post = out.age_y.values >= 0
    def timing(curve):
        c = curve[post]; a = out.age_y.values[post]
        peak = a[np.argmax(c)]; trough = a[np.argmin(c)]
        half = c[0] + 0.5 * (c[-1] - c[0])
        cross = a[np.argmin(np.abs(c - half))]
        return peak, trough, cross
    tim = {}
    for f in feats:
        bt = np.array([timing(curves[f][b]) for b in range(B)])
        p, t, h = timing(fit[f])
        tim[f] = {"age_peak": p, "age_trough": t, "age_half_change": h,
                  "age_half_change_CI": list(np.percentile(bt[:, 2], [2.5, 97.5])),
                  "postnatal_change": float(fit[f][post][-1] - fit[f][post][0])}
    # Spearman correlation of module scores with log-age, postnatal donors
    from scipy.stats import spearmanr
    pd_ = donor[donor.age_y >= 0]
    for f in feats:
        r, pv = spearmanr(pd_.log_pc_days, pd_[f])
        tim[f].update(rho_postnatal_age=r, p_postnatal_age=pv)
    # postnatal coupling glia vs splicing, partial on log-age
    import statsmodels.api as sm
    def resid(v):
        Xd = sm.add_constant(np.c_[pd_.log_pc_days, pd_.log_pc_days ** 2])
        return sm.OLS(v, Xd).fit().resid
    r, pv = spearmanr(resid(pd_.GLIA_PRUNE), resid(pd_.NEURO_SPLICE))
    tim["partial_glia_splice_postnatal"] = {"rho": r, "p": pv, "n": len(pd_)}
    # anti-phase test: postnatal glial peak vs SRRM4/splicing trough, and
    # correlation between the fitted postnatal curves (donor bootstrap CI)
    a = out.age_y.values[post]
    for f2 in ["SRRM4", "NEURO_SPLICE"]:
        pk = np.array([a[np.argmax(curves["GLIA_PRUNE"][b][post])] for b in range(B)])
        tr = np.array([a[np.argmin(curves[f2][b][post])] for b in range(B)])
        cc = np.array([np.corrcoef(curves["GLIA_PRUNE"][b][post], curves[f2][b][post])[0, 1]
                       for b in range(B)])
        tim[f"antiphase_GLIA_vs_{f2}"] = {
            "glia_peak_age_median": float(np.median(pk)),
            "glia_peak_age_CI": list(np.percentile(pk, [2.5, 97.5])),
            "trough_age_median": float(np.median(tr)),
            "trough_age_CI": list(np.percentile(tr, [2.5, 97.5])),
            "curve_r": float(np.corrcoef(fit["GLIA_PRUNE"][post], fit[f2][post])[0, 1]),
            "curve_r_CI": list(np.percentile(cc, [2.5, 97.5])),
            "P_boot_r_ge_0": float(np.mean(cc >= 0))}
    tim["n_donors"] = int(len(donor)); tim["n_postnatal_donors"] = int(len(pd_))
    tim["n_samples"] = int(keep.sum())
    json.dump(tim, open(RES / "brainspan_timing.json", "w"), indent=1, default=float)
    print(json.dumps(tim, indent=1, default=float))


if __name__ == "__main__":
    main()
